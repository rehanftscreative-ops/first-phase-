code
Bash
npm run dev
