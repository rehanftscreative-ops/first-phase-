export type PatientStatus = 'Inpatient' | 'Outpatient' | 'Emergency' | 'Discharged';

export type BloodGroup = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';

export interface Vitals {
  heartRate: number; // bpm
  bloodPressureSys: number; // mmHg
  bloodPressureDia: number; // mmHg
  spO2: number; // %
  temperature: number; // °F
  respiratoryRate: number; // breaths/min
  recordedAt: string;
}

export interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  route: string; // Oral, IV, Topical, etc.
  prescribedBy: string;
  startDate: string;
  endDate?: string;
  status: 'Active' | 'Completed' | 'Discontinued';
}

export interface LabResult {
  id: string;
  testName: string;
  category: 'Hematology' | 'Radiology' | 'Biochemistry' | 'Pathology' | 'Cardiology';
  orderedDate: string;
  resultDate?: string;
  status: 'Pending' | 'Normal' | 'Elevated' | 'Critical';
  value: string;
  referenceRange: string;
  orderedBy: string;
  notes?: string;
}

export interface ClinicalNote {
  id: string;
  date: string;
  doctorName: string;
  doctorSpecialty: string;
  chiefComplaint: string;
  assessment: string;
  treatmentPlan: string;
  diagnosisCode: string; // e.g. ICD-10 code
}

export type DiagnosisSeverity = 'Mild' | 'Moderate' | 'Severe' | 'Acute on Chronic';
export type DiagnosisStatus = 'Active' | 'Chronic' | 'In Remission' | 'Resolved' | 'Rule Out';
export type DiagnosisType = 'Primary' | 'Secondary' | 'Differential' | 'Admitting' | 'Discharge';

export interface PatientDiagnosis {
  id: string;
  icdCode: string; // ICD-10-CM Standard
  description: string;
  category: string;
  type: DiagnosisType;
  status: DiagnosisStatus;
  severity: DiagnosisSeverity;
  onsetDate: string;
  diagnosedDate: string;
  diagnosedBy: string;
  doctorSpecialty: string;
  clinicalNotes?: string;
  hipaaStandard: 'ICD-10-CM' | 'ICD-11' | 'SNOMED-CT';
  billable: boolean;
  hipaaAuditStamp?: string;
}

export interface FacilityVisit {
  id: string;
  visitDate: string;
  doctorName: string;
  doctorSpecialty: string;
  department: string;
  clinicRoom: string;
  visitType: 'Emergency Triage' | 'Specialist Consultation' | 'Inpatient Ward Round' | 'Outpatient Follow-up' | 'Surgical Review' | 'Lab & Imaging Review';
  chiefComplaint: string;
  clinicalAssessment: string;
  primaryDiagnosis: {
    code: string;
    description: string;
  };
  vitalsSnapshot: {
    bloodPressure: string;
    heartRate: number;
    spO2: number;
    temperature: number;
    respiratoryRate: number;
  };
  medicationsPrescribed: string[];
  diagnosticOrders: string[];
  disposition: 'Admitted to Ward' | 'Discharged to Home' | 'Follow-up Scheduled' | 'Referred to Specialist' | 'Transferred to ICU';
  signedAt: string;
  signatureHash?: string;
}

export interface InsurancePolicy {
  provider: string;
  policyNumber: string;
  groupNumber: string;
  coveragePercentage: number; // e.g. 80 means 80% covered
  copayAmount: number;
  status: 'Verified' | 'Pending' | 'Expired';
  expiryDate: string;
}

export interface Patient {
  id: string; // e.g. PT-10492
  firstName: string;
  lastName: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  dob: string;
  bloodGroup: BloodGroup;
  phone: string;
  email: string;
  address: string;
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
  };
  status: PatientStatus;
  wardOrRoom?: string; // e.g., "ICU Bed 04" or "Ward B, Room 208"
  primaryPhysicianId: string;
  primaryPhysicianName: string;
  allergies: Array<{ allergen: string; severity: 'Mild' | 'Moderate' | 'Severe' }>;
  chronicConditions: string[];
  vitals: Vitals[];
  medications: Medication[];
  labResults: LabResult[];
  clinicalNotes: ClinicalNote[];
  diagnoses?: PatientDiagnosis[];
  facilityVisits?: FacilityVisit[];
  insurance: InsurancePolicy;
  createdAt: string;
  updatedAt: string;
}

export type AppointmentStatus = 
  | 'Scheduled' 
  | 'Checked-In' 
  | 'In Consultation' 
  | 'Completed' 
  | 'Cancelled' 
  | 'No-Show';

export type AppointmentPriority = 'Normal' | 'Urgent' | 'Emergency';

export type AppointmentType =
  | 'General Consultation' 
  | 'Follow-up' 
  | 'Specialist Review' 
  | 'Emergency Triage' 
  | 'Lab Review'
  | 'Telehealth Consultation'
  | 'Remote Follow-up';

export interface TelehealthDetails {
  platform: 'WebRTC Clinical Room' | 'Secure Portal' | 'HIPAA Video Bridge';
  roomId: string;
  meetingLink: string;
  patientStatus: 'Waiting in Room' | 'Scheduled / Not Joined' | 'Connected' | 'Completed';
  patientJoinedAt?: string;
  deviceInfo?: string;
  connectionQuality?: 'Excellent (HD 1080p)' | 'Good (720p)' | 'Fair';
  telehealthConsentSigned: boolean;
}

export interface Appointment {
  id: string; // APT-2026-001
  patientId: string;
  patientName: string;
  patientAge: number;
  patientGender: string;
  doctorId: string;
  doctorName: string;
  department: string;
  roomNumber: string;
  date: string; // YYYY-MM-DD
  timeSlot: string; // e.g. "09:30 AM"
  type: string;
  status: AppointmentStatus;
  priority: AppointmentPriority;
  reason: string;
  queueNumber: number;
  estimatedWaitMinutes?: number;
  notes?: string;
  createdAt: string;
  isTelehealth?: boolean;
  telehealthDetails?: TelehealthDetails;
}

export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  department: string;
  roomNumber: string;
  avatar: string;
  availableDays: string[];
  availableHours: string;
  consultationFee: number;
  status: 'Available' | 'In Consultation' | 'In Surgery' | 'Off Duty';
}

export interface BillItem {
  id: string;
  description: string;
  category: 'Consultation' | 'Lab Test' | 'Radiology' | 'Pharmacy' | 'Room & Nursing' | 'Surgical Procedure' | 'Cardiology';
  unitCost: number;
  quantity: number;
  amount: number;
}

export type PaymentStatus = 'Paid' | 'Pending' | 'Partially Paid' | 'Insurance Processing' | 'Refunded';

export type PaymentMethod = 'Credit/Debit Card' | 'HSA/FSA' | 'Direct Insurance' | 'ACH/Bank Transfer' | 'Cash';

export interface PaymentTransaction {
  transactionId: string;
  timestamp: string;
  amountPaid: number;
  method: PaymentMethod;
  cardLast4?: string;
  authCode: string;
  gatewayStatus: 'Success' | 'Declined' | 'Pending Verification';
  receiptUrl?: string;
}

export interface Invoice {
  id: string; // INV-2026-0081
  patientId: string;
  patientName: string;
  patientPhone: string;
  patientEmail: string;
  appointmentId?: string;
  issueDate: string;
  dueDate: string;
  items: BillItem[];
  subtotal: number;
  tax: number;
  insuranceCoveredAmount: number;
  copayAmount: number;
  patientPayable: number;
  amountPaid: number;
  balanceDue: number;
  status: PaymentStatus;
  paymentMethod?: PaymentMethod;
  transactions: PaymentTransaction[];
  notes?: string;
  insuranceClaimNumber?: string;
}

export interface WardBed {
  id: string;
  wardName: string; // ICU, General Ward A, Cardiology Unit, Pediatric Wing
  bedNumber: string;
  status: 'Available' | 'Occupied' | 'Maintenance' | 'Reserved';
  patientId?: string;
  patientName?: string;
  assignedDoctor?: string;
  admissionDate?: string;
}

export interface LiveNotification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'critical';
  timestamp: string;
  read: boolean;
  relatedEntityId?: string;
}

export type UserRole =
  | 'admin'
  | 'doctor'
  | 'nurse'
  | 'receptionist'
  | 'pharmacist'
  | 'lab'
  | 'radiology';

export interface RolePermissions {
  canRegisterPatients: boolean;
  canEditEMR: boolean;
  canPrescribeMeds: boolean;
  canDispenseMeds: boolean;
  canRunLabTests: boolean;
  canReviewRadiology: boolean;
  canManageBilling: boolean;
  canAccessAuditLogs: boolean;
}

export interface RoleDefinition {
  role: UserRole;
  label: string;
  description: string;
  permissions: RolePermissions;
}

export interface StaffMember {
  id: string;
  name: string;
  role: UserRole;
  department: string;
  shift: 'Morning (07:00 - 15:00)' | 'Evening (15:00 - 23:00)' | 'Night (23:00 - 07:00)' | 'On-Call';
  phone: string;
  email: string;
  roomOrStation: string;
  licenseNumber: string;
  status: 'On Duty' | 'In Consultation' | 'In Surgery' | 'On Break' | 'Off Duty';
}

export interface PharmacyItem {
  id: string;
  sku: string;
  name: string;
  genericName: string;
  category: 'Antibiotics' | 'Cardiovascular' | 'Analgesics' | 'Respiratory' | 'Endocrine' | 'Emergency IV';
  dosageForm: 'Tablet' | 'Capsule' | 'Injection IV' | 'Syrup' | 'Inhaler';
  stockQuantity: number;
  minThreshold: number;
  unitPrice: number;
  batchNumber: string;
  expiryDate: string;
  storageCondition: 'Room Temp (20-25°C)' | 'Refrigerated (2-8°C)' | 'Controlled Substance Vault';
  manufacturer: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userName: string;
  userRole: UserRole;
  action: 'CREATE' | 'READ' | 'UPDATE' | 'DELETE' | 'DISPENSE' | 'AUTHENTICATE' | 'CLAIM_EXPORT';
  resourceType: 'Patient Record' | 'Prescription' | 'Billing Invoice' | 'Lab Result' | 'Appointment' | 'Security Settings';
  resourceId: string;
  details: string;
  ipAddress?: string;
  complianceFlag?: 'HIPAA Access Log' | 'GDPR Data Processing' | 'PCI-DSS Payment Log';
}

export interface SystemCompliance {
  hipaaAuditLogEnabled: boolean;
  aes256EncryptionAtRest: boolean;
  hl7FhirInteropEnabled: boolean;
  roleBasedAccessActive: boolean;
  gdprConsentTracking: boolean;
  offlineSyncCache: boolean;
  sessionTimeoutMinutes: number;
  backupFrequencyHours: number;
}
