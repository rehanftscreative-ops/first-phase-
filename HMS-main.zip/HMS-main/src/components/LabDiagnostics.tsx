import React, { useState } from 'react';
import {
  FlaskConical,
  Search,
  Plus,
  AlertTriangle,
  CheckCircle2,
  Clock,
  FileText,
  Activity,
  QrCode,
  Check,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { LabResult } from '../types';

export const LabDiagnostics: React.FC = () => {
  const {
    patients,
    addLabResult,
    updateLabResult,
    doctors,
    currentRole,
    currentUser,
    currentRoleDefinition,
  } = useHospital();

  const canRunLabTests = currentRoleDefinition?.permissions.canRunLabTests ?? true;

  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showOrderModal, setShowOrderModal] = useState(false);

  // Collect all lab tests from all patients with patient metadata attached
  const allLabOrders = patients.flatMap((p) =>
    p.labResults.map((lab) => ({
      ...lab,
      patientId: p.id,
      patientName: `${p.firstName} ${p.lastName}`,
      patientAge: p.age,
      patientGender: p.gender,
      bloodGroup: p.bloodGroup,
    }))
  );

  const [newLabOrder, setNewLabOrder] = useState({
    patientId: patients[0]?.id || '',
    testName: 'Complete Metabolic Panel (CMP-14)',
    category: 'Biochemistry' as LabResult['category'],
    orderedDate: new Date().toISOString().split('T')[0],
    resultDate: new Date().toISOString().split('T')[0],
    status: 'Normal' as LabResult['status'],
    value: 'Glucose 94 mg/dL, Creatinine 0.9 mg/dL',
    referenceRange: 'Normal electrolyte & renal range',
    orderedBy: doctors[0]?.name || 'Dr. Julian Thorne, MD',
    notes: 'Baseline panel before surgery',
  });

  const filteredLabs = allLabOrders.filter((lab) => {
    const matchesSearch =
      lab.testName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lab.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lab.patientId.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = categoryFilter === 'all' || lab.category === categoryFilter;
    const matchesStat = statusFilter === 'all' || lab.status === statusFilter;
    return matchesSearch && matchesCat && matchesStat;
  });

  const handleCreateOrder = (e: React.FormEvent) => {
    e.preventDefault();
    addLabResult(newLabOrder.patientId, {
      testName: newLabOrder.testName,
      category: newLabOrder.category,
      orderedDate: newLabOrder.orderedDate,
      resultDate: newLabOrder.resultDate,
      status: newLabOrder.status,
      value: newLabOrder.value,
      referenceRange: newLabOrder.referenceRange,
      orderedBy: newLabOrder.orderedBy,
      notes: newLabOrder.notes,
    });
    setShowOrderModal(false);
  };

  const criticalLabsCount = allLabOrders.filter((l) => l.status === 'Critical').length;
  const elevatedLabsCount = allLabOrders.filter((l) => l.status === 'Elevated').length;

  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <FlaskConical className="w-5 h-5 text-blue-600" />
            <h1 className="text-base lg:text-lg font-bold text-slate-800 tracking-tight">
              Laboratory & Diagnostic Tracking Console
            </h1>
            <span className="px-2 py-0.5 text-[10px] font-bold bg-purple-100 text-purple-800 rounded">
              LIMS INTEGRATED
            </span>
            {canRunLabTests ? (
              <span className="px-2 py-0.5 text-[10px] font-bold bg-cyan-100 text-cyan-800 rounded flex items-center gap-1">
                <Check className="w-3 h-3" />
                Lab Technologist Access: {currentUser.name}
              </span>
            ) : (
              <span className="px-2 py-0.5 text-[10px] font-bold bg-amber-100 text-amber-800 rounded">
                View-Only Mode ({currentRole})
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Tracking pathology specimen workflows, clinical chemistry, radiological scans, and automated abnormal flag triggers.
          </p>
        </div>

        {canRunLabTests ? (
          <button
            onClick={() => setShowOrderModal(true)}
            className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-semibold flex items-center gap-1.5 shadow-sm transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Order Diagnostic Test</span>
          </button>
        ) : (
          <div className="text-[11px] text-slate-400 italic bg-slate-50 px-3 py-1.5 rounded border border-slate-200">
            Order tests via Attending Doctor or Lab Tech
          </div>
        )}
      </div>

      {/* Lab Throughput Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Active Test Orders</span>
          <div className="text-xl font-bold text-slate-800 font-mono mt-1">{allLabOrders.length}</div>
          <span className="text-[11px] text-slate-500">Across 5 diagnostic labs</span>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Critical Flags</span>
          <div className="text-xl font-bold text-red-600 font-mono mt-1">{criticalLabsCount} Alerts</div>
          <span className="text-[11px] text-slate-500">Immediate physician review required</span>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Elevated / Borderline</span>
          <div className="text-xl font-bold text-amber-600 font-mono mt-1">{elevatedLabsCount} Results</div>
          <span className="text-[11px] text-slate-500">Outside standard reference range</span>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Avg Turnaround Time</span>
          <div className="text-xl font-bold text-emerald-600 font-mono mt-1">42 mins</div>
          <span className="text-[11px] text-slate-500">Specimen draw to result post</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search test name, patient, or MRN..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 border border-slate-200 rounded text-xs focus:outline-none focus:border-blue-500"
            />
          </div>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="p-1.5 border border-slate-200 rounded text-slate-700 bg-white"
          >
            <option value="all">All Diagnostic Disciplines</option>
            <option value="Hematology">Hematology</option>
            <option value="Radiology">Radiology</option>
            <option value="Biochemistry">Biochemistry</option>
            <option value="Pathology">Pathology</option>
            <option value="Cardiology">Cardiology</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="p-1.5 border border-slate-200 rounded text-slate-700 bg-white"
          >
            <option value="all">All Statuses</option>
            <option value="Critical">Critical</option>
            <option value="Elevated">Elevated</option>
            <option value="Normal">Normal</option>
            <option value="Pending">Pending Analysis</option>
          </select>
        </div>

        <span className="text-[11px] text-slate-500 font-mono">
          Showing {filteredLabs.length} specimen records
        </span>
      </div>

      {/* Diagnostics Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-[10px] uppercase font-bold text-slate-500">
              <tr>
                <th className="py-2.5 px-3">Specimen / Barcode</th>
                <th className="py-2.5 px-3">Diagnostic Test Name</th>
                <th className="py-2.5 px-3">Patient Record</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3">Finding / Measured Value</th>
                <th className="py-2.5 px-3">Reference Range</th>
                <th className="py-2.5 px-3">Ordered By</th>
                <th className="py-2.5 px-3 text-right">Clinical Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredLabs.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    No diagnostic findings match current filters.
                  </td>
                </tr>
              ) : (
                filteredLabs.map((lab) => {
                  const isCritical = lab.status === 'Critical';
                  const isElevated = lab.status === 'Elevated';
                  return (
                    <tr key={lab.id} className={`hover:bg-slate-50 ${isCritical ? 'bg-red-50/40' : ''}`}>
                      <td className="py-2.5 px-3 whitespace-nowrap font-mono text-[11px]">
                        <div className="font-bold text-slate-800 flex items-center gap-1">
                          <QrCode className="w-3 h-3 text-slate-400" />
                          <span>{lab.id}</span>
                        </div>
                        <span className="text-[10px] text-slate-400">{lab.orderedDate}</span>
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="font-bold text-slate-800">{lab.testName}</div>
                        {lab.notes && <div className="text-[10px] text-slate-500 truncate max-w-xs">{lab.notes}</div>}
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <div className="font-semibold text-slate-800">{lab.patientName}</div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          {lab.patientId} • {lab.patientAge}y {lab.patientGender}
                        </div>
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-700">
                          {lab.category}
                        </span>
                      </td>
                      <td className="py-2.5 px-3">
                        <div className={`font-mono font-bold ${isCritical ? 'text-red-700' : isElevated ? 'text-amber-700' : 'text-slate-800'}`}>
                          {lab.value}
                        </div>
                      </td>
                      <td className="py-2.5 px-3 font-mono text-slate-500 text-[11px]">
                        {lab.referenceRange}
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap text-slate-600">
                        {lab.orderedBy}
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap text-right">
                        {canRunLabTests ? (
                          <select
                            value={lab.status}
                            onChange={(e) =>
                              updateLabResult(lab.patientId, lab.id, {
                                status: e.target.value as LabResult['status'],
                                resultDate: new Date().toISOString().split('T')[0],
                              })
                            }
                            className={`text-[10px] font-bold px-2 py-0.5 rounded border focus:outline-none cursor-pointer ${
                              isCritical
                                ? 'bg-red-100 text-red-700 border-red-300 animate-pulse'
                                : isElevated
                                ? 'bg-amber-100 text-amber-700 border-amber-300'
                                : lab.status === 'Pending'
                                ? 'bg-slate-100 text-slate-600 border-slate-300'
                                : 'bg-emerald-100 text-emerald-700 border-emerald-300'
                            }`}
                          >
                            <option value="Normal">Normal</option>
                            <option value="Pending">Pending</option>
                            <option value="Elevated">Elevated</option>
                            <option value="Critical">Critical Alert</option>
                          </select>
                        ) : (
                          <span
                            className={`inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded font-bold ${
                              isCritical
                                ? 'bg-red-100 text-red-700 animate-pulse'
                                : isElevated
                                ? 'bg-amber-100 text-amber-700'
                                : lab.status === 'Pending'
                                ? 'bg-slate-100 text-slate-600'
                                : 'bg-emerald-100 text-emerald-700'
                            }`}
                          >
                            {lab.status}
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Order Diagnostic Modal */}
      {showOrderModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-md w-full p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h3 className="font-bold text-sm text-slate-800">
                Order Diagnostic / Laboratory Investigation
              </h3>
              <button onClick={() => setShowOrderModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>
            <form onSubmit={handleCreateOrder} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-600 font-medium mb-1">Patient</label>
                <select
                  value={newLabOrder.patientId}
                  onChange={(e) => setNewLabOrder({ ...newLabOrder, patientId: e.target.value })}
                  className="w-full p-2 border border-slate-200 rounded text-slate-800 font-medium"
                >
                  {patients.map((p) => (
                    <option key={p.id} value={p.id}>{p.firstName} {p.lastName} ({p.id})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Diagnostic Test Name</label>
                <input
                  type="text"
                  placeholder="e.g. D-Dimer Quantitative Assay"
                  value={newLabOrder.testName}
                  onChange={(e) => setNewLabOrder({ ...newLabOrder, testName: e.target.value })}
                  className="w-full p-2 border border-slate-200 rounded font-semibold text-slate-800"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Category</label>
                  <select
                    value={newLabOrder.category}
                    onChange={(e) => setNewLabOrder({ ...newLabOrder, category: e.target.value as LabResult['category'] })}
                    className="w-full p-2 border border-slate-200 rounded"
                  >
                    <option value="Hematology">Hematology</option>
                    <option value="Biochemistry">Biochemistry</option>
                    <option value="Pathology">Pathology</option>
                    <option value="Radiology">Radiology</option>
                    <option value="Cardiology">Cardiology</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Result Status</label>
                  <select
                    value={newLabOrder.status}
                    onChange={(e) => setNewLabOrder({ ...newLabOrder, status: e.target.value as LabResult['status'] })}
                    className="w-full p-2 border border-slate-200 rounded"
                  >
                    <option value="Normal">Normal</option>
                    <option value="Elevated">Elevated</option>
                    <option value="Critical">Critical</option>
                    <option value="Pending">Pending Analysis</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Measured Value</label>
                  <input
                    type="text"
                    value={newLabOrder.value}
                    onChange={(e) => setNewLabOrder({ ...newLabOrder, value: e.target.value })}
                    className="w-full p-2 border border-slate-200 rounded font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Reference Range</label>
                  <input
                    type="text"
                    value={newLabOrder.referenceRange}
                    onChange={(e) => setNewLabOrder({ ...newLabOrder, referenceRange: e.target.value })}
                    className="w-full p-2 border border-slate-200 rounded font-mono"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Ordering Physician</label>
                <select
                  value={newLabOrder.orderedBy}
                  onChange={(e) => setNewLabOrder({ ...newLabOrder, orderedBy: e.target.value })}
                  className="w-full p-2 border border-slate-200 rounded"
                >
                  {doctors.map((d) => (
                    <option key={d.id} value={d.name}>{d.name} ({d.specialty})</option>
                  ))}
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowOrderModal(false)}
                  className="px-3 py-1.5 border border-slate-300 rounded text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded font-semibold"
                >
                  Record Diagnostic Test
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
