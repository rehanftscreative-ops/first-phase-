import React, { useState } from 'react';
import {
  Users,
  Search,
  Plus,
  Activity,
  Heart,
  Calendar,
  AlertTriangle,
  FileText,
  Pill,
  Clock,
  ShieldCheck,
  CheckCircle2,
  ChevronRight,
  UserX,
  Stethoscope,
  FlaskConical,
  Phone,
  Mail,
  MapPin,
  Building,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { Patient, PatientStatus, BloodGroup, Vitals, Medication, ClinicalNote, LabResult } from '../types';

interface PatientsEMRProps {
  onOpenNewPatient: () => void;
}

export const PatientsEMR: React.FC<PatientsEMRProps> = ({ onOpenNewPatient }) => {
  const {
    patients,
    selectedPatient,
    setSelectedPatientId,
    addVitals,
    addClinicalNote,
    addMedication,
    addLabResult,
    dischargePatient,
    doctors,
    currentRole,
    logAuditEvent,
  } = useHospital();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [activeEMRTab, setActiveEMRTab] = useState<'vitals' | 'notes' | 'meds' | 'labs' | 'insurance'>('vitals');

  // Modal states for adding clinical sub-records
  const [showVitalsModal, setShowVitalsModal] = useState(false);
  const [showNoteModal, setShowNoteModal] = useState(false);
  const [showMedModal, setShowMedModal] = useState(false);
  const [showLabModal, setShowLabModal] = useState(false);

  // Vitals form state
  const [vitalsForm, setVitalsForm] = useState({
    heartRate: 72,
    bloodPressureSys: 120,
    bloodPressureDia: 80,
    spO2: 98,
    temperature: 98.6,
    respiratoryRate: 16,
  });

  // Note form state
  const [noteForm, setNoteForm] = useState({
    doctorName: doctors[0]?.name || 'Dr. Julian Thorne, MD',
    doctorSpecialty: doctors[0]?.specialty || 'General Surgery',
    chiefComplaint: '',
    assessment: '',
    treatmentPlan: '',
    diagnosisCode: 'ICD-10 R10.9',
  });

  // Medication form state
  const [medForm, setMedForm] = useState({
    name: '',
    dosage: '500mg',
    frequency: 'Twice daily with meals',
    route: 'Oral',
    prescribedBy: doctors[0]?.name || 'Dr. Julian Thorne, MD',
    startDate: new Date().toISOString().split('T')[0],
    status: 'Active' as Medication['status'],
  });

  // Lab form state
  const [labForm, setLabForm] = useState({
    testName: 'Complete Blood Count (CBC)',
    category: 'Hematology' as LabResult['category'],
    orderedDate: new Date().toISOString().split('T')[0],
    resultDate: new Date().toISOString().split('T')[0],
    status: 'Normal' as LabResult['status'],
    value: 'WBC 6.4 x10^3/uL',
    referenceRange: '4.5 - 11.0 x10^3/uL',
    orderedBy: doctors[0]?.name || 'Dr. Julian Thorne, MD',
    notes: '',
  });

  const filteredPatients = patients.filter((p) => {
    const matchesSearch =
      `${p.firstName} ${p.lastName}`.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.phone.includes(searchQuery);
    if (statusFilter === 'all') return matchesSearch;
    return matchesSearch && p.status.toLowerCase() === statusFilter.toLowerCase();
  });

  const activePatient = selectedPatient || filteredPatients[0] || null;

  const handleVitalsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePatient) return;
    addVitals(activePatient.id, vitalsForm);
    setShowVitalsModal(false);
  };

  const handleNoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePatient) return;
    addClinicalNote(activePatient.id, noteForm);
    setNoteForm({
      ...noteForm,
      chiefComplaint: '',
      assessment: '',
      treatmentPlan: '',
    });
    setShowNoteModal(false);
  };

  const handleMedSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePatient) return;
    addMedication(activePatient.id, medForm);
    setMedForm({
      ...medForm,
      name: '',
    });
    setShowMedModal(false);
  };

  const handleLabSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePatient) return;
    addLabResult(activePatient.id, labForm);
    setShowLabModal(false);
  };

  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto space-y-4">
      {/* Module Title & Stats */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            <h1 className="text-base lg:text-lg font-bold text-slate-800 tracking-tight">
              Patient Registration & Electronic Medical Records (EMR)
            </h1>
            <span className="px-2 py-0.5 text-[10px] font-bold bg-blue-100 text-blue-800 rounded">
              HIPAA SECURED
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Complete longitudinal health records, active telemetry vitals, clinical encounter logs, and medications.
          </p>
        </div>

        <button
          onClick={onOpenNewPatient}
          className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-semibold flex items-center gap-1.5 shadow-sm transition shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>New Patient Registration</span>
        </button>
      </div>

      {/* Main 2-Column Split: Directory on Left, EMR Detail on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Col: Patient List (5 cols) */}
        <div className="lg:col-span-4 bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[750px]">
          <div className="p-3 border-b border-slate-200 bg-slate-50 space-y-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search patient name, ID, or phone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded text-xs focus:outline-none focus:border-blue-500 text-slate-800"
              />
            </div>

            <div className="flex items-center gap-1 overflow-x-auto pb-1 text-[11px]">
              {['all', 'Inpatient', 'Emergency', 'Outpatient', 'Discharged'].map((filter) => (
                <button
                  key={filter}
                  onClick={() => setStatusFilter(filter)}
                  className={`px-2 py-0.5 rounded font-medium transition whitespace-nowrap ${
                    statusFilter === filter
                      ? 'bg-slate-800 text-white font-semibold'
                      : 'text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          <div className="divide-y divide-slate-100 overflow-y-auto flex-1">
            {filteredPatients.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">
                No patients match current criteria.
              </div>
            ) : (
              filteredPatients.map((patient) => {
                const isSelected = activePatient?.id === patient.id;
                return (
                  <div
                    key={patient.id}
                    onClick={() => {
                      setSelectedPatientId(patient.id);
                      logAuditEvent('READ', 'Patient Record', patient.id, `Opened medical record for ${patient.firstName} ${patient.lastName}`);
                    }}
                    className={`p-3 cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-blue-50/70 border-l-3 border-blue-600'
                        : 'hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="text-xs font-bold text-slate-800">
                          {patient.firstName} {patient.lastName}
                        </h4>
                        <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                          {patient.id} • {patient.age}y {patient.gender} • {patient.bloodGroup}
                        </div>
                      </div>
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                          patient.status === 'Emergency'
                            ? 'bg-red-100 text-red-700'
                            : patient.status === 'Inpatient'
                            ? 'bg-blue-100 text-blue-700'
                            : patient.status === 'Outpatient'
                            ? 'bg-emerald-100 text-emerald-700'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {patient.status}
                      </span>
                    </div>

                    <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
                      <span className="truncate pr-2 font-medium">
                        {patient.wardOrRoom || patient.primaryPhysicianName}
                      </span>
                      <span className="font-mono text-[10px] text-slate-400">
                        {patient.updatedAt?.split('T')[0]}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Col: Comprehensive EMR View (8 cols) */}
        <div className="lg:col-span-8 bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[750px]">
          {activePatient ? (
            <>
              {/* Patient Banner */}
              <div className="p-4 border-b border-slate-200 bg-slate-50/75 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-full bg-blue-600 text-white font-bold text-sm flex items-center justify-center">
                    {activePatient.firstName[0]}
                    {activePatient.lastName[0]}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-sm font-bold text-slate-800">
                        {activePatient.firstName} {activePatient.lastName}
                      </h2>
                      <span className="text-xs font-mono font-bold text-blue-700 bg-blue-100 px-1.5 py-0.5 rounded">
                        {activePatient.id}
                      </span>
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-200 text-slate-700 font-mono">
                        Blood: {activePatient.bloodGroup}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 flex flex-wrap items-center gap-3 mt-1">
                      <span>DOB: {activePatient.dob} ({activePatient.age} yrs)</span>
                      <span>Physician: {activePatient.primaryPhysicianName}</span>
                      <span>Location: {activePatient.wardOrRoom || 'Outpatient Clinic'}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {activePatient.status !== 'Discharged' && (
                    <button
                      onClick={() => {
                        if (window.confirm(`Discharge patient ${activePatient.firstName} ${activePatient.lastName}?`)) {
                          dischargePatient(activePatient.id);
                        }
                      }}
                      className="px-2.5 py-1.5 border border-slate-300 hover:bg-slate-100 text-slate-700 rounded text-xs font-medium transition"
                    >
                      Discharge Patient
                    </button>
                  )}
                </div>
              </div>

              {/* Sub-Tabs Navigation */}
              <div className="flex items-center gap-2 px-4 border-b border-slate-200 bg-white text-xs">
                {[
                  { id: 'vitals', label: 'Telemetry & Vitals', icon: Activity, count: activePatient.vitals.length },
                  { id: 'notes', label: 'Clinical Encounters', icon: FileText, count: activePatient.clinicalNotes.length },
                  { id: 'meds', label: 'Medications & Rx', icon: Pill, count: activePatient.medications.length },
                  { id: 'labs', label: 'Lab & Diagnostics', icon: FlaskConical, count: activePatient.labResults.length },
                  { id: 'insurance', label: 'Demographics & Policy', icon: ShieldCheck, count: null },
                ].map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeEMRTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveEMRTab(tab.id as typeof activeEMRTab)}
                      className={`py-2.5 px-2 border-b-2 font-medium flex items-center gap-1.5 transition ${
                        isActive
                          ? 'border-blue-600 text-blue-600 font-bold'
                          : 'border-transparent text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{tab.label}</span>
                      {tab.count !== null && (
                        <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded font-mono">
                          {tab.count}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Content Panel Area */}
              <div className="p-4 overflow-y-auto flex-1 space-y-4">
                {/* TAB 1: VITALS */}
                {activeEMRTab === 'vitals' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                        Physiological Telemetry & Vitals History
                      </h3>
                      <button
                        onClick={() => setShowVitalsModal(true)}
                        className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded text-xs flex items-center gap-1"
                      >
                        <Plus className="w-3 h-3" /> Record Vitals
                      </button>
                    </div>

                    {/* Latest Vitals Snapshot Cards */}
                    {activePatient.vitals.length > 0 ? (
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
                        <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                          <span className="text-[10px] font-bold uppercase text-slate-500 block">Heart Rate</span>
                          <span className="text-lg font-bold text-slate-800 font-mono">
                            {activePatient.vitals[0].heartRate} <span className="text-xs font-normal text-slate-500">bpm</span>
                          </span>
                        </div>
                        <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                          <span className="text-[10px] font-bold uppercase text-slate-500 block">Blood Pressure</span>
                          <span className="text-lg font-bold text-slate-800 font-mono">
                            {activePatient.vitals[0].bloodPressureSys}/{activePatient.vitals[0].bloodPressureDia}{' '}
                            <span className="text-xs font-normal text-slate-500">mmHg</span>
                          </span>
                        </div>
                        <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                          <span className="text-[10px] font-bold uppercase text-slate-500 block">Pulse Oximetry</span>
                          <span className="text-lg font-bold text-slate-800 font-mono">
                            {activePatient.vitals[0].spO2}%
                          </span>
                        </div>
                        <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                          <span className="text-[10px] font-bold uppercase text-slate-500 block">Body Temp</span>
                          <span className="text-lg font-bold text-slate-800 font-mono">
                            {activePatient.vitals[0].temperature}°F
                          </span>
                        </div>
                        <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                          <span className="text-[10px] font-bold uppercase text-slate-500 block">Respiration</span>
                          <span className="text-lg font-bold text-slate-800 font-mono">
                            {activePatient.vitals[0].respiratoryRate}{' '}
                            <span className="text-xs font-normal text-slate-500">bpm</span>
                          </span>
                        </div>
                      </div>
                    ) : (
                      <div className="p-4 text-center text-xs text-slate-400 bg-slate-50 rounded border border-dashed border-slate-200">
                        No vitals logged yet for this admission.
                      </div>
                    )}

                    {/* Vitals History Table */}
                    <div className="border border-slate-200 rounded overflow-hidden">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-50 border-b border-slate-200 text-[10px] uppercase font-bold text-slate-500">
                          <tr>
                            <th className="p-2">Timestamp</th>
                            <th className="p-2">HR</th>
                            <th className="p-2">BP (Sys/Dia)</th>
                            <th className="p-2">SpO2</th>
                            <th className="p-2">Temp</th>
                            <th className="p-2">RR</th>
                            <th className="p-2">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 font-mono">
                          {activePatient.vitals.map((v, i) => (
                            <tr key={i} className="hover:bg-slate-50">
                              <td className="p-2 text-slate-600">{new Date(v.recordedAt).toLocaleString()}</td>
                              <td className="p-2 font-bold text-slate-800">{v.heartRate} bpm</td>
                              <td className="p-2 text-slate-800">{v.bloodPressureSys}/{v.bloodPressureDia}</td>
                              <td className="p-2 text-slate-800">{v.spO2}%</td>
                              <td className="p-2 text-slate-800">{v.temperature}°F</td>
                              <td className="p-2 text-slate-800">{v.respiratoryRate}/min</td>
                              <td className="p-2">
                                <span className={`px-1.5 py-0.5 rounded text-[10px] font-sans font-bold ${
                                  v.spO2 < 92 || v.bloodPressureSys > 150 ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-700'
                                }`}>
                                  {v.spO2 < 92 || v.bloodPressureSys > 150 ? 'Critical' : 'Stable'}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* TAB 2: CLINICAL NOTES */}
                {activeEMRTab === 'notes' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                        Doctor Consultations & Progress Notes
                      </h3>
                      <button
                        onClick={() => setShowNoteModal(true)}
                        className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded text-xs flex items-center gap-1"
                      >
                        <Plus className="w-3 h-3" /> Add Clinical Encounter
                      </button>
                    </div>

                    <div className="space-y-3">
                      {activePatient.clinicalNotes.length === 0 ? (
                        <div className="p-6 text-center text-xs text-slate-400 bg-slate-50 rounded">
                          No physician encounter notes recorded.
                        </div>
                      ) : (
                        activePatient.clinicalNotes.map((note) => (
                          <div key={note.id} className="p-3.5 rounded border border-slate-200 bg-white shadow-2xs space-y-2">
                            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                              <div>
                                <span className="font-bold text-xs text-slate-800">{note.doctorName}</span>
                                <span className="text-[11px] text-slate-500 ml-2">({note.doctorSpecialty})</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="text-[10px] font-mono bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded font-bold">
                                  {note.diagnosisCode}
                                </span>
                                <span className="text-[11px] text-slate-400">{note.date}</span>
                              </div>
                            </div>

                            <div className="text-xs space-y-1">
                              <div>
                                <span className="font-semibold text-slate-700">Chief Complaint: </span>
                                <span className="text-slate-600">{note.chiefComplaint}</span>
                              </div>
                              <div>
                                <span className="font-semibold text-slate-700">Assessment: </span>
                                <span className="text-slate-600">{note.assessment}</span>
                              </div>
                              <div>
                                <span className="font-semibold text-slate-700">Plan: </span>
                                <span className="text-slate-600">{note.treatmentPlan}</span>
                              </div>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}

                {/* TAB 3: MEDICATIONS */}
                {activeEMRTab === 'meds' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                        Active Prescriptions & Medication Chart
                      </h3>
                      <button
                        onClick={() => setShowMedModal(true)}
                        className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded text-xs flex items-center gap-1"
                      >
                        <Plus className="w-3 h-3" /> Prescribe Medication
                      </button>
                    </div>

                    <div className="border border-slate-200 rounded overflow-hidden">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-50 border-b border-slate-200 text-[10px] uppercase font-bold text-slate-500">
                          <tr>
                            <th className="p-2.5">Medication Name</th>
                            <th className="p-2.5">Dosage</th>
                            <th className="p-2.5">Frequency & Route</th>
                            <th className="p-2.5">Prescriber</th>
                            <th className="p-2.5">Start Date</th>
                            <th className="p-2.5">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {activePatient.medications.map((m) => (
                            <tr key={m.id} className="hover:bg-slate-50">
                              <td className="p-2.5 font-bold text-slate-800">{m.name}</td>
                              <td className="p-2.5 font-mono text-slate-700">{m.dosage}</td>
                              <td className="p-2.5 text-slate-600">{m.frequency} ({m.route})</td>
                              <td className="p-2.5 text-slate-600">{m.prescribedBy}</td>
                              <td className="p-2.5 font-mono text-slate-500">{m.startDate}</td>
                              <td className="p-2.5">
                                <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                  m.status === 'Active' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'
                                }`}>
                                  {m.status}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* TAB 4: LABS */}
                {activeEMRTab === 'labs' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                        Diagnostic Orders & Verified Lab Findings
                      </h3>
                      <button
                        onClick={() => setShowLabModal(true)}
                        className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded text-xs flex items-center gap-1"
                      >
                        <Plus className="w-3 h-3" /> Order / Enter Lab
                      </button>
                    </div>

                    <div className="border border-slate-200 rounded overflow-hidden">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-50 border-b border-slate-200 text-[10px] uppercase font-bold text-slate-500">
                          <tr>
                            <th className="p-2.5">Test Name</th>
                            <th className="p-2.5">Category</th>
                            <th className="p-2.5">Result Value</th>
                            <th className="p-2.5">Reference Range</th>
                            <th className="p-2.5">Ordered By</th>
                            <th className="p-2.5">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {activePatient.labResults.map((lab) => (
                            <tr key={lab.id} className="hover:bg-slate-50">
                              <td className="p-2.5 font-semibold text-slate-800">{lab.testName}</td>
                              <td className="p-2.5 text-slate-500">{lab.category}</td>
                              <td className="p-2.5 font-bold text-slate-800">{lab.value}</td>
                              <td className="p-2.5 font-mono text-slate-500 text-[11px]">{lab.referenceRange}</td>
                              <td className="p-2.5 text-slate-600">{lab.orderedBy}</td>
                              <td className="p-2.5">
                                <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                  lab.status === 'Critical'
                                    ? 'bg-red-100 text-red-700'
                                    : lab.status === 'Elevated'
                                    ? 'bg-amber-100 text-amber-700'
                                    : 'bg-emerald-100 text-emerald-700'
                                }`}>
                                  {lab.status}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* TAB 5: DEMOGRAPHICS & INSURANCE */}
                {activeEMRTab === 'insurance' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Demographic Details */}
                      <div className="p-4 bg-slate-50 rounded border border-slate-200 space-y-2.5 text-xs">
                        <h4 className="font-bold uppercase tracking-wider text-slate-700 border-b border-slate-200 pb-1.5">
                          Personal Information & Emergency Contact
                        </h4>
                        <div className="flex items-center gap-2 text-slate-600">
                          <Phone className="w-3.5 h-3.5 text-slate-400" />
                          <span>Phone: {activePatient.phone}</span>
                        </div>
                        <div className="flex items-center gap-2 text-slate-600">
                          <Mail className="w-3.5 h-3.5 text-slate-400" />
                          <span>Email: {activePatient.email}</span>
                        </div>
                        <div className="flex items-center gap-2 text-slate-600">
                          <MapPin className="w-3.5 h-3.5 text-slate-400" />
                          <span>Address: {activePatient.address}</span>
                        </div>
                        <div className="pt-2 border-t border-slate-200">
                          <span className="font-semibold text-slate-700 block">Emergency Contact:</span>
                          <span className="text-slate-600">
                            {activePatient.emergencyContact.name} ({activePatient.emergencyContact.relationship}) - {activePatient.emergencyContact.phone}
                          </span>
                        </div>
                      </div>

                      {/* Insurance Policy */}
                      <div className="p-4 bg-slate-50 rounded border border-slate-200 space-y-2.5 text-xs">
                        <h4 className="font-bold uppercase tracking-wider text-slate-700 border-b border-slate-200 pb-1.5 flex items-center justify-between">
                          <span>Insurance Policy & Coverage</span>
                          <span className="text-[10px] text-emerald-700 bg-emerald-100 font-bold px-1.5 py-0.5 rounded">
                            {activePatient.insurance.status}
                          </span>
                        </h4>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Provider:</span>
                          <span className="font-bold text-slate-800">{activePatient.insurance.provider}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Policy Number:</span>
                          <span className="font-mono text-slate-800">{activePatient.insurance.policyNumber}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Group Number:</span>
                          <span className="font-mono text-slate-800">{activePatient.insurance.groupNumber}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Coverage Percentage:</span>
                          <span className="font-bold text-blue-600">{activePatient.insurance.coveragePercentage}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Copay Amount:</span>
                          <span className="font-bold text-slate-800">${activePatient.insurance.copayAmount.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Expiry Date:</span>
                          <span className="font-mono text-slate-600">{activePatient.insurance.expiryDate}</span>
                        </div>
                      </div>
                    </div>

                    {/* Allergies & Chronic Conditions */}
                    <div className="p-4 bg-white rounded border border-slate-200 space-y-3 text-xs">
                      <div>
                        <h4 className="font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                          Known Drug & Environmental Allergies
                        </h4>
                        <div className="flex flex-wrap gap-1.5">
                          {activePatient.allergies.map((all, i) => (
                            <span
                              key={i}
                              className={`px-2 py-0.5 rounded font-medium text-[11px] ${
                                all.severity === 'Severe'
                                  ? 'bg-red-100 text-red-700 font-bold'
                                  : all.severity === 'Moderate'
                                  ? 'bg-amber-100 text-amber-700'
                                  : 'bg-slate-100 text-slate-600'
                              }`}
                            >
                              {all.allergen} ({all.severity})
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="pt-2 border-t border-slate-100">
                        <h4 className="font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                          Chronic Health Conditions
                        </h4>
                        <div className="flex flex-wrap gap-1.5">
                          {activePatient.chronicConditions.map((cond, i) => (
                            <span key={i} className="px-2 py-0.5 bg-blue-50 text-blue-700 rounded text-[11px] font-medium">
                              {cond}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="p-12 text-center text-slate-400 text-xs">
              Select a patient from the left column to inspect EMR record.
            </div>
          )}
        </div>
      </div>

      {/* Modal: Add Vitals */}
      {showVitalsModal && activePatient && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-md w-full p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h3 className="font-bold text-sm text-slate-800">
                Log Physiological Vitals — {activePatient.firstName} {activePatient.lastName}
              </h3>
              <button onClick={() => setShowVitalsModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>
            <form onSubmit={handleVitalsSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Heart Rate (bpm)</label>
                  <input
                    type="number"
                    value={vitalsForm.heartRate}
                    onChange={(e) => setVitalsForm({ ...vitalsForm, heartRate: Number(e.target.value) })}
                    className="w-full p-2 border border-slate-200 rounded font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">SpO2 Oxygen (%)</label>
                  <input
                    type="number"
                    value={vitalsForm.spO2}
                    onChange={(e) => setVitalsForm({ ...vitalsForm, spO2: Number(e.target.value) })}
                    className="w-full p-2 border border-slate-200 rounded font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">BP Systolic (mmHg)</label>
                  <input
                    type="number"
                    value={vitalsForm.bloodPressureSys}
                    onChange={(e) => setVitalsForm({ ...vitalsForm, bloodPressureSys: Number(e.target.value) })}
                    className="w-full p-2 border border-slate-200 rounded font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">BP Diastolic (mmHg)</label>
                  <input
                    type="number"
                    value={vitalsForm.bloodPressureDia}
                    onChange={(e) => setVitalsForm({ ...vitalsForm, bloodPressureDia: Number(e.target.value) })}
                    className="w-full p-2 border border-slate-200 rounded font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Temperature (°F)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={vitalsForm.temperature}
                    onChange={(e) => setVitalsForm({ ...vitalsForm, temperature: Number(e.target.value) })}
                    className="w-full p-2 border border-slate-200 rounded font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Respiration (bpm)</label>
                  <input
                    type="number"
                    value={vitalsForm.respiratoryRate}
                    onChange={(e) => setVitalsForm({ ...vitalsForm, respiratoryRate: Number(e.target.value) })}
                    className="w-full p-2 border border-slate-200 rounded font-mono"
                    required
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowVitalsModal(false)}
                  className="px-3 py-1.5 border border-slate-300 rounded text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded font-semibold"
                >
                  Save Vitals
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add Clinical Note */}
      {showNoteModal && activePatient && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-lg w-full p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h3 className="font-bold text-sm text-slate-800">
                Record Clinical Note — {activePatient.firstName} {activePatient.lastName}
              </h3>
              <button onClick={() => setShowNoteModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>
            <form onSubmit={handleNoteSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Attending Physician</label>
                  <select
                    value={noteForm.doctorName}
                    onChange={(e) => {
                      const doc = doctors.find((d) => d.name === e.target.value);
                      setNoteForm({
                        ...noteForm,
                        doctorName: e.target.value,
                        doctorSpecialty: doc?.specialty || 'General Medicine',
                      });
                    }}
                    className="w-full p-2 border border-slate-200 rounded text-slate-800"
                  >
                    {doctors.map((d) => (
                      <option key={d.id} value={d.name}>{d.name} ({d.specialty})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Diagnosis Code (ICD-10)</label>
                  <input
                    type="text"
                    value={noteForm.diagnosisCode}
                    onChange={(e) => setNoteForm({ ...noteForm, diagnosisCode: e.target.value })}
                    className="w-full p-2 border border-slate-200 rounded font-mono"
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block text-slate-600 font-medium mb-1">Chief Complaint</label>
                <input
                  type="text"
                  placeholder="e.g. Sharp epigastric pain radiating to left shoulder"
                  value={noteForm.chiefComplaint}
                  onChange={(e) => setNoteForm({ ...noteForm, chiefComplaint: e.target.value })}
                  className="w-full p-2 border border-slate-200 rounded"
                  required
                />
              </div>
              <div>
                <label className="block text-slate-600 font-medium mb-1">Clinical Assessment</label>
                <textarea
                  rows={2}
                  placeholder="Objective clinical examination and findings"
                  value={noteForm.assessment}
                  onChange={(e) => setNoteForm({ ...noteForm, assessment: e.target.value })}
                  className="w-full p-2 border border-slate-200 rounded"
                  required
                />
              </div>
              <div>
                <label className="block text-slate-600 font-medium mb-1">Treatment Plan</label>
                <textarea
                  rows={2}
                  placeholder="Prescriptions, telemetry monitoring, dietary restrictions"
                  value={noteForm.treatmentPlan}
                  onChange={(e) => setNoteForm({ ...noteForm, treatmentPlan: e.target.value })}
                  className="w-full p-2 border border-slate-200 rounded"
                  required
                />
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowNoteModal(false)}
                  className="px-3 py-1.5 border border-slate-300 rounded text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded font-semibold"
                >
                  Sign & Save Note
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Prescribe Medication */}
      {showMedModal && activePatient && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-md w-full p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h3 className="font-bold text-sm text-slate-800">
                Prescribe Medication — {activePatient.firstName} {activePatient.lastName}
              </h3>
              <button onClick={() => setShowMedModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>
            <form onSubmit={handleMedSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-600 font-medium mb-1">Medication Name</label>
                <input
                  type="text"
                  placeholder="e.g. Amoxicillin Trihydrate"
                  value={medForm.name}
                  onChange={(e) => setMedForm({ ...medForm, name: e.target.value })}
                  className="w-full p-2 border border-slate-200 rounded font-semibold text-slate-800"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Dosage</label>
                  <input
                    type="text"
                    value={medForm.dosage}
                    onChange={(e) => setMedForm({ ...medForm, dosage: e.target.value })}
                    className="w-full p-2 border border-slate-200 rounded font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Administration Route</label>
                  <select
                    value={medForm.route}
                    onChange={(e) => setMedForm({ ...medForm, route: e.target.value })}
                    className="w-full p-2 border border-slate-200 rounded"
                  >
                    <option value="Oral">Oral (PO)</option>
                    <option value="IV Infusion">IV Infusion</option>
                    <option value="Subcutaneous">Subcutaneous</option>
                    <option value="Inhalation">Inhalation</option>
                    <option value="Topical">Topical</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-slate-600 font-medium mb-1">Frequency / Regimen</label>
                <input
                  type="text"
                  value={medForm.frequency}
                  onChange={(e) => setMedForm({ ...medForm, frequency: e.target.value })}
                  className="w-full p-2 border border-slate-200 rounded"
                  required
                />
              </div>
              <div>
                <label className="block text-slate-600 font-medium mb-1">Prescribed By</label>
                <select
                  value={medForm.prescribedBy}
                  onChange={(e) => setMedForm({ ...medForm, prescribedBy: e.target.value })}
                  className="w-full p-2 border border-slate-200 rounded"
                >
                  {doctors.map((d) => (
                    <option key={d.id} value={d.name}>{d.name}</option>
                  ))}
                </select>
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowMedModal(false)}
                  className="px-3 py-1.5 border border-slate-300 rounded text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded font-semibold"
                >
                  Confirm Rx
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add Lab Test */}
      {showLabModal && activePatient && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-md w-full p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h3 className="font-bold text-sm text-slate-800">
                Order Diagnostic Test — {activePatient.firstName} {activePatient.lastName}
              </h3>
              <button onClick={() => setShowLabModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>
            <form onSubmit={handleLabSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-600 font-medium mb-1">Test Name</label>
                <input
                  type="text"
                  placeholder="e.g. Cardiac Troponin I (High Sensitivity)"
                  value={labForm.testName}
                  onChange={(e) => setLabForm({ ...labForm, testName: e.target.value })}
                  className="w-full p-2 border border-slate-200 rounded font-semibold text-slate-800"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Diagnostic Category</label>
                  <select
                    value={labForm.category}
                    onChange={(e) => setLabForm({ ...labForm, category: e.target.value as LabResult['category'] })}
                    className="w-full p-2 border border-slate-200 rounded"
                  >
                    <option value="Hematology">Hematology</option>
                    <option value="Biochemistry">Biochemistry</option>
                    <option value="Cardiology">Cardiology</option>
                    <option value="Radiology">Radiology</option>
                    <option value="Pathology">Pathology</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Status</label>
                  <select
                    value={labForm.status}
                    onChange={(e) => setLabForm({ ...labForm, status: e.target.value as LabResult['status'] })}
                    className="w-full p-2 border border-slate-200 rounded"
                  >
                    <option value="Normal">Normal</option>
                    <option value="Elevated">Elevated</option>
                    <option value="Critical">Critical</option>
                    <option value="Pending">Pending Analysis</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-slate-600 font-medium mb-1">Measured Value</label>
                <input
                  type="text"
                  placeholder="e.g. 0.04 ng/mL"
                  value={labForm.value}
                  onChange={(e) => setLabForm({ ...labForm, value: e.target.value })}
                  className="w-full p-2 border border-slate-200 rounded font-mono"
                  required
                />
              </div>
              <div>
                <label className="block text-slate-600 font-medium mb-1">Reference Range</label>
                <input
                  type="text"
                  placeholder="e.g. < 0.014 ng/mL"
                  value={labForm.referenceRange}
                  onChange={(e) => setLabForm({ ...labForm, referenceRange: e.target.value })}
                  className="w-full p-2 border border-slate-200 rounded font-mono"
                  required
                />
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowLabModal(false)}
                  className="px-3 py-1.5 border border-slate-300 rounded text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded font-semibold"
                >
                  Record Diagnostic Findings
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
