import React, { useState } from 'react';
import {
  CreditCard,
  Plus,
  Search,
  DollarSign,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  FileText,
  Printer,
  ChevronRight,
  Receipt,
  Download,
  Lock,
  ArrowUpRight,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { Invoice, PaymentStatus } from '../types';

interface BillingClaimsViewProps {
  onOpenNewInvoice: () => void;
  onOpenPaymentModal: (invoice: Invoice) => void;
  onSelectPatient: (id: string) => void;
}

export const BillingClaimsView: React.FC<BillingClaimsViewProps> = ({
  onOpenNewInvoice,
  onOpenPaymentModal,
  onSelectPatient,
}) => {
  const { invoices, setActiveTab } = useHospital();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);

  // Financial calculations
  const totalBilled = invoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
  const totalCollected = invoices.reduce((sum, inv) => sum + inv.paidAmount, 0);
  const totalOutstanding = invoices.reduce(
    (sum, inv) => sum + (inv.totalAmount - inv.paidAmount),
    0
  );
  const insuranceCoveredTotal = invoices.reduce(
    (sum, inv) => sum + inv.insuranceCoveredAmount,
    0
  );

  const filteredInvoices = invoices.filter((inv) => {
    const matchesSearch =
      inv.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inv.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inv.patientId.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;
    if (statusFilter !== 'all' && inv.status.toLowerCase() !== statusFilter.toLowerCase())
      return false;
    return true;
  });

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-7xl mx-auto">
      {/* Financial Overview Cards (High Density) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg shadow-sm text-white">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
              Total Billed (MTD)
            </span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-bold font-mono text-white mt-1">
            ${totalBilled.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">{invoices.length} invoices generated</div>
        </div>

        <div className="bg-white border border-slate-200 p-3.5 rounded-lg shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
              Settled / Collected
            </span>
            <span className="text-xs font-semibold text-emerald-600 flex items-center">
              <ArrowUpRight className="w-3 h-3 mr-0.5" /> 84%
            </span>
          </div>
          <div className="text-xl font-bold font-mono text-emerald-600 mt-1">
            ${totalCollected.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Direct tokenized gateway payments</div>
        </div>

        <div className="bg-white border border-slate-200 p-3.5 rounded-lg shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
              Outstanding Copay / Patient
            </span>
            <AlertCircle className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-xl font-bold font-mono text-amber-600 mt-1">
            ${totalOutstanding.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            {invoices.filter((i) => i.status === 'Pending').length} pending settlement
          </div>
        </div>

        <div className="bg-white border border-slate-200 p-3.5 rounded-lg shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
              Insurance Adjudicated
            </span>
            <ShieldCheck className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-xl font-bold font-mono text-blue-600 mt-1">
            ${insuranceCoveredTotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Auto-processed claims</div>
        </div>
      </div>

      {/* Action and Search Bar */}
      <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          {/* Search bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              id="billing-search-input"
              placeholder="Search invoice #, patient name, ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-56 sm:w-64 bg-slate-50 border border-slate-200 rounded-md py-1.5 pl-8 pr-3 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 text-slate-800 placeholder-slate-400"
            />
          </div>

          {/* Status Filter */}
          <select
            id="billing-status-filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-md py-1.5 px-2.5 text-xs text-slate-700 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          >
            <option value="all">All Statuses</option>
            <option value="Pending">Pending Payment</option>
            <option value="Paid">Settled (Paid)</option>
            <option value="Partially Paid">Partially Paid</option>
            <option value="Insurance Processing">Insurance Processing</option>
          </select>

          <div className="hidden xl:flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-100 border border-slate-200 text-[11px] text-slate-600 font-mono">
            <Lock className="w-3 h-3 text-emerald-600" />
            <span>PCI-DSS TLS 1.3 / AES-256 Tokenization</span>
          </div>
        </div>

        <button
          id="create-invoice-button"
          onClick={onOpenNewInvoice}
          className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition shadow-sm self-start md:self-auto shrink-0"
        >
          <Plus className="w-3.5 h-3.5" /> Generate Invoice
        </button>
      </div>

      {/* Main Ledger Table & Receipt Drawer (if selected) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Invoices Table */}
        <div
          className={`bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden flex flex-col ${
            selectedInvoice ? 'lg:col-span-7' : 'lg:col-span-12'
          }`}
        >
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-100/80 text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                  <th className="py-2.5 px-3">Invoice ID</th>
                  <th className="py-2.5 px-3">Patient Record</th>
                  <th className="py-2.5 px-3">Date / Due</th>
                  <th className="py-2.5 px-3">Total Amount</th>
                  <th className="py-2.5 px-3">Insurance Split</th>
                  <th className="py-2.5 px-3">Balance Due</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Payment Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-normal">
                {filteredInvoices.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-slate-400">
                      No invoices found matching criteria.
                    </td>
                  </tr>
                ) : (
                  filteredInvoices.map((inv) => {
                    const isSelected = selectedInvoice?.id === inv.id;
                    const balance = inv.totalAmount - inv.paidAmount;

                    return (
                      <tr
                        key={inv.id}
                        onClick={() => setSelectedInvoice(inv)}
                        className={`hover:bg-blue-50/40 cursor-pointer transition-colors ${
                          isSelected ? 'bg-blue-50 border-l-4 border-l-blue-600' : ''
                        }`}
                      >
                        <td className="py-2.5 px-3 font-mono font-bold text-slate-800 whitespace-nowrap">
                          {inv.id}
                        </td>

                        <td className="py-2.5 px-3">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectPatient(inv.patientId);
                              setActiveTab('patients');
                            }}
                            className="font-semibold text-slate-800 hover:text-blue-600 text-left block truncate max-w-[130px]"
                          >
                            {inv.patientName}
                          </button>
                          <span className="text-[10px] font-mono text-slate-400">{inv.patientId}</span>
                        </td>

                        <td className="py-2.5 px-3 whitespace-nowrap font-mono text-slate-600">
                          <div>{inv.issueDate}</div>
                          <div className="text-[10px] text-slate-400">Due: {inv.dueDate}</div>
                        </td>

                        <td className="py-2.5 px-3 font-mono font-bold text-slate-800 whitespace-nowrap">
                          ${inv.totalAmount.toFixed(2)}
                        </td>

                        <td className="py-2.5 px-3 whitespace-nowrap font-mono text-[11px] text-slate-500">
                          <div>Ins: ${inv.insuranceCoveredAmount.toFixed(2)}</div>
                          <div className="text-[10px] text-slate-400">Copay: ${inv.copayAmount.toFixed(2)}</div>
                        </td>

                        <td className="py-2.5 px-3 font-mono font-bold whitespace-nowrap">
                          <span className={balance > 0 ? 'text-amber-600' : 'text-emerald-600'}>
                            ${balance.toFixed(2)}
                          </span>
                        </td>

                        <td className="py-2.5 px-3 whitespace-nowrap">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                              inv.status === 'Paid'
                                ? 'bg-emerald-100 text-emerald-800'
                                : inv.status === 'Pending'
                                ? 'bg-amber-100 text-amber-800'
                                : inv.status === 'Partially Paid'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-purple-100 text-purple-800'
                            }`}
                          >
                            {inv.status}
                          </span>
                        </td>

                        <td className="py-2.5 px-3 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-1.5">
                            {balance > 0 ? (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onOpenPaymentModal(inv);
                                }}
                                className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded text-[11px] font-semibold flex items-center gap-1 transition shadow-sm"
                              >
                                <CreditCard className="w-3 h-3" /> Collect
                              </button>
                            ) : (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedInvoice(inv);
                                }}
                                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[11px] font-semibold flex items-center gap-1"
                              >
                                <Receipt className="w-3 h-3" /> Receipt
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          <div className="p-2.5 bg-slate-50 border-t border-slate-200 text-[11px] text-slate-500 flex items-center justify-between">
            <span>{filteredInvoices.length} invoices indexed</span>
            <span className="font-mono text-[10px] text-slate-400">HIPAA 837 / 835 claims standard</span>
          </div>
        </div>

        {/* Selected Invoice Receipt View */}
        {selectedInvoice && (
          <div className="lg:col-span-5 bg-white rounded-lg border border-slate-200 shadow-sm flex flex-col overflow-hidden">
            {/* Header */}
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                  Medical Billing Statement
                </div>
                <h3 className="text-sm font-bold text-white font-mono mt-0.5">
                  {selectedInvoice.id}
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="p-1.5 text-slate-300 hover:text-white rounded hover:bg-slate-800 transition"
                  title="Print billing statement"
                >
                  <Printer className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setSelectedInvoice(null)}
                  className="text-xs text-slate-400 hover:text-white px-1.5 py-1"
                >
                  Close
                </button>
              </div>
            </div>

            {/* Bill Details */}
            <div className="p-4 space-y-4 text-xs flex-1 overflow-y-auto">
              <div className="flex justify-between items-start pb-3 border-b border-slate-100">
                <div>
                  <div className="font-bold text-slate-800 text-sm">{selectedInvoice.patientName}</div>
                  <div className="text-[11px] text-slate-500 font-mono">Patient ID: {selectedInvoice.patientId}</div>
                  <div className="text-[11px] text-slate-500">Contact: {selectedInvoice.patientPhone}</div>
                </div>
                <div className="text-right font-mono text-[11px] text-slate-500">
                  <div>Issued: {selectedInvoice.issueDate}</div>
                  <div>Due: {selectedInvoice.dueDate}</div>
                  <div className="mt-1">
                    <span
                      className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                        selectedInvoice.status === 'Paid'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {selectedInvoice.status}
                    </span>
                  </div>
                </div>
              </div>

              {/* Line Items Table */}
              <div>
                <div className="text-[10px] font-bold uppercase text-slate-400 tracking-wider mb-1.5">
                  Itemized Hospital Services
                </div>
                <div className="divide-y divide-slate-100 border border-slate-100 rounded">
                  {selectedInvoice.items.map((item) => (
                    <div key={item.id} className="p-2 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-semibold text-slate-800">{item.description}</div>
                        <div className="text-[10px] text-slate-400">
                          {item.category} • Qty: {item.quantity} × ${item.unitCost.toFixed(2)}
                        </div>
                      </div>
                      <div className="font-mono font-bold text-slate-700">
                        ${item.amount.toFixed(2)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Financial Calculation Summary */}
              <div className="bg-slate-50 p-3 rounded-md space-y-1.5 text-xs font-mono">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal</span>
                  <span>${selectedInvoice.subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Tax (Medical Exemption / Surcharge)</span>
                  <span>${selectedInvoice.tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-blue-600">
                  <span>Insurance Payer Contribution</span>
                  <span>-${selectedInvoice.insuranceCoveredAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Patient Copay Portion</span>
                  <span>${selectedInvoice.copayAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-emerald-600 border-t border-slate-200 pt-1">
                  <span>Amount Paid / Settled</span>
                  <span>${selectedInvoice.paidAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-900 font-bold text-sm border-t border-slate-200 pt-1">
                  <span>Net Balance Outstanding</span>
                  <span>${(selectedInvoice.totalAmount - selectedInvoice.paidAmount).toFixed(2)}</span>
                </div>
              </div>

              {/* Payment History / Transactions */}
              {selectedInvoice.transactions.length > 0 && (
                <div>
                  <div className="text-[10px] font-bold uppercase text-slate-400 tracking-wider mb-1.5">
                    Settled Transactions Log
                  </div>
                  <div className="space-y-1.5">
                    {selectedInvoice.transactions.map((tx, idx) => (
                      <div
                        key={idx}
                        className="p-2 bg-emerald-50/70 border border-emerald-200 rounded text-xs flex items-center justify-between"
                      >
                        <div>
                          <div className="font-bold text-emerald-900">
                            ${tx.amountPaid.toFixed(2)} via {tx.method}
                          </div>
                          <div className="text-[10px] font-mono text-emerald-700">
                            Auth: {tx.authCode} • TX: {tx.transactionId}
                          </div>
                        </div>
                        <span className="text-[10px] text-emerald-800 font-mono">
                          {new Date(tx.timestamp).toLocaleDateString()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Action Button */}
              {selectedInvoice.totalAmount - selectedInvoice.paidAmount > 0 && (
                <button
                  onClick={() => onOpenPaymentModal(selectedInvoice)}
                  className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold flex items-center justify-center gap-1.5 transition shadow-sm"
                >
                  <CreditCard className="w-3.5 h-3.5" /> Open Secure Payment Gateway
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
