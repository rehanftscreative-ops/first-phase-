import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  Plus,
  Search,
  CheckCircle2,
  PhoneCall,
  UserCheck,
  AlertTriangle,
  Stethoscope,
  Filter,
  Users,
  Video,
  ExternalLink,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { AppointmentStatus, AppointmentPriority, Appointment } from '../types';
import { TelehealthView } from './TelehealthView';
import { TelehealthVideoModal } from './TelehealthVideoModal';

interface AppointmentsManagerProps {
  onOpenNewAppointment: () => void;
  onSelectPatient: (id: string) => void;
}

export const AppointmentsManager: React.FC<AppointmentsManagerProps> = ({
  onOpenNewAppointment,
  onSelectPatient,
}) => {
  const {
    appointments,
    doctors,
    updateAppointmentStatus,
    callNextAppointment,
  } = useHospital();

  const [activeView, setActiveView] = useState<'clinic' | 'telehealth'>('clinic');
  const [activeVideoModalApt, setActiveVideoModalApt] = useState<Appointment | null>(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');

  const telehealthAppointments = appointments.filter(
    (apt) =>
      apt.isTelehealth ||
      apt.type.toLowerCase().includes('telehealth') ||
      apt.type.toLowerCase().includes('remote') ||
      apt.roomNumber.toLowerCase().includes('virtual')
  );

  const telehealthWaitingCount = telehealthAppointments.filter(
    (a) =>
      a.status === 'Checked-In' ||
      a.telehealthDetails?.patientStatus === 'Waiting in Room'
  ).length;

  const inClinicAppointments = appointments.filter(
    (a) =>
      !a.isTelehealth &&
      !a.type.toLowerCase().includes('telehealth') &&
      !a.type.toLowerCase().includes('remote')
  );

  const filteredAppointments = appointments.filter((apt) => {
    const matchesSearch =
      apt.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      apt.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      apt.doctorName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDoctor = selectedDoctorId === 'all' || apt.doctorId === selectedDoctorId;
    const matchesStatus = statusFilter === 'all' || apt.status.toLowerCase() === statusFilter.toLowerCase();
    const matchesPriority = priorityFilter === 'all' || apt.priority.toLowerCase() === priorityFilter.toLowerCase();
    return matchesSearch && matchesDoctor && matchesStatus && matchesPriority;
  });

  const waitingQueue = inClinicAppointments.filter(
    (a) => a.status === 'Checked-In' || a.status === 'Scheduled'
  );

  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto space-y-4">
      {/* Header Bar with Sub-View Switcher */}
      <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              {activeView === 'telehealth' ? (
                <Video className="w-5 h-5 text-emerald-600" />
              ) : (
                <Calendar className="w-5 h-5 text-blue-600" />
              )}
              <h1 className="text-base lg:text-lg font-bold text-slate-800 tracking-tight">
                {activeView === 'telehealth'
                  ? 'Telehealth & Remote Video Consultations'
                  : 'Appointment Scheduling & Live Patient Queue'}
              </h1>
              <span
                className={`px-2 py-0.5 text-[10px] font-bold rounded ${
                  activeView === 'telehealth'
                    ? 'bg-purple-100 text-purple-800'
                    : 'bg-emerald-100 text-emerald-800'
                }`}
              >
                {activeView === 'telehealth' ? 'HIPAA WEBRTC BRIDGE' : 'REAL-TIME QUEUE'}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {activeView === 'telehealth'
                ? 'Manage upcoming remote video sessions, virtual waiting room lobbies, and initiate live consultations.'
                : 'Manage physician appointment slots, real-time wait times, check-ins, and consultation turnover.'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            {activeView === 'clinic' && (
              <button
                onClick={() => callNextAppointment(selectedDoctorId !== 'all' ? selectedDoctorId : undefined)}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-semibold flex items-center gap-1.5 shadow-sm transition"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>Call Next in Queue</span>
              </button>
            )}
            <button
              onClick={onOpenNewAppointment}
              className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-semibold flex items-center gap-1.5 shadow-sm transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{activeView === 'telehealth' ? 'Book Telehealth Slot' : 'Book Appointment'}</span>
            </button>
          </div>
        </div>

        {/* View Switcher Tabs: In-Clinic Queue vs Dedicated Telehealth View */}
        <div className="flex items-center gap-2 pt-2 border-t border-slate-100 text-xs">
          <button
            onClick={() => setActiveView('clinic')}
            className={`px-4 py-2 rounded-lg font-semibold flex items-center gap-2 transition ${
              activeView === 'clinic'
                ? 'bg-blue-50 text-blue-700 border border-blue-200 shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>In-Clinic Queue</span>
            <span
              className={`px-2 py-0.5 rounded-full text-[10px] font-mono ${
                activeView === 'clinic'
                  ? 'bg-blue-200/80 text-blue-900 font-bold'
                  : 'bg-slate-200 text-slate-700'
              }`}
            >
              {inClinicAppointments.length}
            </span>
          </button>

          <button
            onClick={() => setActiveView('telehealth')}
            className={`px-4 py-2 rounded-lg font-semibold flex items-center gap-2 transition relative ${
              activeView === 'telehealth'
                ? 'bg-emerald-50 text-emerald-800 border border-emerald-300 shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Video className="w-4 h-4 text-emerald-600" />
            <span>Telehealth</span>
            <span
              className={`px-2 py-0.5 rounded-full text-[10px] font-mono ${
                activeView === 'telehealth'
                  ? 'bg-emerald-200 text-emerald-900 font-bold'
                  : 'bg-slate-200 text-slate-700'
              }`}
            >
              {telehealthAppointments.length}
            </span>

            {telehealthWaitingCount > 0 && (
              <span className="flex items-center gap-1 text-[10px] bg-emerald-600 text-white font-bold px-1.5 py-0.5 rounded-full animate-pulse shadow-xs">
                <span className="w-1.5 h-1.5 rounded-full bg-white"></span>
                <span>{telehealthWaitingCount} in lobby</span>
              </span>
            )}
          </button>
        </div>
      </div>

      {/* RENDER DEDICATED TELEHEALTH VIEW */}
      {activeView === 'telehealth' ? (
        <TelehealthView
          onOpenNewAppointment={onOpenNewAppointment}
          onSelectPatient={onSelectPatient}
        />
      ) : (
        /* RENDER IN-CLINIC APPOINTMENT QUEUE */
        <>

      {/* Queue Velocity Metrics Ribbon */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Currently Waiting</span>
          <div className="text-xl font-bold text-slate-800 font-mono mt-1">{waitingQueue.length} Patients</div>
          <span className="text-[11px] text-slate-500">In waiting lounge or checked-in</span>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">In Active Consultation</span>
          <div className="text-xl font-bold text-blue-600 font-mono mt-1">
            {appointments.filter((a) => a.status === 'In Consultation').length} Consults
          </div>
          <span className="text-[11px] text-slate-500">Physicians with patients</span>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Avg Slot Wait Time</span>
          <div className="text-xl font-bold text-emerald-600 font-mono mt-1">11.4 mins</div>
          <span className="text-[11px] text-slate-500">Check-in to physician call</span>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Completed Sessions</span>
          <div className="text-xl font-bold text-slate-700 font-mono mt-1">
            {appointments.filter((a) => a.status === 'Completed').length}
          </div>
          <span className="text-[11px] text-slate-500">Consultations finished today</span>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
          <div className="relative flex-1 min-w-[180px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Filter by patient, ID, or doctor..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 border border-slate-200 rounded text-xs focus:outline-none focus:border-blue-500"
            />
          </div>

          <select
            value={selectedDoctorId}
            onChange={(e) => setSelectedDoctorId(e.target.value)}
            className="p-1.5 border border-slate-200 rounded text-slate-700 bg-white"
          >
            <option value="all">All Attending Physicians</option>
            {doctors.map((d) => (
              <option key={d.id} value={d.id}>{d.name} ({d.specialty})</option>
            ))}
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="p-1.5 border border-slate-200 rounded text-slate-700 bg-white"
          >
            <option value="all">All Statuses</option>
            <option value="Scheduled">Scheduled</option>
            <option value="Checked-In">Checked In</option>
            <option value="In Consultation">In Consultation</option>
            <option value="Completed">Completed</option>
            <option value="Cancelled">Cancelled</option>
          </select>

          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="p-1.5 border border-slate-200 rounded text-slate-700 bg-white"
          >
            <option value="all">All Priorities</option>
            <option value="Normal">Normal</option>
            <option value="Urgent">Urgent</option>
            <option value="Emergency">Emergency</option>
          </select>
        </div>

        <span className="text-[11px] text-slate-500 font-mono">
          Showing {filteredAppointments.length} of {appointments.length} appointments
        </span>
      </div>

      {/* Main Appointments Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-[10px] uppercase font-bold text-slate-500">
              <tr>
                <th className="py-2.5 px-3">Queue #</th>
                <th className="py-2.5 px-3">Slot & Date</th>
                <th className="py-2.5 px-3">Patient Record</th>
                <th className="py-2.5 px-3">Consultation Reason</th>
                <th className="py-2.5 px-3">Doctor & Clinic</th>
                <th className="py-2.5 px-3">Priority</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Queue Operations</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredAppointments.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-slate-400">
                    No appointments match the selected filters.
                  </td>
                </tr>
              ) : (
                filteredAppointments.map((apt) => (
                  <tr key={apt.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-mono font-bold text-slate-700">
                      #{String(apt.queueNumber).padStart(2, '0')}
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <div className="font-bold text-slate-800 font-mono">{apt.timeSlot}</div>
                      <div className="text-[10px] text-slate-400">{apt.date}</div>
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <button
                        onClick={() => onSelectPatient(apt.patientId)}
                        className="text-left font-semibold text-slate-800 hover:text-blue-600 block"
                      >
                        {apt.patientName}
                      </button>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {apt.patientId} • {apt.patientAge}y {apt.patientGender}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="font-medium text-slate-700 flex items-center gap-1.5">
                        <span>{apt.type}</span>
                        {(apt.isTelehealth || apt.type.toLowerCase().includes('telehealth') || apt.type.toLowerCase().includes('remote')) && (
                          <span className="px-1.5 py-0.5 text-[9px] bg-emerald-100 text-emerald-800 rounded font-semibold flex items-center gap-0.5">
                            <Video className="w-2.5 h-2.5" />
                            <span>Remote</span>
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate max-w-xs">{apt.reason}</div>
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <div className="font-semibold text-slate-800">{apt.doctorName}</div>
                      <div className="text-[10px] text-slate-400">{apt.department} • Room {apt.roomNumber}</div>
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          apt.priority === 'Emergency'
                            ? 'bg-red-100 text-red-700'
                            : apt.priority === 'Urgent'
                            ? 'bg-amber-100 text-amber-700'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {apt.priority}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full font-medium ${
                          apt.status === 'In Consultation'
                            ? 'bg-blue-100 text-blue-700'
                            : apt.status === 'Checked-In'
                            ? 'bg-emerald-100 text-emerald-700'
                            : apt.status === 'Completed'
                            ? 'bg-slate-100 text-slate-500'
                            : 'bg-amber-100 text-amber-700'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            apt.status === 'In Consultation'
                              ? 'bg-blue-600 animate-pulse'
                              : apt.status === 'Checked-In'
                              ? 'bg-emerald-600'
                              : apt.status === 'Completed'
                              ? 'bg-slate-400'
                              : 'bg-amber-600'
                          }`}
                        />
                        {apt.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {(apt.isTelehealth ||
                          apt.type.toLowerCase().includes('telehealth') ||
                          apt.type.toLowerCase().includes('remote')) &&
                          apt.status !== 'Completed' &&
                          apt.status !== 'Cancelled' && (
                            <button
                              onClick={() => setActiveVideoModalApt(apt)}
                              className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded text-[11px] flex items-center gap-1 shadow-xs"
                              title="Initiate Telehealth Video Session"
                            >
                              <Video className="w-3 h-3" />
                              <span>Video</span>
                            </button>
                          )}
                        {apt.status === 'Scheduled' && (
                          <button
                            onClick={() => updateAppointmentStatus(apt.id, 'Checked-In')}
                            className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded text-[11px]"
                          >
                            Check In
                          </button>
                        )}
                        {apt.status === 'Checked-In' && (
                          <button
                            onClick={() => updateAppointmentStatus(apt.id, 'In Consultation')}
                            className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded text-[11px]"
                          >
                            Begin Consult
                          </button>
                        )}
                        {apt.status === 'In Consultation' && (
                          <button
                            onClick={() => updateAppointmentStatus(apt.id, 'Completed')}
                            className="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded text-[11px]"
                          >
                            Complete
                          </button>
                        )}
                        {apt.status !== 'Completed' && apt.status !== 'Cancelled' && (
                          <button
                            onClick={() => updateAppointmentStatus(apt.id, 'Cancelled')}
                            className="px-2 py-1 border border-slate-200 hover:bg-red-50 text-red-600 rounded text-[11px]"
                          >
                            Cancel
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
      </>
      )}

      {/* Video Consultation Session Modal */}
      {activeVideoModalApt && (
        <TelehealthVideoModal
          appointment={activeVideoModalApt}
          isOpen={!!activeVideoModalApt}
          onClose={() => setActiveVideoModalApt(null)}
          onSelectPatient={onSelectPatient}
        />
      )}
    </div>
  );
};
