import React, { useState } from 'react';
import {
  Pill,
  Search,
  Plus,
  AlertTriangle,
  CheckCircle2,
  Package,
  RefreshCw,
  MinusCircle,
  Building,
  ShieldAlert,
  Archive,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { PharmacyItem } from '../types';

export const PharmacyInventory: React.FC = () => {
  const { pharmacy, dispensePharmacyItem, restockPharmacyItem, addPharmacyItem, patients } = useHospital();

  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  // Modal states
  const [showDispenseModal, setShowDispenseModal] = useState(false);
  const [showRestockModal, setShowRestockModal] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState<PharmacyItem | null>(null);

  const [dispenseQty, setDispenseQty] = useState(10);
  const [dispensePatientId, setDispensePatientId] = useState(patients[0]?.id || '');
  const [restockQty, setRestockQty] = useState(50);

  const [newMedicine, setNewMedicine] = useState({
    sku: 'MED-NEW-100',
    name: '',
    genericName: '',
    category: 'Antibiotics' as PharmacyItem['category'],
    dosageForm: 'Tablet' as PharmacyItem['dosageForm'],
    stockQuantity: 100,
    minThreshold: 30,
    unitPrice: 2.50,
    batchNumber: 'BAT-2026-900',
    expiryDate: '2028-12-31',
    storageCondition: 'Room Temp (20-25°C)' as PharmacyItem['storageCondition'],
    manufacturer: 'Pfizer / Novartis',
  });

  const filteredItems = pharmacy.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.genericName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.batchNumber.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const lowStockCount = pharmacy.filter((p) => p.stockQuantity <= p.minThreshold).length;
  const totalStockUnits = pharmacy.reduce((sum, p) => sum + p.stockQuantity, 0);
  const totalValuation = pharmacy.reduce((sum, p) => sum + p.stockQuantity * p.unitPrice, 0);

  const handleDispense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem) return;
    dispensePharmacyItem(selectedItem.id, dispenseQty, dispensePatientId);
    setShowDispenseModal(false);
  };

  const handleRestock = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem) return;
    restockPharmacyItem(selectedItem.id, restockQty);
    setShowRestockModal(false);
  };

  const handleAddMedicine = (e: React.FormEvent) => {
    e.preventDefault();
    addPharmacyItem(newMedicine);
    setShowAddModal(false);
  };

  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Pill className="w-5 h-5 text-blue-600" />
            <h1 className="text-base lg:text-lg font-bold text-slate-800 tracking-tight">
              Hospital Pharmacy & Formulary Inventory
            </h1>
            <span className="px-2 py-0.5 text-[10px] font-bold bg-blue-100 text-blue-800 rounded">
              FORMULARY 2026
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Real-time drug inventory tracking, cold-storage/vault monitoring, low-stock threshold triggers, and ward dispensing.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-semibold flex items-center gap-1.5 shadow-sm transition"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Medicine to Stock</span>
        </button>
      </div>

      {/* Stats Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Total Formulary SKUs</span>
          <div className="text-xl font-bold text-slate-800 font-mono mt-1">{pharmacy.length} Drugs</div>
          <span className="text-[11px] text-slate-500">FDA Approved & In-House</span>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Low Stock Reorders</span>
          <div className="text-xl font-bold text-amber-600 font-mono mt-1">{lowStockCount} Items</div>
          <span className="text-[11px] text-slate-500">Below minimum safety threshold</span>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Total Units in Vault</span>
          <div className="text-xl font-bold text-slate-800 font-mono mt-1">{totalStockUnits.toLocaleString()}</div>
          <span className="text-[11px] text-slate-500">Dispensing reserve stock</span>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Formulary Valuation</span>
          <div className="text-xl font-bold text-emerald-600 font-mono mt-1">
            ${totalValuation.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <span className="text-[11px] text-slate-500">Current wholesale value</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search medication name, SKU, or generic..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 border border-slate-200 rounded text-xs focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex items-center gap-1 overflow-x-auto">
            {['all', 'Antibiotics', 'Cardiovascular', 'Analgesics', 'Respiratory', 'Endocrine', 'Emergency IV'].map((cat) => (
              <button
                key={cat}
                onClick={() => setCategoryFilter(cat)}
                className={`px-2 py-1 rounded font-medium whitespace-nowrap transition ${
                  categoryFilter === cat
                    ? 'bg-slate-800 text-white font-semibold'
                    : 'text-slate-600 hover:bg-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <span className="text-[11px] text-slate-500 font-mono">
          {filteredItems.length} records found
        </span>
      </div>

      {/* Inventory Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-[10px] uppercase font-bold text-slate-500">
              <tr>
                <th className="py-2.5 px-3">SKU & Batch</th>
                <th className="py-2.5 px-3">Medication Name</th>
                <th className="py-2.5 px-3">Category & Form</th>
                <th className="py-2.5 px-3">Storage Requirement</th>
                <th className="py-2.5 px-3">Expiry</th>
                <th className="py-2.5 px-3">Stock Level</th>
                <th className="py-2.5 px-3">Unit Price</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    No medications found matching filter.
                  </td>
                </tr>
              ) : (
                filteredItems.map((item) => {
                  const isLow = item.stockQuantity <= item.minThreshold;
                  return (
                    <tr key={item.id} className={`hover:bg-slate-50 ${isLow ? 'bg-amber-50/40' : ''}`}>
                      <td className="py-2.5 px-3 whitespace-nowrap font-mono">
                        <div className="font-bold text-slate-800">{item.sku}</div>
                        <div className="text-[10px] text-slate-400">{item.batchNumber}</div>
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="font-semibold text-slate-800">{item.name}</div>
                        <div className="text-[11px] text-slate-500">Generic: {item.genericName} • {item.manufacturer}</div>
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <div className="text-slate-700 font-medium">{item.category}</div>
                        <span className="text-[10px] bg-slate-100 text-slate-600 px-1 rounded">{item.dosageForm}</span>
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                            item.storageCondition === 'Controlled Substance Vault'
                              ? 'bg-purple-100 text-purple-700'
                              : item.storageCondition === 'Refrigerated (2-8°C)'
                              ? 'bg-blue-100 text-blue-700'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {item.storageCondition}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap font-mono text-slate-600">
                        {item.expiryDate}
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap font-mono">
                        <div className="flex items-center gap-1.5">
                          <span className={`font-bold text-sm ${isLow ? 'text-rose-600' : 'text-slate-800'}`}>
                            {item.stockQuantity}
                          </span>
                          <span className="text-[10px] text-slate-400">/ min {item.minThreshold}</span>
                        </div>
                        {isLow && (
                          <span className="inline-flex items-center gap-0.5 text-[9px] font-bold text-rose-600 uppercase">
                            <AlertTriangle className="w-2.5 h-2.5" /> Low Stock Alert
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap font-mono font-bold text-slate-700">
                        ${item.unitPrice.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => {
                              setSelectedItem(item);
                              setShowDispenseModal(true);
                            }}
                            className="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded text-[11px]"
                          >
                            Dispense
                          </button>
                          <button
                            onClick={() => {
                              setSelectedItem(item);
                              setShowRestockModal(true);
                            }}
                            className="px-2 py-1 border border-slate-200 hover:bg-slate-100 text-slate-700 font-semibold rounded text-[11px]"
                          >
                            Restock
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Dispense Modal */}
      {showDispenseModal && selectedItem && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-md w-full p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h3 className="font-bold text-sm text-slate-800">
                Dispense Medication — {selectedItem.name}
              </h3>
              <button onClick={() => setShowDispenseModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>
            <form onSubmit={handleDispense} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-600 font-medium mb-1">Select Inpatient or Outpatient</label>
                <select
                  value={dispensePatientId}
                  onChange={(e) => setDispensePatientId(e.target.value)}
                  className="w-full p-2 border border-slate-200 rounded text-slate-800 font-medium"
                >
                  {patients.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.firstName} {p.lastName} ({p.id}) — {p.wardOrRoom || p.status}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">
                  Quantity to Dispense (Max Available: {selectedItem.stockQuantity})
                </label>
                <input
                  type="number"
                  min={1}
                  max={selectedItem.stockQuantity}
                  value={dispenseQty}
                  onChange={(e) => setDispenseQty(Number(e.target.value))}
                  className="w-full p-2 border border-slate-200 rounded font-mono font-bold text-slate-800"
                  required
                />
              </div>

              <div className="p-2.5 bg-slate-50 border border-slate-200 rounded text-[11px] text-slate-600 space-y-1">
                <div className="flex justify-between">
                  <span>Unit Price:</span>
                  <span className="font-mono font-bold">${selectedItem.unitPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold text-slate-800 pt-1 border-t border-slate-200">
                  <span>Total Dispensed Charge:</span>
                  <span className="font-mono text-blue-600">${(dispenseQty * selectedItem.unitPrice).toFixed(2)}</span>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowDispenseModal(false)}
                  className="px-3 py-1.5 border border-slate-300 rounded text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded font-semibold"
                >
                  Confirm Dispensing
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Restock Modal */}
      {showRestockModal && selectedItem && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-md w-full p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h3 className="font-bold text-sm text-slate-800">
                Replenish Inventory — {selectedItem.name}
              </h3>
              <button onClick={() => setShowRestockModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>
            <form onSubmit={handleRestock} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-600 font-medium mb-1">Batch Number</label>
                <input
                  type="text"
                  value={selectedItem.batchNumber}
                  disabled
                  className="w-full p-2 bg-slate-100 border border-slate-200 rounded font-mono text-slate-700"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Units Received from Supplier</label>
                <input
                  type="number"
                  min={1}
                  value={restockQty}
                  onChange={(e) => setRestockQty(Number(e.target.value))}
                  className="w-full p-2 border border-slate-200 rounded font-mono font-bold text-slate-800 text-sm"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowRestockModal(false)}
                  className="px-3 py-1.5 border border-slate-300 rounded text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-semibold"
                >
                  Record Stock Inflow
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add New Drug Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-lg w-full p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h3 className="font-bold text-sm text-slate-800">
                Add New Drug to Pharmacy Catalog
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>
            <form onSubmit={handleAddMedicine} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Drug Brand Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Ciprofloxacin 500mg"
                    value={newMedicine.name}
                    onChange={(e) => setNewMedicine({ ...newMedicine, name: e.target.value })}
                    className="w-full p-2 border border-slate-200 rounded font-semibold"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Generic / Chemical Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Cipro"
                    value={newMedicine.genericName}
                    onChange={(e) => setNewMedicine({ ...newMedicine, genericName: e.target.value })}
                    className="w-full p-2 border border-slate-200 rounded"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Category</label>
                  <select
                    value={newMedicine.category}
                    onChange={(e) => setNewMedicine({ ...newMedicine, category: e.target.value as PharmacyItem['category'] })}
                    className="w-full p-2 border border-slate-200 rounded"
                  >
                    <option value="Antibiotics">Antibiotics</option>
                    <option value="Cardiovascular">Cardiovascular</option>
                    <option value="Analgesics">Analgesics</option>
                    <option value="Respiratory">Respiratory</option>
                    <option value="Endocrine">Endocrine</option>
                    <option value="Emergency IV">Emergency IV</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Form</label>
                  <select
                    value={newMedicine.dosageForm}
                    onChange={(e) => setNewMedicine({ ...newMedicine, dosageForm: e.target.value as PharmacyItem['dosageForm'] })}
                    className="w-full p-2 border border-slate-200 rounded"
                  >
                    <option value="Tablet">Tablet</option>
                    <option value="Capsule">Capsule</option>
                    <option value="Injection IV">Injection IV</option>
                    <option value="Syrup">Syrup</option>
                    <option value="Inhaler">Inhaler</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Storage Condition</label>
                  <select
                    value={newMedicine.storageCondition}
                    onChange={(e) => setNewMedicine({ ...newMedicine, storageCondition: e.target.value as PharmacyItem['storageCondition'] })}
                    className="w-full p-2 border border-slate-200 rounded"
                  >
                    <option value="Room Temp (20-25°C)">Room Temp</option>
                    <option value="Refrigerated (2-8°C)">Cold (2-8°C)</option>
                    <option value="Controlled Substance Vault">Controlled Vault</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Initial Stock Units</label>
                  <input
                    type="number"
                    value={newMedicine.stockQuantity}
                    onChange={(e) => setNewMedicine({ ...newMedicine, stockQuantity: Number(e.target.value) })}
                    className="w-full p-2 border border-slate-200 rounded font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Min Threshold</label>
                  <input
                    type="number"
                    value={newMedicine.minThreshold}
                    onChange={(e) => setNewMedicine({ ...newMedicine, minThreshold: Number(e.target.value) })}
                    className="w-full p-2 border border-slate-200 rounded font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Unit Price ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newMedicine.unitPrice}
                    onChange={(e) => setNewMedicine({ ...newMedicine, unitPrice: Number(e.target.value) })}
                    className="w-full p-2 border border-slate-200 rounded font-mono"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Manufacturer</label>
                  <input
                    type="text"
                    value={newMedicine.manufacturer}
                    onChange={(e) => setNewMedicine({ ...newMedicine, manufacturer: e.target.value })}
                    className="w-full p-2 border border-slate-200 rounded"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Expiry Date</label>
                  <input
                    type="date"
                    value={newMedicine.expiryDate}
                    onChange={(e) => setNewMedicine({ ...newMedicine, expiryDate: e.target.value })}
                    className="w-full p-2 border border-slate-200 rounded font-mono"
                    required
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 border border-slate-300 rounded text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded font-semibold"
                >
                  Catalog Drug
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
