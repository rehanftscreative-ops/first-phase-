import React, { useState } from 'react';
import { X, UserPlus, ShieldCheck, HeartPulse } from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { BloodGroup, PatientStatus } from '../types';

interface NewPatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPatientCreated: (id: string) => void;
}

export const NewPatientModal: React.FC<NewPatientModalProps> = ({
  isOpen,
  onClose,
  onPatientCreated,
}) => {
  const { addPatient, doctors, wardBeds } = useHospital();

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    age: 35,
    gender: 'Male' as 'Male' | 'Female' | 'Other',
    dob: '1991-05-14',
    bloodGroup: 'O+' as BloodGroup,
    phone: '+1 (555) 000-0000',
    email: '',
    address: '123 Medical Plaza, Springfield, IL',
    emergencyContactName: '',
    emergencyContactRel: 'Spouse',
    emergencyContactPhone: '+1 (555) 000-0001',
    status: 'Inpatient' as PatientStatus,
    wardOrRoom: 'General Ward A - Bed 101',
    primaryPhysicianId: doctors[0]?.id || 'DOC-101',
    primaryPhysicianName: doctors[0]?.name || 'Dr. Sarah Jenkins, MD',
    allergies: 'None',
    chronicConditions: 'None',
    insuranceProvider: 'BlueCross BlueShield Premier',
    insurancePolicyNumber: 'BCBS-90214-X',
    insuranceGroupNumber: 'GRP-8821',
    insuranceCoverage: 80,
    insuranceCopay: 35,
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const assignedDoctor = doctors.find((d) => d.id === formData.primaryPhysicianId);

    const newPatient = addPatient({
      firstName: formData.firstName,
      lastName: formData.lastName,
      age: Number(formData.age),
      gender: formData.gender,
      dob: formData.dob,
      bloodGroup: formData.bloodGroup,
      phone: formData.phone,
      email: formData.email || `${formData.firstName.toLowerCase()}.${formData.lastName.toLowerCase()}@example.com`,
      address: formData.address,
      emergencyContact: {
        name: formData.emergencyContactName || 'Family Member',
        relationship: formData.emergencyContactRel,
        phone: formData.emergencyContactPhone,
      },
      status: formData.status,
      wardOrRoom: formData.wardOrRoom,
      primaryPhysicianId: formData.primaryPhysicianId,
      primaryPhysicianName: assignedDoctor ? assignedDoctor.name : formData.primaryPhysicianName,
      allergies:
        formData.allergies === 'None' || !formData.allergies.trim()
          ? []
          : formData.allergies.split(',').map((a) => ({
              allergen: a.trim(),
              severity: 'Moderate',
            })),
      chronicConditions:
        formData.chronicConditions === 'None' || !formData.chronicConditions.trim()
          ? []
          : formData.chronicConditions.split(',').map((c) => c.trim()),
      insurance: {
        provider: formData.insuranceProvider,
        policyNumber: formData.insurancePolicyNumber,
        groupNumber: formData.insuranceGroupNumber,
        coveragePercentage: Number(formData.insuranceCoverage),
        copayAmount: Number(formData.insuranceCopay),
        status: 'Verified',
        expiryDate: '2027-12-31',
      },
    });

    onPatientCreated(newPatient.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 z-50">
      <div className="bg-white rounded-lg border border-slate-200 shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden text-xs">
        {/* Header */}
        <div className="p-3.5 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-blue-600 flex items-center justify-center text-white font-bold">
              +
            </div>
            <div>
              <h2 className="font-bold text-sm text-white">Patient Admission & Registration</h2>
              <p className="text-[10px] text-slate-400">HL7 / HIPAA Encrypted Clinical Intake</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 space-y-4 overflow-y-auto flex-1">
          {/* Demographics */}
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-500 tracking-wider mb-2">
              1. Patient Demographics & Identification
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div>
                <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">First Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. John"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">Last Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Doe"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">Blood Group</label>
                <select
                  value={formData.bloodGroup}
                  onChange={(e) => setFormData({ ...formData, bloodGroup: e.target.value as BloodGroup })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs"
                >
                  <option value="A+">A+</option>
                  <option value="A-">A-</option>
                  <option value="B+">B+</option>
                  <option value="B-">B-</option>
                  <option value="AB+">AB+</option>
                  <option value="AB-">AB-</option>
                  <option value="O+">O+</option>
                  <option value="O-">O-</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">Age</label>
                <input
                  type="number"
                  required
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: Number(e.target.value) })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs"
                />
              </div>

              <div>
                <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">Gender</label>
                <select
                  value={formData.gender}
                  onChange={(e) => setFormData({ ...formData, gender: e.target.value as any })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">Contact Phone</label>
                <input
                  type="text"
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs"
                />
              </div>
            </div>
          </div>

          {/* Clinical Status & Bed Assignment */}
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-500 tracking-wider mb-2">
              2. Clinical Triage & Physician Assignment
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div>
                <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">Admission Status</label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value as PatientStatus })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs"
                >
                  <option value="Inpatient">Inpatient (Ward Admission)</option>
                  <option value="Emergency">Emergency (Immediate Triage)</option>
                  <option value="Outpatient">Outpatient (Ambulatory Clinic)</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">Primary Physician</label>
                <select
                  value={formData.primaryPhysicianId}
                  onChange={(e) => setFormData({ ...formData, primaryPhysicianId: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs"
                >
                  {doctors.map((doc) => (
                    <option key={doc.id} value={doc.id}>
                      {doc.name.replace(', MD', '').replace(', FACS', '')} ({doc.specialty})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">Ward / Room Target</label>
                <input
                  type="text"
                  value={formData.wardOrRoom}
                  onChange={(e) => setFormData({ ...formData, wardOrRoom: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs"
                  placeholder="e.g. ICU Bed 04"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">
                  Allergies (comma-separated, or None)
                </label>
                <input
                  type="text"
                  value={formData.allergies}
                  onChange={(e) => setFormData({ ...formData, allergies: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs"
                  placeholder="e.g. Penicillin, Shellfish"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">
                  Chronic Diagnoses / Pre-existing Conditions
                </label>
                <input
                  type="text"
                  value={formData.chronicConditions}
                  onChange={(e) => setFormData({ ...formData, chronicConditions: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs"
                  placeholder="e.g. Hypertension, Diabetes Mellitus"
                />
              </div>
            </div>
          </div>

          {/* Insurance & Billing */}
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-500 tracking-wider mb-2">
              3. Insurance Policy & Adjudication
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div>
                <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">Payer Name</label>
                <input
                  type="text"
                  value={formData.insuranceProvider}
                  onChange={(e) => setFormData({ ...formData, insuranceProvider: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs"
                />
              </div>
              <div>
                <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">Policy Number</label>
                <input
                  type="text"
                  value={formData.insurancePolicyNumber}
                  onChange={(e) => setFormData({ ...formData, insurancePolicyNumber: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs font-mono"
                />
              </div>
              <div>
                <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">Copay ($)</label>
                <input
                  type="number"
                  value={formData.insuranceCopay}
                  onChange={(e) => setFormData({ ...formData, insuranceCopay: Number(e.target.value) })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs font-mono"
                />
              </div>
            </div>
          </div>

          {/* Footer Action Buttons */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-[10px] text-slate-500">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>HIPAA Privacy Rule Protected</span>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-semibold text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded font-semibold text-xs shadow-sm flex items-center gap-1.5"
              >
                <UserPlus className="w-3.5 h-3.5" /> Complete Admission
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
