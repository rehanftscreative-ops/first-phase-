import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Mic,
  MicOff,
  Video,
  VideoOff,
  PhoneOff,
  Monitor,
  Share2,
  MessageSquare,
  FileText,
  Activity,
  ShieldCheck,
  Wifi,
  Sparkles,
  Send,
  Plus,
  Pill,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  Maximize2,
  Minimize2,
  Clock,
  User,
  Info,
} from 'lucide-react';
import { Appointment, Patient } from '../types';
import { useHospital } from '../context/HospitalContext';

interface TelehealthVideoModalProps {
  appointment: Appointment;
  isOpen: boolean;
  onClose: () => void;
  onSelectPatient?: (patientId: string) => void;
}

export const TelehealthVideoModal: React.FC<TelehealthVideoModalProps> = ({
  appointment,
  isOpen,
  onClose,
  onSelectPatient,
}) => {
  const {
    patients,
    doctors,
    updateAppointmentStatus,
    addClinicalNote,
    addMedication,
    addNotification,
    logAuditEvent,
  } = useHospital();

  const patient = patients.find((p) => p.id === appointment.patientId);
  const doctor = doctors.find((d) => d.id === appointment.doctorId) || {
    name: appointment.doctorName,
    specialty: appointment.department,
  };

  // Video call media controls state
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [activeSideTab, setActiveSideTab] = useState<'soap' | 'chart' | 'prescribe' | 'chat'>('soap');
  const [callDuration, setCallDuration] = useState(0);
  const [isCopied, setIsCopied] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [webcamActive, setWebcamActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // SOAP Documentation state
  const [soapSubjective, setSoapSubjective] = useState(
    `Patient attended via telehealth from home. Reports: "${appointment.reason}". Denies acute shortness of breath or radiating chest pressure.`
  );
  const [soapObjective, setSoapObjective] = useState(
    `Alert, interactive, in no acute distress over video. Ambulatory home BP log reviewed: 132/84 mmHg average. Resting pulse 72 bpm. Respiratory effort normal.`
  );
  const [soapAssessment, setSoapAssessment] = useState(
    `Essential Hypertension (ICD-10 I10) - stable on current regimen; Routine telemedicine follow-up.`
  );
  const [soapPlan, setSoapPlan] = useState(
    `1. Continue current antihypertensive medications.\n2. Recheck fasting lipid panel in 6 weeks.\n3. Return to clinic or telehealth in 3 months.\n4. Call emergency services if any red-flag symptoms develop.`
  );
  const [diagnosisCode, setDiagnosisCode] = useState('I10');
  const [isSavingNote, setIsSavingNote] = useState(false);

  // In-call Chat state
  const [chatMessages, setChatMessages] = useState<
    Array<{ id: string; sender: 'doctor' | 'patient' | 'system'; text: string; time: string }>
  >([
    {
      id: 'sys-1',
      sender: 'system',
      text: 'Encrypted peer-to-peer WebRTC session established (AES-256 GCM). Both streams verified.',
      time: 'Just now',
    },
    {
      id: 'pt-1',
      sender: 'patient',
      text: 'Hello doctor, I can see and hear you clearly! I have my blood pressure log ready.',
      time: 'Just now',
    },
  ]);
  const [newChatMessage, setNewChatMessage] = useState('');

  // Quick e-prescribe state
  const [rxName, setRxName] = useState('');
  const [rxDosage, setRxDosage] = useState('');
  const [rxFrequency, setRxFrequency] = useState('Once daily with food');
  const [rxRoute, setRxRoute] = useState('Oral');
  const [rxSuccessMessage, setRxSuccessMessage] = useState('');

  // Auto-start consultation status on launch
  useEffect(() => {
    if (isOpen && appointment.status !== 'In Consultation') {
      updateAppointmentStatus(appointment.id, 'In Consultation');
      logAuditEvent(
        'ACCESS',
        'Appointment',
        appointment.id,
        `Physician initiated telehealth video session with ${appointment.patientName} (${appointment.id})`
      );
    }
  }, [isOpen, appointment.id]);

  // Call duration counter
  useEffect(() => {
    if (!isOpen) return;
    const interval = setInterval(() => {
      setCallDuration((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isOpen]);

  // Optional real webcam toggle attempt
  const toggleRealWebcam = async () => {
    if (webcamActive) {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((track) => track.stop());
        videoRef.current.srcObject = null;
      }
      setWebcamActive(false);
    } else {
      try {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.play();
          }
          setWebcamActive(true);
        } else {
          addNotification('Webcam Notice', 'Camera preview is simulated in this environment.', 'info');
        }
      } catch (err) {
        // Fallback gracefully
        addNotification('Webcam Notice', 'Using high-definition simulated clinical feed.', 'info');
      }
    }
  };

  // Format call duration MM:SS
  const formatDuration = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChatMessage.trim()) return;

    const message = {
      id: `msg-${Date.now()}`,
      sender: 'doctor' as const,
      text: newChatMessage.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages((prev) => [...prev, message]);
    setNewChatMessage('');

    // Simulated patient reply
    setTimeout(() => {
      setChatMessages((prev) => [
        ...prev,
        {
          id: `msg-reply-${Date.now()}`,
          sender: 'patient',
          text: 'Thank you doctor, noted down!',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    }, 1200);
  };

  const handlePrescribeQuickRx = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rxName.trim() || !rxDosage.trim() || !patient) return;

    addMedication(patient.id, {
      name: rxName.trim(),
      dosage: rxDosage.trim(),
      frequency: rxFrequency,
      route: rxRoute,
      prescribedBy: appointment.doctorName,
      startDate: new Date().toISOString().split('T')[0],
      status: 'Active',
    });

    setRxSuccessMessage(`Successfully e-prescribed ${rxName} to hospital outpatient formulary!`);
    setRxName('');
    setRxDosage('');
    setTimeout(() => setRxSuccessMessage(''), 4000);
  };

  const handleSaveSoapAndComplete = () => {
    if (!patient) return;
    setIsSavingNote(true);

    const treatmentSummary = `${soapAssessment}\n\nPLAN:\n${soapPlan}`;
    addClinicalNote(patient.id, {
      doctorName: appointment.doctorName,
      doctorSpecialty: appointment.department,
      chiefComplaint: `[Telehealth Consult] ${appointment.reason}`,
      assessment: `${soapSubjective}\n\nOBJECTIVE:\n${soapObjective}\n\nASSESSMENT:\n${soapAssessment}`,
      treatmentPlan: soapPlan,
      diagnosisCode: diagnosisCode || 'I10',
    });

    updateAppointmentStatus(appointment.id, 'Completed');
    logAuditEvent(
      'UPDATE',
      'Appointment',
      appointment.id,
      `Telehealth consult concluded and SOAP note recorded for ${appointment.patientName}`
    );
    addNotification(
      'Telehealth Session Concluded',
      `Session completed for ${appointment.patientName}. SOAP notes and orders synced to EMR.`,
      'success',
      appointment.patientId
    );

    setIsSavingNote(false);
    onClose();
  };

  const handleCopyMeetingLink = () => {
    const link =
      appointment.telehealthDetails?.meetingLink ||
      `https://telehealth.medcore.health/room/${appointment.id}`;
    navigator.clipboard.writeText(link);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
    addNotification('Link Copied', 'Telehealth room link copied to clipboard.', 'info');
  };

  if (!isOpen) return null;

  return (
    <div
      id="telehealth-video-modal"
      className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 z-50 animate-in fade-in duration-200"
    >
      <div className="bg-slate-900 border border-slate-700/80 rounded-xl shadow-2xl w-full max-w-6xl h-[92vh] flex flex-col overflow-hidden text-slate-200">
        {/* Top Video Header Bar */}
        <div className="px-4 py-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
              <div className="font-semibold text-sm text-white flex items-center gap-2">
                <span>Telehealth Video Consultation</span>
                <span className="px-2 py-0.5 text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded font-mono font-bold">
                  LIVE SESSION
                </span>
              </div>
            </div>

            <div className="hidden md:flex items-center gap-2 text-xs text-slate-400 pl-3 border-l border-slate-700">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
              <span>HIPAA Compliant 256-Bit E2EE</span>
            </div>
          </div>

          {/* Session Timer & Room Info */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-800 rounded border border-slate-700 text-xs font-mono text-emerald-400 font-bold">
              <Clock className="w-3.5 h-3.5 text-emerald-400" />
              <span>{formatDuration(callDuration)}</span>
            </div>

            <button
              onClick={handleCopyMeetingLink}
              className="hidden sm:flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 text-xs transition"
              title="Copy Patient Meeting Link"
            >
              {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{isCopied ? 'Link Copied' : 'Invite Link'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition"
              title="Minimize Session"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Main Split Layout: Video Room (Left/Center) + Clinical Documentation (Right) */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 min-h-0 bg-slate-950">
          {/* Left / Center: Video Stage & Controls (7 or 8 columns on large screens) */}
          <div className="lg:col-span-7 xl:col-span-8 flex flex-col p-3 sm:p-4 gap-3 border-b lg:border-b-0 lg:border-r border-slate-800 min-h-0">
            {/* Video Canvas Container */}
            <div className="relative flex-1 bg-slate-900 rounded-xl border border-slate-800 overflow-hidden flex items-center justify-center shadow-inner min-h-[260px] sm:min-h-[380px]">
              {/* Main Remote Patient Video Feed */}
              <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-b from-slate-850 via-slate-900 to-slate-950">
                {isScreenSharing ? (
                  /* Screen share mode: Show diagnostic visual review */
                  <div className="w-full h-full p-4 flex flex-col items-center justify-center bg-slate-950 text-center">
                    <div className="max-w-md p-4 bg-slate-900 border border-blue-500/40 rounded-xl shadow-lg">
                      <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-xs text-blue-400 font-semibold">
                        <span className="flex items-center gap-1.5">
                          <Activity className="w-4 h-4 text-emerald-400" />
                          Diagnostic Share: Ambulatory Rhythm & BP Report
                        </span>
                        <span className="text-[10px] bg-blue-500/20 px-1.5 py-0.5 rounded text-blue-300">
                          SHARING SCREEN
                        </span>
                      </div>
                      <div className="h-28 bg-slate-950 rounded flex items-center justify-center p-2">
                        {/* ECG trace wave visual */}
                        <svg className="w-full h-full text-emerald-400" viewBox="0 0 500 100">
                          <path
                            d="M 0 50 L 80 50 L 90 20 L 100 80 L 110 50 L 170 50 L 180 15 L 190 85 L 200 50 L 300 50 L 310 10 L 320 90 L 330 50 L 420 50 L 430 30 L 440 70 L 450 50 L 500 50"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2.5"
                            strokeLinecap="round"
                          />
                        </svg>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-2">
                        Displaying 14-day ambulatory continuous rhythm & home BP summary for patient review.
                      </p>
                    </div>
                  </div>
                ) : (
                  /* Patient Simulated High-Def Video Stream */
                  <div className="relative w-full h-full flex flex-col items-center justify-center overflow-hidden">
                    {/* Atmospheric telemedicine video background */}
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/60 to-transparent z-10" />

                    {/* Patient Video Representation */}
                    <div className="relative z-10 flex flex-col items-center text-center p-4">
                      <div className="relative mb-3">
                        <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-full bg-gradient-to-tr from-blue-600 via-indigo-500 to-emerald-400 p-1 shadow-2xl flex items-center justify-center">
                          <div className="w-full h-full rounded-full bg-slate-800 flex items-center justify-center overflow-hidden">
                            <span className="text-3xl sm:text-4xl font-bold text-white tracking-wider">
                              {appointment.patientName
                                .split(' ')
                                .map((n) => n[0])
                                .join('')}
                            </span>
                          </div>
                        </div>
                        {/* Audio Waveform Activity Pulse */}
                        <div className="absolute -bottom-1 right-2 bg-emerald-500 text-slate-950 p-1.5 rounded-full shadow-lg border-2 border-slate-900">
                          <Mic className="w-3.5 h-3.5" />
                        </div>
                      </div>

                      <div className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                        <span>{appointment.patientName}</span>
                        <span className="text-xs font-normal text-slate-400 font-mono">
                          ({appointment.patientGender}, {appointment.patientAge} yrs)
                        </span>
                      </div>
                      <span className="text-xs text-emerald-400 flex items-center gap-1.5 mt-0.5">
                        <Wifi className="w-3.5 h-3.5" />
                        <span>Connected • WebRTC 1080p (24ms)</span>
                      </span>

                      <div className="mt-3 px-3 py-1 bg-slate-800/80 backdrop-blur-xs border border-slate-700/60 rounded-full text-[11px] text-slate-300 max-w-md">
                        <span className="text-slate-400 font-semibold">Chief Reason: </span>
                        <span>{appointment.reason}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Top Video HUD Badges */}
              <div className="absolute top-3 left-3 z-20 flex items-center gap-2">
                <span className="px-2.5 py-1 bg-black/60 backdrop-blur-md rounded-md text-[11px] text-white font-medium flex items-center gap-1.5 border border-white/10">
                  <User className="w-3 h-3 text-emerald-400" />
                  <span>{appointment.patientName}</span>
                </span>
                <span className="px-2 py-1 bg-emerald-500/20 backdrop-blur-md rounded-md text-[10px] text-emerald-300 font-mono border border-emerald-500/30">
                  HD 1080p 60fps
                </span>
              </div>

              {/* Bottom Right: Doctor's Picture-in-Picture (PiP) Stream */}
              <div className="absolute bottom-3 right-3 z-20 w-32 sm:w-44 h-24 sm:h-32 bg-slate-950 rounded-lg border-2 border-slate-750 overflow-hidden shadow-2xl flex flex-col justify-between p-2">
                {webcamActive ? (
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                ) : (
                  <div className="absolute inset-0 bg-gradient-to-tr from-slate-900 to-slate-800 flex flex-col items-center justify-center text-center p-2">
                    <div className="w-9 h-9 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs mb-1">
                      {appointment.doctorName
                        .split(' ')
                        .filter((p) => !p.includes('.'))
                        .map((n) => n[0])
                        .slice(0, 2)
                        .join('')}
                    </div>
                    <span className="text-[10px] font-bold text-slate-200 truncate max-w-full">
                      {appointment.doctorName}
                    </span>
                    <span className="text-[9px] text-slate-400">Attending Physician</span>
                  </div>
                )}

                <div className="relative z-10 flex items-center justify-between w-full text-[9px] text-white">
                  <span className="bg-black/60 px-1 py-0.5 rounded font-mono">You (Doctor)</span>
                  {isMuted && (
                    <span className="bg-red-500/80 p-0.5 rounded text-white">
                      <MicOff className="w-2.5 h-2.5" />
                    </span>
                  )}
                </div>

                <div className="relative z-10 flex justify-end">
                  <button
                    onClick={toggleRealWebcam}
                    className="text-[9px] bg-slate-900/90 hover:bg-slate-800 px-1.5 py-0.5 rounded border border-slate-700 text-slate-300"
                    title={webcamActive ? 'Disable Camera' : 'Use Real Camera'}
                  >
                    {webcamActive ? 'Stop Cam' : 'Camera'}
                  </button>
                </div>
              </div>
            </div>

            {/* Bottom Call Control Toolbar */}
            <div className="bg-slate-900 px-4 py-2.5 rounded-xl border border-slate-800 flex items-center justify-between gap-2 shadow-sm">
              <div className="flex items-center gap-1.5">
                {/* Mute Toggle */}
                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className={`p-2.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
                    isMuted
                      ? 'bg-red-500/20 text-red-400 border border-red-500/40 hover:bg-red-500/30'
                      : 'bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700'
                  }`}
                  title={isMuted ? 'Unmute Microphone' : 'Mute Microphone'}
                >
                  {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 text-emerald-400" />}
                  <span className="hidden sm:inline">{isMuted ? 'Unmute' : 'Mute'}</span>
                </button>

                {/* Video Toggle */}
                <button
                  onClick={() => setIsVideoOff(!isVideoOff)}
                  className={`p-2.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
                    isVideoOff
                      ? 'bg-red-500/20 text-red-400 border border-red-500/40 hover:bg-red-500/30'
                      : 'bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700'
                  }`}
                  title={isVideoOff ? 'Turn Camera On' : 'Turn Camera Off'}
                >
                  {isVideoOff ? <VideoOff className="w-4 h-4" /> : <Video className="w-4 h-4 text-blue-400" />}
                  <span className="hidden sm:inline">{isVideoOff ? 'Start Video' : 'Video On'}</span>
                </button>

                {/* Screen / Imaging Share */}
                <button
                  onClick={() => setIsScreenSharing(!isScreenSharing)}
                  className={`p-2.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
                    isScreenSharing
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700'
                  }`}
                  title="Share Medical Imaging / Lab Charts with Patient"
                >
                  <Monitor className="w-4 h-4" />
                  <span className="hidden sm:inline">
                    {isScreenSharing ? 'Stop Share' : 'Share Diagnostics'}
                  </span>
                </button>
              </div>

              {/* End Call / Finalize Consultation Button */}
              <div className="flex items-center gap-2">
                <button
                  onClick={handleSaveSoapAndComplete}
                  disabled={isSavingNote}
                  className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-lg shadow flex items-center gap-1.5 transition"
                  title="Complete consultation and log SOAP documentation into patient EMR"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isSavingNote ? 'Syncing...' : 'Complete & Sign'}</span>
                </button>

                <button
                  onClick={onClose}
                  className="p-2.5 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow transition"
                  title="Leave Video Call"
                >
                  <PhoneOff className="w-4 h-4" />
                  <span className="hidden sm:inline">Leave Room</span>
                </button>
              </div>
            </div>
          </div>

          {/* Right: Integrated Telehealth Clinical Workbench (4 or 5 cols) */}
          <div className="lg:col-span-5 xl:col-span-4 flex flex-col bg-slate-900 border-t lg:border-t-0 border-slate-800 min-h-0">
            {/* Workbench Tab Navigation */}
            <div className="flex items-center border-b border-slate-800 bg-slate-850 px-2 pt-2">
              <button
                onClick={() => setActiveSideTab('soap')}
                className={`flex-1 py-2 px-2 text-xs font-semibold flex items-center justify-center gap-1.5 border-b-2 transition ${
                  activeSideTab === 'soap'
                    ? 'border-blue-500 text-blue-400 bg-slate-800/60 rounded-t'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>SOAP Note</span>
              </button>

              <button
                onClick={() => setActiveSideTab('chart')}
                className={`flex-1 py-2 px-2 text-xs font-semibold flex items-center justify-center gap-1.5 border-b-2 transition ${
                  activeSideTab === 'chart'
                    ? 'border-blue-500 text-blue-400 bg-slate-800/60 rounded-t'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Activity className="w-3.5 h-3.5" />
                <span>Vitals & HUD</span>
              </button>

              <button
                onClick={() => setActiveSideTab('prescribe')}
                className={`flex-1 py-2 px-2 text-xs font-semibold flex items-center justify-center gap-1.5 border-b-2 transition ${
                  activeSideTab === 'prescribe'
                    ? 'border-blue-500 text-blue-400 bg-slate-800/60 rounded-t'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Pill className="w-3.5 h-3.5" />
                <span>E-Prescribe</span>
              </button>

              <button
                onClick={() => setActiveSideTab('chat')}
                className={`flex-1 py-2 px-2 text-xs font-semibold flex items-center justify-center gap-1.5 border-b-2 transition ${
                  activeSideTab === 'chat'
                    ? 'border-blue-500 text-blue-400 bg-slate-800/60 rounded-t'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Chat</span>
              </button>
            </div>

            {/* Workbench Tab Content */}
            <div className="flex-1 p-3 sm:p-4 overflow-y-auto space-y-3 text-xs">
              {/* TAB 1: SOAP CLINICAL NOTE */}
              {activeSideTab === 'soap' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-bold text-slate-100 text-xs flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                        Live Telehealth SOAP Documentation
                      </h3>
                      <p className="text-[10px] text-slate-400">
                        Document clinical findings in real-time during the remote encounter.
                      </p>
                    </div>

                    <span className="px-2 py-0.5 bg-slate-800 border border-slate-700 text-slate-300 rounded text-[10px] font-mono">
                      ICD-10: {diagnosisCode}
                    </span>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                      Subjective (Chief Complaint & Remote History)
                    </label>
                    <textarea
                      value={soapSubjective}
                      onChange={(e) => setSoapSubjective(e.target.value)}
                      rows={2}
                      className="w-full bg-slate-950 border border-slate-750 rounded p-2 text-slate-200 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                      Objective (Visual Examination & Patient Vitals)
                    </label>
                    <textarea
                      value={soapObjective}
                      onChange={(e) => setSoapObjective(e.target.value)}
                      rows={2}
                      className="w-full bg-slate-950 border border-slate-750 rounded p-2 text-slate-200 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[10px] font-bold uppercase text-slate-400">
                        Assessment & Diagnosis (ICD-10 Standard)
                      </label>
                      <select
                        value={diagnosisCode}
                        onChange={(e) => {
                          setDiagnosisCode(e.target.value);
                          if (e.target.value === 'I10') {
                            setSoapAssessment('Essential (primary) hypertension - stable control on current regimen.');
                          } else if (e.target.value === 'E11.9') {
                            setSoapAssessment('Type 2 diabetes mellitus without complications - glycemic review.');
                          } else if (e.target.value === 'J45.909') {
                            setSoapAssessment('Unspecified asthma, uncomplicated - spirometry follow-up.');
                          } else if (e.target.value === 'G43.909') {
                            setSoapAssessment('Migraine, unspecified, not intractable - prophylactic review.');
                          }
                        }}
                        className="bg-slate-800 text-slate-200 text-[10px] border border-slate-700 rounded px-1.5 py-0.5"
                      >
                        <option value="I10">I10 - Essential Hypertension</option>
                        <option value="E11.9">E11.9 - Type 2 Diabetes</option>
                        <option value="J45.909">J45.909 - Asthma</option>
                        <option value="G43.909">G43.909 - Migraine</option>
                        <option value="Z00.00">Z00.00 - General Wellness</option>
                      </select>
                    </div>
                    <textarea
                      value={soapAssessment}
                      onChange={(e) => setSoapAssessment(e.target.value)}
                      rows={2}
                      className="w-full bg-slate-950 border border-slate-750 rounded p-2 text-slate-200 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                      Plan (Pharmacotherapy, Lifestyle & Follow-Up)
                    </label>
                    <textarea
                      value={soapPlan}
                      onChange={(e) => setSoapPlan(e.target.value)}
                      rows={3}
                      className="w-full bg-slate-950 border border-slate-750 rounded p-2 text-slate-200 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none font-sans"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={handleSaveSoapAndComplete}
                    disabled={isSavingNote}
                    className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded text-xs flex items-center justify-center gap-1.5 transition shadow"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Save SOAP Note & Mark Consultation Complete</span>
                  </button>
                </div>
              )}

              {/* TAB 2: VITALS HUD & PATIENT MEDICAL CHART */}
              {activeSideTab === 'chart' && (
                <div className="space-y-3">
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                      <div>
                        <span className="text-sm font-bold text-white">{appointment.patientName}</span>
                        <div className="text-[10px] text-slate-400 font-mono">
                          ID: {appointment.patientId} • Blood: {patient?.bloodGroup || 'O+'}
                        </div>
                      </div>
                      {onSelectPatient && (
                        <button
                          onClick={() => {
                            onClose();
                            onSelectPatient(appointment.patientId);
                          }}
                          className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-blue-400 text-[10px] font-semibold rounded border border-slate-700"
                        >
                          Full EMR Chart
                        </button>
                      )}
                    </div>

                    {/* Known Allergies Alert */}
                    <div className="mt-2.5 p-2 bg-red-950/40 border border-red-800/40 rounded flex items-start gap-2">
                      <AlertCircle className="w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="text-[10px] font-bold text-red-300 uppercase">Documented Allergies:</span>
                        <p className="text-[11px] text-red-200">
                          {patient?.allergies && patient.allergies.length > 0
                            ? patient.allergies.join(', ')
                            : 'No known drug allergies (NKDA)'}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Vitals Snapshot */}
                  <div>
                    <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1.5">
                      Baseline Vitals Snapshot
                    </span>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                        <span className="text-[9px] text-slate-400 uppercase">Blood Pressure</span>
                        <div className="text-sm font-bold text-slate-200 font-mono">
                          {patient?.vitals?.[0]?.bloodPressure || '128/82 mmHg'}
                        </div>
                        <span className="text-[9px] text-emerald-400">Normal Range</span>
                      </div>
                      <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                        <span className="text-[9px] text-slate-400 uppercase">Heart Rate</span>
                        <div className="text-sm font-bold text-slate-200 font-mono">
                          {patient?.vitals?.[0]?.heartRate || 74} bpm
                        </div>
                        <span className="text-[9px] text-emerald-400">Regular Sinus</span>
                      </div>
                      <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                        <span className="text-[9px] text-slate-400 uppercase">SpO2 Saturation</span>
                        <div className="text-sm font-bold text-slate-200 font-mono">
                          {patient?.vitals?.[0]?.spO2 || 98}%
                        </div>
                        <span className="text-[9px] text-emerald-400">Ambient Air</span>
                      </div>
                      <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                        <span className="text-[9px] text-slate-400 uppercase">Body Temp</span>
                        <div className="text-sm font-bold text-slate-200 font-mono">
                          {patient?.vitals?.[0]?.temperature || 98.6}°F
                        </div>
                        <span className="text-[9px] text-emerald-400">Afebrile</span>
                      </div>
                    </div>
                  </div>

                  {/* Current Active Medications */}
                  <div>
                    <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1.5">
                      Active Home Medications
                    </span>
                    <div className="space-y-1.5 max-h-36 overflow-y-auto">
                      {patient?.medications && patient.medications.length > 0 ? (
                        patient.medications.map((med) => (
                          <div
                            key={med.id}
                            className="p-2 bg-slate-950 rounded border border-slate-800 text-[11px] flex items-center justify-between"
                          >
                            <div>
                              <span className="font-semibold text-slate-200">{med.name}</span>
                              <div className="text-[10px] text-slate-400">
                                {med.dosage} • {med.frequency}
                              </div>
                            </div>
                            <span className="px-1.5 py-0.5 bg-emerald-500/20 text-emerald-400 rounded text-[9px]">
                              {med.status}
                            </span>
                          </div>
                        ))
                      ) : (
                        <p className="text-slate-500 text-[11px] italic">No active medications cataloged.</p>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: QUICK E-PRESCRIBE */}
              {activeSideTab === 'prescribe' && (
                <div className="space-y-3">
                  <div>
                    <h3 className="font-bold text-slate-100 text-xs flex items-center gap-1.5">
                      <Pill className="w-3.5 h-3.5 text-emerald-400" />
                      In-Consultation E-Prescription
                    </h3>
                    <p className="text-[10px] text-slate-400">
                      Transmit digital prescriptions directly to the hospital pharmacy during video visit.
                    </p>
                  </div>

                  {rxSuccessMessage && (
                    <div className="p-2.5 bg-emerald-950/60 border border-emerald-700/50 rounded text-emerald-300 text-[11px] flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                      <span>{rxSuccessMessage}</span>
                    </div>
                  )}

                  <form onSubmit={handlePrescribeQuickRx} className="space-y-2.5">
                    <div>
                      <label className="text-[10px] font-semibold text-slate-300 block mb-0.5">
                        Medication Name *
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Amlodipine Besylate, Lisinopril, Albuterol"
                        value={rxName}
                        onChange={(e) => setRxName(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-750 rounded p-2 text-slate-200 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                        required
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[10px] font-semibold text-slate-300 block mb-0.5">
                          Dosage / Strength *
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. 5 mg, 500 mg"
                          value={rxDosage}
                          onChange={(e) => setRxDosage(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-750 rounded p-2 text-slate-200 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                          required
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-semibold text-slate-300 block mb-0.5">Route</label>
                        <select
                          value={rxRoute}
                          onChange={(e) => setRxRoute(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-750 rounded p-2 text-slate-200 text-xs"
                        >
                          <option value="Oral">Oral</option>
                          <option value="Inhalation">Inhalation</option>
                          <option value="Sublingual">Sublingual</option>
                          <option value="Topical">Topical</option>
                          <option value="Subcutaneous">Subcutaneous</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="text-[10px] font-semibold text-slate-300 block mb-0.5">
                        Frequency & Instructions
                      </label>
                      <input
                        type="text"
                        value={rxFrequency}
                        onChange={(e) => setRxFrequency(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-750 rounded p-2 text-slate-200 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded text-xs flex items-center justify-center gap-1.5 transition shadow mt-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Transmit E-Prescription Now</span>
                    </button>
                  </form>
                </div>
              )}

              {/* TAB 4: IN-CALL ENCRYPTED CHAT */}
              {activeSideTab === 'chat' && (
                <div className="flex flex-col h-[320px] justify-between">
                  <div className="space-y-2 overflow-y-auto pr-1">
                    {chatMessages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`p-2 rounded-lg text-[11px] leading-relaxed ${
                          msg.sender === 'system'
                            ? 'bg-slate-950 text-slate-400 border border-slate-800 text-center text-[10px]'
                            : msg.sender === 'doctor'
                            ? 'bg-blue-600 text-white ml-6 rounded-br-none'
                            : 'bg-slate-800 text-slate-200 mr-6 rounded-bl-none border border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between text-[9px] opacity-75 mb-0.5">
                          <span>{msg.sender === 'doctor' ? 'You' : msg.sender === 'patient' ? appointment.patientName : 'System'}</span>
                          <span>{msg.time}</span>
                        </div>
                        <div>{msg.text}</div>
                      </div>
                    ))}
                  </div>

                  <form onSubmit={handleSendMessage} className="mt-2 flex gap-1.5 pt-2 border-t border-slate-800">
                    <input
                      type="text"
                      placeholder="Type secure message to patient..."
                      value={newChatMessage}
                      onChange={(e) => setNewChatMessage(e.target.value)}
                      className="flex-1 bg-slate-950 border border-slate-750 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                    <button
                      type="submit"
                      className="p-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded transition"
                      title="Send message"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </form>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
