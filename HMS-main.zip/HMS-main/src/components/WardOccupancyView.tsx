import React, { useState } from 'react';
import {
  BedDouble,
  Users,
  Search,
  CheckCircle2,
  AlertTriangle,
  Clock,
  UserPlus,
  UserMinus,
  Activity,
  Filter,
  Layers,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { WardBed } from '../types';

interface WardOccupancyViewProps {
  onSelectPatient: (id: string) => void;
}

export const WardOccupancyView: React.FC<WardOccupancyViewProps> = ({ onSelectPatient }) => {
  const { wardBeds, assignBedToPatient, releaseBed, patients, setActiveTab } = useHospital();

  const [selectedWard, setSelectedWard] = useState<string>('all');
  const [selectedBedToAssign, setSelectedBedToAssign] = useState<WardBed | null>(null);
  const [patientToAssignId, setPatientToAssignId] = useState<string>('');

  // Extract unique ward names
  const wardNames = Array.from(new Set(wardBeds.map((b) => b.wardName)));

  const filteredBeds = wardBeds.filter((bed) => {
    if (selectedWard !== 'all' && bed.wardName !== selectedWard) return false;
    return true;
  });

  const occupiedCount = wardBeds.filter((b) => b.status === 'Occupied').length;
  const availableCount = wardBeds.filter((b) => b.status === 'Available').length;
  const maintenanceCount = wardBeds.filter((b) => b.status === 'Maintenance').length;
  const occupancyRate = Math.round((occupiedCount / wardBeds.length) * 100);

  const unassignedPatients = patients.filter(
    (p) => (p.status === 'Inpatient' || p.status === 'Emergency') && (!p.wardOrRoom || p.wardOrRoom === 'Unassigned')
  );

  const handleAssignBed = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBedToAssign || !patientToAssignId) return;
    assignBedToPatient(selectedBedToAssign.id, patientToAssignId);
    setSelectedBedToAssign(null);
    setPatientToAssignId('');
  };

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-7xl mx-auto">
      {/* Top Occupancy Status Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-sm">
          <div className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
            Overall Hospital Occupancy
          </div>
          <div className="text-xl font-bold text-slate-800 mt-1 flex items-baseline gap-2">
            <span>{occupancyRate}%</span>
            <span className="text-xs font-mono text-slate-500">
              ({occupiedCount}/{wardBeds.length} Beds)
            </span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2 overflow-hidden">
            <div
              className={`h-1.5 rounded-full ${occupancyRate > 85 ? 'bg-amber-500' : 'bg-emerald-500'}`}
              style={{ width: `${occupancyRate}%` }}
            />
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-sm">
          <div className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
            Ready & Sanitized Beds
          </div>
          <div className="text-xl font-bold text-emerald-600 mt-1 font-mono">
            {availableCount} Available
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Ready for direct admissions</div>
        </div>

        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-sm">
          <div className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
            Occupied Inpatient Beds
          </div>
          <div className="text-xl font-bold text-blue-600 mt-1 font-mono">
            {occupiedCount} Occupied
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Continuous nursing telemetry</div>
        </div>

        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-sm">
          <div className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
            Sanitization / Maintenance
          </div>
          <div className="text-xl font-bold text-amber-600 mt-1 font-mono">
            {maintenanceCount} Units
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Turnaround cycle in progress</div>
        </div>
      </div>

      {/* Ward Filter Bar */}
      <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider mr-2 flex items-center gap-1">
            <Layers className="w-3.5 h-3.5 text-blue-600" /> Ward Section:
          </span>
          <button
            onClick={() => setSelectedWard('all')}
            className={`px-2.5 py-1 text-xs rounded font-medium transition ${
              selectedWard === 'all'
                ? 'bg-blue-600 text-white font-semibold'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            All Wards ({wardBeds.length})
          </button>
          {wardNames.map((ward) => {
            const count = wardBeds.filter((b) => b.wardName === ward).length;
            const occupied = wardBeds.filter((b) => b.wardName === ward && b.status === 'Occupied').length;
            return (
              <button
                key={ward}
                onClick={() => setSelectedWard(ward)}
                className={`px-2.5 py-1 text-xs rounded font-medium transition ${
                  selectedWard === ward
                    ? 'bg-blue-600 text-white font-semibold'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {ward} ({occupied}/{count})
              </button>
            );
          })}
        </div>

        {unassignedPatients.length > 0 && (
          <div className="text-xs text-amber-800 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded font-semibold flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
            <span>{unassignedPatients.length} Patients awaiting bed assignment</span>
          </div>
        )}
      </div>

      {/* High Density Ward Floor Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
        {filteredBeds.map((bed) => {
          const isOccupied = bed.status === 'Occupied';
          const isAvailable = bed.status === 'Available';
          const isMaintenance = bed.status === 'Maintenance';

          return (
            <div
              key={bed.id}
              className={`p-3.5 rounded-lg border transition-all shadow-xs flex flex-col justify-between ${
                isOccupied
                  ? 'bg-white border-blue-200 hover:border-blue-400'
                  : isAvailable
                  ? 'bg-slate-50 border-emerald-200 hover:border-emerald-400'
                  : 'bg-amber-50/50 border-amber-200'
              }`}
            >
              <div>
                {/* Bed Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <BedDouble
                      className={`w-4 h-4 ${
                        isOccupied ? 'text-blue-600' : isAvailable ? 'text-emerald-600' : 'text-amber-600'
                      }`}
                    />
                    <span className="font-bold text-xs text-slate-800 font-mono">{bed.bedNumber}</span>
                  </div>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                      isOccupied
                        ? 'bg-blue-100 text-blue-800'
                        : isAvailable
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {bed.status}
                  </span>
                </div>

                <div className="text-[11px] text-slate-500 font-medium mt-1">{bed.wardName}</div>

                {/* Patient Information if occupied */}
                {isOccupied && bed.patientName && (
                  <div className="mt-3 p-2 bg-slate-50 rounded border border-slate-100 text-xs">
                    <button
                      onClick={() => {
                        if (bed.patientId) {
                          onSelectPatient(bed.patientId);
                          setActiveTab('patients');
                        }
                      }}
                      className="font-bold text-slate-800 hover:text-blue-600 truncate block text-left"
                    >
                      {bed.patientName}
                    </button>
                    <div className="text-[10px] text-slate-500 mt-0.5">
                      Attending: {bed.assignedDoctor || 'On-Duty Chief'}
                    </div>
                    {bed.admissionDate && (
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                        Admitted: {bed.admissionDate}
                      </div>
                    )}
                  </div>
                )}

                {isAvailable && (
                  <div className="mt-4 p-2 bg-emerald-50/50 rounded border border-emerald-100 text-[11px] text-emerald-800">
                    Sanitized & ready for admission protocol.
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between">
                {isOccupied ? (
                  <button
                    onClick={() => {
                      if (window.confirm(`Release bed ${bed.bedNumber} and clear patient assignment?`)) {
                        releaseBed(bed.id);
                      }
                    }}
                    className="text-[11px] text-rose-600 hover:text-rose-800 font-semibold flex items-center gap-1"
                  >
                    <UserMinus className="w-3 h-3" /> Release Bed
                  </button>
                ) : isAvailable ? (
                  <button
                    onClick={() => setSelectedBedToAssign(bed)}
                    className="text-[11px] text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1"
                  >
                    <UserPlus className="w-3 h-3" /> Assign Patient
                  </button>
                ) : (
                  <span className="text-[10px] text-amber-700">Cleaning protocol in progress</span>
                )}
                <span className="text-[10px] font-mono text-slate-400">{bed.id}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Assign Patient Bed Modal */}
      {selectedBedToAssign && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-md w-full p-4 text-xs">
            <div className="flex justify-between items-center pb-2 border-b border-slate-200">
              <h3 className="font-bold text-sm text-slate-800">
                Assign Bed: {selectedBedToAssign.bedNumber} ({selectedBedToAssign.wardName})
              </h3>
              <button
                onClick={() => setSelectedBedToAssign(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAssignBed} className="mt-3 space-y-3">
              <div>
                <label className="text-[11px] font-bold text-slate-600 block mb-1">
                  Select Inpatient to Admit
                </label>
                <select
                  value={patientToAssignId}
                  onChange={(e) => setPatientToAssignId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-xs"
                  required
                >
                  <option value="">-- Choose Inpatient --</option>
                  {patients.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.firstName} {p.lastName} ({p.id}) - {p.status} {p.wardOrRoom ? `[Current: ${p.wardOrRoom}]` : ''}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSelectedBedToAssign(null)}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded font-semibold shadow-sm"
                >
                  Confirm Bed Assignment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
