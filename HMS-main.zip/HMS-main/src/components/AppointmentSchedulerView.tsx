import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  Plus,
  Search,
  Filter,
  UserCheck,
  PhoneCall,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Stethoscope,
  ChevronRight,
  User,
  Building,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { AppointmentStatus, AppointmentPriority } from '../types';

interface AppointmentSchedulerViewProps {
  onOpenNewAppointment: () => void;
  onSelectPatient: (id: string) => void;
}

export const AppointmentSchedulerView: React.FC<AppointmentSchedulerViewProps> = ({
  onOpenNewAppointment,
  onSelectPatient,
}) => {
  const {
    appointments,
    updateAppointmentStatus,
    callNextAppointment,
    doctors,
    setActiveTab,
    addNotification,
  } = useHospital();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [activeCallId, setActiveCallId] = useState<string | null>(null);

  // Filter appointments
  const filteredAppointments = appointments.filter((appt) => {
    const matchesSearch =
      appt.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      appt.patientId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      appt.reason.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;
    if (selectedDoctorId !== 'all' && appt.doctorId !== selectedDoctorId) return false;
    if (selectedStatus !== 'all' && appt.status.toLowerCase() !== selectedStatus.toLowerCase()) return false;
    return true;
  });

  const handleCallPatient = (appt: typeof appointments[0]) => {
    setActiveCallId(appt.id);
    updateAppointmentStatus(appt.id, 'In Consultation');
    addNotification(
      `Queue Summon: ${appt.patientName}`,
      `Summoned to ${appt.roomNumber} for consultation with ${appt.doctorName}`,
      'info',
      appt.id
    );
    setTimeout(() => {
      setActiveCallId(null);
    }, 2500);
  };

  const activeQueue = appointments.filter(
    (a) => a.status === 'Checked-In' || a.status === 'In Consultation' || a.status === 'Scheduled'
  );

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-7xl mx-auto">
      {/* Top Header & Queue Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-sm">
          <div className="text-[11px] font-bold uppercase text-slate-500">Active Clinic Queue</div>
          <div className="text-xl font-bold text-slate-800 mt-1 flex items-baseline gap-2">
            <span>{activeQueue.length} Patients</span>
            <span className="text-xs font-semibold text-blue-600 font-mono">Real-time</span>
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-sm">
          <div className="text-[11px] font-bold uppercase text-slate-500">Checked In (Waiting)</div>
          <div className="text-xl font-bold text-emerald-600 mt-1">
            {appointments.filter((a) => a.status === 'Checked-In').length} In Waiting Lounge
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-sm">
          <div className="text-[11px] font-bold uppercase text-slate-500">In Consultation Now</div>
          <div className="text-xl font-bold text-blue-600 mt-1">
            {appointments.filter((a) => a.status === 'In Consultation').length} In Rooms
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <div className="text-[11px] font-bold uppercase text-slate-500">Auto Queue Caller</div>
            <button
              onClick={() => callNextAppointment()}
              className="mt-1 px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition shadow-sm"
            >
              <PhoneCall className="w-3 h-3" /> Call Next in Queue
            </button>
          </div>
        </div>
      </div>

      {/* Filter and Action Bar */}
      <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          {/* Search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              id="appointment-search-input"
              placeholder="Search patient, doctor, or condition..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-56 sm:w-64 bg-slate-50 border border-slate-200 rounded-md py-1.5 pl-8 pr-3 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 text-slate-800 placeholder-slate-400"
            />
          </div>

          {/* Doctor Filter */}
          <select
            id="appointment-doctor-filter"
            value={selectedDoctorId}
            onChange={(e) => setSelectedDoctorId(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-md py-1.5 px-2.5 text-xs text-slate-700 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          >
            <option value="all">All Doctors</option>
            {doctors.map((doc) => (
              <option key={doc.id} value={doc.id}>
                {doc.name.replace(', MD', '').replace(', FACS', '')} ({doc.specialty})
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            id="appointment-status-filter"
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-md py-1.5 px-2.5 text-xs text-slate-700 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          >
            <option value="all">All Statuses</option>
            <option value="Scheduled">Scheduled</option>
            <option value="Checked-In">Checked In</option>
            <option value="In Consultation">In Consultation</option>
            <option value="Completed">Completed</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>

        <button
          id="book-appointment-button"
          onClick={onOpenNewAppointment}
          className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition shadow-sm self-start md:self-auto shrink-0"
        >
          <Plus className="w-3.5 h-3.5" /> Book Appointment
        </button>
      </div>

      {/* High Density Real-Time Appointments Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-100/80 text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                <th className="py-2.5 px-3">Queue #</th>
                <th className="py-2.5 px-3">Slot / Time</th>
                <th className="py-2.5 px-3">Patient</th>
                <th className="py-2.5 px-3">Physician & Room</th>
                <th className="py-2.5 px-3">Clinical Reason</th>
                <th className="py-2.5 px-3">Priority</th>
                <th className="py-2.5 px-3">Queue Status</th>
                <th className="py-2.5 px-3 text-right">Workflow Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-normal">
              {filteredAppointments.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    No appointments found matching your search parameters.
                  </td>
                </tr>
              ) : (
                filteredAppointments.map((appt) => {
                  const isBeingCalled = activeCallId === appt.id;

                  return (
                    <tr
                      key={appt.id}
                      className={`hover:bg-slate-50 transition-colors ${
                        isBeingCalled ? 'bg-blue-50 animate-pulse' : ''
                      }`}
                    >
                      {/* Queue Number */}
                      <td className="py-2.5 px-3 font-mono font-bold text-slate-600">
                        #{appt.queueNumber.toString().padStart(2, '0')}
                      </td>

                      {/* Time Slot */}
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <span className="font-mono font-semibold text-slate-800">{appt.timeSlot}</span>
                        <div className="text-[10px] text-slate-400 font-mono">{appt.date}</div>
                      </td>

                      {/* Patient */}
                      <td className="py-2.5 px-3">
                        <button
                          onClick={() => {
                            onSelectPatient(appt.patientId);
                            setActiveTab('patients');
                          }}
                          className="font-semibold text-slate-800 hover:text-blue-600 block text-left truncate max-w-[140px]"
                        >
                          {appt.patientName}
                        </button>
                        <span className="text-[10px] font-mono text-slate-400">
                          {appt.patientId} • {appt.patientAge}y {appt.patientGender[0]}
                        </span>
                      </td>

                      {/* Doctor & Room */}
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <div className="font-medium text-slate-800">
                          {appt.doctorName.replace(', MD', '').replace(', FACS', '')}
                        </div>
                        <div className="text-[10px] text-slate-500 flex items-center gap-1">
                          <Building className="w-2.5 h-2.5 text-slate-400" />
                          <span>{appt.roomNumber}</span> • <span>{appt.department}</span>
                        </div>
                      </td>

                      {/* Clinical Reason */}
                      <td className="py-2.5 px-3">
                        <span className="text-slate-700 line-clamp-1 max-w-[200px]" title={appt.reason}>
                          {appt.reason}
                        </span>
                      </td>

                      {/* Priority */}
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                            appt.priority === 'Emergency'
                              ? 'bg-red-100 text-red-800'
                              : appt.priority === 'Urgent'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {appt.priority}
                        </span>
                      </td>

                      {/* Status */}
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                            appt.status === 'In Consultation'
                              ? 'bg-blue-100 text-blue-800'
                              : appt.status === 'Checked-In'
                              ? 'bg-emerald-100 text-emerald-800'
                              : appt.status === 'Scheduled'
                              ? 'bg-slate-100 text-slate-700'
                              : appt.status === 'Completed'
                              ? 'bg-gray-100 text-gray-600'
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {appt.status}
                        </span>
                      </td>

                      {/* Workflow Actions */}
                      <td className="py-2.5 px-3 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          {appt.status === 'Scheduled' && (
                            <button
                              onClick={() => updateAppointmentStatus(appt.id, 'Checked-In')}
                              className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[10px] font-semibold flex items-center gap-1 shadow-2xs"
                              title="Check in arrived patient"
                            >
                              <UserCheck className="w-3 h-3" /> Check In
                            </button>
                          )}

                          {appt.status === 'Checked-In' && (
                            <button
                              onClick={() => handleCallPatient(appt)}
                              className="px-2 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded text-[10px] font-semibold flex items-center gap-1 shadow-2xs"
                              title="Call patient into consultation room"
                            >
                              <PhoneCall className="w-3 h-3" /> Call to Room
                            </button>
                          )}

                          {appt.status === 'In Consultation' && (
                            <button
                              onClick={() => updateAppointmentStatus(appt.id, 'Completed')}
                              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded text-[10px] font-semibold flex items-center gap-1"
                              title="Mark appointment finished"
                            >
                              <CheckCircle2 className="w-3 h-3" /> Conclude
                            </button>
                          )}

                          {appt.status !== 'Completed' && appt.status !== 'Cancelled' && (
                            <button
                              onClick={() => updateAppointmentStatus(appt.id, 'Cancelled')}
                              className="px-1.5 py-1 text-slate-400 hover:text-red-600 rounded text-[10px]"
                              title="Cancel slot"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        <div className="p-2.5 bg-slate-50 border-t border-slate-200 text-[11px] text-slate-500 flex items-center justify-between">
          <span>{filteredAppointments.length} appointment slots scheduled</span>
          <span className="font-mono text-[10px] text-slate-400">Real-time sync active</span>
        </div>
      </div>
    </div>
  );
};
