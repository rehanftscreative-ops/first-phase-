import React, { useState } from 'react';
import { X, Calendar, Clock, Stethoscope, AlertTriangle } from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { AppointmentPriority } from '../types';

interface NewAppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewAppointmentModal: React.FC<NewAppointmentModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { bookAppointment, doctors, patients, setActiveTab } = useHospital();

  const [patientId, setPatientId] = useState<string>(patients[0]?.id || '');
  const [doctorId, setDoctorId] = useState<string>(doctors[0]?.id || '');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [timeSlot, setTimeSlot] = useState<string>('11:00 AM');
  const [type, setType] = useState<any>('General Consultation');
  const [priority, setPriority] = useState<AppointmentPriority>('Normal');
  const [reason, setReason] = useState<string>('Routine clinical evaluation and symptoms review.');
  const [notes, setNotes] = useState<string>('Check baseline telemetry');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const selectedPatient = patients.find((p) => p.id === patientId);
    const selectedDoctor = doctors.find((d) => d.id === doctorId);

    if (!selectedPatient || !selectedDoctor) return;

    const isTele = type.includes('Telehealth') || type.includes('Remote');
    const virtualRoomId = `TH-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;

    bookAppointment({
      patientId: selectedPatient.id,
      patientName: `${selectedPatient.firstName} ${selectedPatient.lastName}`,
      patientAge: selectedPatient.age,
      patientGender: selectedPatient.gender,
      doctorId: selectedDoctor.id,
      doctorName: selectedDoctor.name,
      department: selectedDoctor.department,
      roomNumber: isTele ? 'Virtual Video Room' : selectedDoctor.roomNumber,
      date,
      timeSlot,
      type,
      status: 'Scheduled',
      priority,
      reason,
      notes,
      isTelehealth: isTele,
      telehealthDetails: isTele ? {
        platform: 'WebRTC Clinical Room',
        roomId: virtualRoomId,
        meetingLink: `https://telehealth.medcore.health/room/${virtualRoomId}`,
        patientStatus: 'Scheduled / Not Joined',
        telehealthConsentSigned: true,
      } : undefined,
    });

    onClose();
    setActiveTab('appointments');
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 z-50">
      <div className="bg-white rounded-lg border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden text-xs">
        {/* Header */}
        <div className="p-3.5 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-blue-400" />
            <h2 className="font-bold text-sm text-white">Book Real-Time Appointment</h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-4 space-y-3">
          <div>
            <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">
              Select Patient *
            </label>
            <select
              value={patientId}
              onChange={(e) => setPatientId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs focus:ring-1 focus:ring-blue-500"
              required
            >
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.firstName} {p.lastName} ({p.id}) - Blood: {p.bloodGroup}, Age: {p.age}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">
              Select Consulting Physician *
            </label>
            <select
              value={doctorId}
              onChange={(e) => setDoctorId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs focus:ring-1 focus:ring-blue-500"
              required
            >
              {doctors.map((doc) => (
                <option key={doc.id} value={doc.id}>
                  {doc.name} • {doc.specialty} ({doc.roomNumber})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">Date</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs font-mono"
                required
              />
            </div>

            <div>
              <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">Time Slot</label>
              <select
                value={timeSlot}
                onChange={(e) => setTimeSlot(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs font-mono"
              >
                <option value="09:00 AM">09:00 AM</option>
                <option value="09:30 AM">09:30 AM</option>
                <option value="10:00 AM">10:00 AM</option>
                <option value="10:30 AM">10:30 AM</option>
                <option value="11:00 AM">11:00 AM</option>
                <option value="11:30 AM">11:30 AM</option>
                <option value="01:30 PM">01:30 PM</option>
                <option value="02:00 PM">02:00 PM</option>
                <option value="02:30 PM">02:30 PM</option>
                <option value="03:00 PM">03:00 PM</option>
                <option value="04:00 PM">04:00 PM</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">Type</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs"
              >
                <option value="General Consultation">General Consultation (In-Clinic)</option>
                <option value="Telehealth Consultation">📹 Telehealth Consultation (Remote Video)</option>
                <option value="Remote Follow-up">📹 Remote Follow-up (Video)</option>
                <option value="Follow-up">In-Clinic Follow-up</option>
                <option value="Specialist Review">Specialist Review</option>
                <option value="Emergency Triage">Emergency Triage</option>
                <option value="Lab Review">Lab Review</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as AppointmentPriority)}
                className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs font-semibold"
              >
                <option value="Normal">Normal</option>
                <option value="Urgent">Urgent</option>
                <option value="Emergency">Emergency</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">
              Reason for Visit / Chief Symptoms
            </label>
            <input
              type="text"
              required
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs"
              placeholder="e.g. Follow-up after post-operative physical therapy"
            />
          </div>

          <div className="pt-2 border-t border-slate-200 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-semibold text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded font-semibold text-xs shadow-sm"
            >
              Schedule Slot & Assign Queue #
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
