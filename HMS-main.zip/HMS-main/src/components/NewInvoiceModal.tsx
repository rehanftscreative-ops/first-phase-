import React, { useState } from 'react';
import { X, ReceiptText, Plus, Trash2, ShieldCheck, DollarSign } from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { BillItem } from '../types';

interface NewInvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewInvoiceModal: React.FC<NewInvoiceModalProps> = ({ isOpen, onClose }) => {
  const { createInvoice, patients, setActiveTab } = useHospital();

  const [patientId, setPatientId] = useState<string>(patients[0]?.id || '');
  const [items, setItems] = useState<BillItem[]>([
    {
      id: 'ITEM-1',
      description: 'Specialist Physician Consultation Fee',
      category: 'Consultation',
      unitCost: 150,
      quantity: 1,
      amount: 150,
    },
    {
      id: 'ITEM-2',
      description: 'Cardiac Telemetry & Continuous Monitoring (24h)',
      category: 'Room & Nursing',
      unitCost: 280,
      quantity: 1,
      amount: 280,
    },
  ]);

  const [newItemDesc, setNewItemDesc] = useState('');
  const [newItemCost, setNewItemCost] = useState(50);
  const [newItemCat, setNewItemCat] = useState<BillItem['category']>('Lab Test');

  const selectedPatient = patients.find((p) => p.id === patientId) || patients[0];

  const subtotal = items.reduce((acc, item) => acc + item.amount, 0);
  const tax = Number((subtotal * 0.04).toFixed(2));
  const total = subtotal + tax;

  const coverageRatio = selectedPatient ? selectedPatient.insurance.coveragePercentage / 100 : 0.8;
  const insuranceCovered = Number((subtotal * coverageRatio).toFixed(2));
  const copay = selectedPatient ? selectedPatient.insurance.copayAmount : 30;

  if (!isOpen) return null;

  const handleAddItem = () => {
    if (!newItemDesc.trim()) return;
    const newItem: BillItem = {
      id: `ITEM-${Date.now()}`,
      description: newItemDesc,
      category: newItemCat,
      unitCost: newItemCost,
      quantity: 1,
      amount: newItemCost,
    };
    setItems([...items, newItem]);
    setNewItemDesc('');
    setNewItemCost(50);
  };

  const handleRemoveItem = (id: string) => {
    setItems(items.filter((i) => i.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatient || items.length === 0) return;

    createInvoice({
      patientId: selectedPatient.id,
      patientName: `${selectedPatient.firstName} ${selectedPatient.lastName}`,
      patientPhone: selectedPatient.phone,
      patientEmail: selectedPatient.email,
      issueDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 14).toISOString().split('T')[0],
      items,
      tax,
      totalAmount: total,
      insuranceCoveredAmount: insuranceCovered,
      copayAmount: copay,
      status: 'Pending',
      notes: 'Generated via MedCore HMS Billing Subsystem.',
    });

    onClose();
    setActiveTab('billing');
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 z-50">
      <div className="bg-white rounded-lg border border-slate-200 shadow-2xl max-w-xl w-full max-h-[90vh] flex flex-col overflow-hidden text-xs">
        {/* Header */}
        <div className="p-3.5 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ReceiptText className="w-4 h-4 text-emerald-400" />
            <h2 className="font-bold text-sm text-white">Generate Medical Billing Statement</h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 space-y-4 overflow-y-auto flex-1">
          <div>
            <label className="text-[10px] font-semibold text-slate-600 block mb-0.5">
              Select Patient Account *
            </label>
            <select
              value={patientId}
              onChange={(e) => setPatientId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs focus:ring-1 focus:ring-blue-500"
              required
            >
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.firstName} {p.lastName} ({p.id}) - Insured: {p.insurance.provider} ({p.insurance.coveragePercentage}%)
                </option>
              ))}
            </select>
          </div>

          {/* Add Line Item Sub-form */}
          <div className="p-2.5 bg-slate-50 border border-slate-200 rounded space-y-2">
            <div className="text-[10px] font-bold text-slate-500 uppercase">
              Add Medical Charge / Supply
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
              <div className="sm:col-span-2">
                <input
                  type="text"
                  placeholder="Service or drug name..."
                  value={newItemDesc}
                  onChange={(e) => setNewItemDesc(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded p-1 text-xs"
                />
              </div>
              <div>
                <select
                  value={newItemCat}
                  onChange={(e) => setNewItemCat(e.target.value as any)}
                  className="w-full bg-white border border-slate-300 rounded p-1 text-xs"
                >
                  <option value="Consultation">Consultation</option>
                  <option value="Lab Test">Lab Test</option>
                  <option value="Radiology">Radiology</option>
                  <option value="Pharmacy">Pharmacy</option>
                  <option value="Room & Nursing">Room & Nursing</option>
                  <option value="Surgical Procedure">Surgical</option>
                </select>
              </div>
              <div className="flex gap-1">
                <input
                  type="number"
                  placeholder="$ Cost"
                  value={newItemCost}
                  onChange={(e) => setNewItemCost(Number(e.target.value))}
                  className="w-full bg-white border border-slate-300 rounded p-1 text-xs font-mono"
                />
                <button
                  type="button"
                  onClick={handleAddItem}
                  className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded font-bold"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* Line Items List */}
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1">
              Line Items ({items.length})
            </div>
            <div className="divide-y divide-slate-100 border border-slate-200 rounded max-h-40 overflow-y-auto">
              {items.map((item) => (
                <div key={item.id} className="p-2 flex items-center justify-between text-xs hover:bg-slate-50">
                  <div>
                    <div className="font-semibold text-slate-800">{item.description}</div>
                    <span className="text-[10px] text-slate-400">{item.category}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-mono font-bold text-slate-700">${item.amount.toFixed(2)}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveItem(item.id)}
                      className="text-slate-400 hover:text-red-500 p-0.5"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Live Totals Card */}
          <div className="bg-slate-50 p-3 rounded border border-slate-200 space-y-1 text-xs font-mono">
            <div className="flex justify-between text-slate-600">
              <span>Gross Subtotal</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Surcharge / Tax</span>
              <span>${tax.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-blue-600">
              <span>Est. Insurance Covered ({selectedPatient?.insurance.coveragePercentage}%)</span>
              <span>-${insuranceCovered.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Standard Copay</span>
              <span>${copay.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-slate-900 font-bold text-sm border-t border-slate-200 pt-1">
              <span>Total Invoice Amount</span>
              <span>${total.toFixed(2)}</span>
            </div>
          </div>

          {/* Actions */}
          <div className="pt-2 border-t border-slate-200 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-semibold text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded font-semibold text-xs shadow-sm flex items-center gap-1.5"
            >
              <DollarSign className="w-3.5 h-3.5" /> Post Invoice to Ledger
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
