import React, { useState } from 'react';
import {
  Users,
  Search,
  Plus,
  Filter,
  Activity,
  FileText,
  Pill,
  TestTube2,
  ShieldCheck,
  ChevronRight,
  Heart,
  Thermometer,
  Wind,
  Droplets,
  AlertTriangle,
  Calendar,
  Phone,
  Mail,
  MapPin,
  CheckCircle2,
  X,
  Clock,
  UserX,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { Patient, PatientStatus, BloodGroup } from '../types';

interface PatientRecordsViewProps {
  onOpenNewPatient: () => void;
  selectedPatientId: string | null;
  onSelectPatient: (id: string | null) => void;
}

export const PatientRecordsView: React.FC<PatientRecordsViewProps> = ({
  onOpenNewPatient,
  selectedPatientId,
  onSelectPatient,
}) => {
  const {
    patients,
    addVitals,
    addMedication,
    addClinicalNote,
    addLabResult,
    dischargePatient,
    doctors,
  } = useHospital();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [activeDetailTab, setActiveDetailTab] = useState<'vitals' | 'meds' | 'labs' | 'notes' | 'insurance'>('vitals');

  // Form states inside patient chart drawer
  const [showVitalsForm, setShowVitalsForm] = useState(false);
  const [vitalsData, setVitalsData] = useState({
    heartRate: 75,
    bloodPressureSys: 120,
    bloodPressureDia: 80,
    spO2: 98,
    temperature: 98.6,
    respiratoryRate: 16,
  });

  const [showMedForm, setShowMedForm] = useState(false);
  const [medData, setMedData] = useState({
    name: '',
    dosage: '',
    frequency: 'Once daily',
    route: 'Oral',
    prescribedBy: 'Dr. Sarah Jenkins, MD',
    startDate: new Date().toISOString().split('T')[0],
    status: 'Active' as const,
  });

  const [showNoteForm, setShowNoteForm] = useState(false);
  const [noteData, setNoteData] = useState({
    doctorName: 'Dr. Julian Thorne, MD',
    doctorSpecialty: 'Internal Medicine',
    chiefComplaint: '',
    assessment: '',
    treatmentPlan: '',
    diagnosisCode: 'ICD-10 Z00.0',
  });

  const [showLabForm, setShowLabForm] = useState(false);
  const [labData, setLabData] = useState({
    testName: '',
    category: 'Hematology' as const,
    orderedDate: new Date().toISOString().split('T')[0],
    resultDate: new Date().toISOString().split('T')[0],
    status: 'Normal' as const,
    value: '',
    referenceRange: '',
    orderedBy: 'Dr. Sarah Jenkins, MD',
    notes: '',
  });

  // Filter patients
  const filteredPatients = patients.filter((p) => {
    const matchesSearch =
      `${p.firstName} ${p.lastName}`.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.chronicConditions.some((c) => c.toLowerCase().includes(searchQuery.toLowerCase()));

    if (!matchesSearch) return false;
    if (statusFilter === 'all') return true;
    return p.status.toLowerCase() === statusFilter.toLowerCase();
  });

  const activePatient = patients.find((p) => p.id === selectedPatientId) || null;

  const handleSaveVitals = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePatient) return;
    addVitals(activePatient.id, vitalsData);
    setShowVitalsForm(false);
  };

  const handleSaveMedication = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePatient || !medData.name) return;
    addMedication(activePatient.id, medData);
    setShowMedForm(false);
    setMedData({
      name: '',
      dosage: '',
      frequency: 'Once daily',
      route: 'Oral',
      prescribedBy: 'Dr. Sarah Jenkins, MD',
      startDate: new Date().toISOString().split('T')[0],
      status: 'Active',
    });
  };

  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePatient || !noteData.assessment) return;
    addClinicalNote(activePatient.id, noteData);
    setShowNoteForm(false);
    setNoteData({
      doctorName: 'Dr. Julian Thorne, MD',
      doctorSpecialty: 'Internal Medicine',
      chiefComplaint: '',
      assessment: '',
      treatmentPlan: '',
      diagnosisCode: 'ICD-10 Z00.0',
    });
  };

  const handleSaveLab = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePatient || !labData.testName) return;
    addLabResult(activePatient.id, labData);
    setShowLabForm(false);
    setLabData({
      testName: '',
      category: 'Hematology',
      orderedDate: new Date().toISOString().split('T')[0],
      resultDate: new Date().toISOString().split('T')[0],
      status: 'Normal',
      value: '',
      referenceRange: '',
      orderedBy: 'Dr. Sarah Jenkins, MD',
      notes: '',
    });
  };

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-7xl mx-auto">
      {/* Top Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3.5 rounded-lg border border-slate-200 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
            <Users className="w-4 h-4" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
              Patient Health Records (EHR)
            </h1>
            <p className="text-xs text-slate-500">
              {filteredPatients.length} records indexed • Encrypted HL7 FHIR Compatible
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Search bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              id="patient-search-input"
              placeholder="Search by name, ID or diagnosis..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-56 sm:w-64 bg-slate-50 border border-slate-200 rounded-md py-1.5 pl-8 pr-3 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 text-slate-800 placeholder-slate-400 transition"
            />
          </div>

          {/* Status Filter */}
          <select
            id="patient-status-filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-md py-1.5 px-2.5 text-xs text-slate-700 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          >
            <option value="all">All Statuses</option>
            <option value="Inpatient">Inpatient</option>
            <option value="Outpatient">Outpatient</option>
            <option value="Emergency">Emergency</option>
            <option value="Discharged">Discharged</option>
          </select>

          <button
            id="admit-patient-button"
            onClick={onOpenNewPatient}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition shadow-sm shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Admit Patient</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Patients Table & Optional Active Chart Drawer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Patient Records Table (High Density) */}
        <div
          className={`bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden flex flex-col ${
            activePatient ? 'lg:col-span-6' : 'lg:col-span-12'
          }`}
        >
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-100/80 text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                  <th className="py-2.5 px-3">Patient Record</th>
                  <th className="py-2.5 px-3">Age / Blood</th>
                  <th className="py-2.5 px-3">Status / Bed</th>
                  <th className="py-2.5 px-3">Attending Physician</th>
                  <th className="py-2.5 px-3">Primary Diagnosis</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-normal">
                {filteredPatients.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-slate-400 text-xs">
                      No patients found matching current search or filters.
                    </td>
                  </tr>
                ) : (
                  filteredPatients.map((patient) => {
                    const isSelected = selectedPatientId === patient.id;
                    const latestVitals = patient.vitals[0];

                    return (
                      <tr
                        key={patient.id}
                        onClick={() => onSelectPatient(patient.id)}
                        className={`hover:bg-blue-50/40 cursor-pointer transition-colors ${
                          isSelected ? 'bg-blue-50 border-l-4 border-l-blue-600' : ''
                        }`}
                      >
                        <td className="py-2.5 px-3">
                          <div className="font-semibold text-slate-800 flex items-center gap-1.5">
                            <span>
                              {patient.firstName} {patient.lastName}
                            </span>
                          </div>
                          <div className="text-[10px] font-mono text-slate-400">ID: {patient.id}</div>
                        </td>

                        <td className="py-2.5 px-3 whitespace-nowrap">
                          <span className="text-slate-700 font-medium">{patient.age}y</span> •{' '}
                          <span className="font-semibold px-1 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px]">
                            {patient.bloodGroup}
                          </span>
                        </td>

                        <td className="py-2.5 px-3 whitespace-nowrap">
                          <span
                            className={`inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                              patient.status === 'Emergency'
                                ? 'bg-red-100 text-red-800'
                                : patient.status === 'Inpatient'
                                ? 'bg-amber-100 text-amber-800'
                                : patient.status === 'Outpatient'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {patient.status}
                          </span>
                          {patient.wardOrRoom && (
                            <div className="text-[10px] text-slate-500 font-mono mt-0.5 truncate max-w-[110px]">
                              {patient.wardOrRoom}
                            </div>
                          )}
                        </td>

                        <td className="py-2.5 px-3 text-slate-600 whitespace-nowrap">
                          <span className="text-xs">
                            {patient.primaryPhysicianName.replace(', MD', '').replace(', FACS', '')}
                          </span>
                        </td>

                        <td className="py-2.5 px-3">
                          <div className="text-[11px] text-slate-700 truncate max-w-[130px]">
                            {patient.chronicConditions[0] || 'No chronic conditions'}
                          </div>
                          {patient.allergies.length > 0 && (
                            <span className="inline-block text-[9px] text-rose-600 font-semibold uppercase tracking-wider">
                              Allergy: {patient.allergies[0].allergen}
                            </span>
                          )}
                        </td>

                        <td className="py-2.5 px-3 text-right whitespace-nowrap">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectPatient(isSelected ? null : patient.id);
                            }}
                            className={`px-2 py-1 rounded text-[11px] font-semibold transition ${
                              isSelected
                                ? 'bg-blue-600 text-white'
                                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                            }`}
                          >
                            {isSelected ? 'Viewing Chart' : 'Chart'}
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          <div className="p-2.5 bg-slate-50 border-t border-slate-200 text-[11px] text-slate-500 flex items-center justify-between">
            <span>Displaying {filteredPatients.length} patient records</span>
            <span className="font-mono text-[10px] text-slate-400">HL7 FHIR v4 compliant</span>
          </div>
        </div>

        {/* Clinical Patient Chart (Drawer/Panel when a patient is selected) */}
        {activePatient && (
          <div className="lg:col-span-6 bg-white rounded-lg border border-slate-200 shadow-sm flex flex-col overflow-hidden">
            {/* Chart Header */}
            <div className="p-4 bg-slate-900 text-white flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-bold text-white">
                    {activePatient.firstName} {activePatient.lastName}
                  </h2>
                  <span className="font-mono text-xs bg-slate-800 text-blue-300 px-1.5 py-0.5 rounded">
                    {activePatient.id}
                  </span>
                  <span
                    className={`text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded ${
                      activePatient.status === 'Emergency'
                        ? 'bg-red-500 text-white'
                        : activePatient.status === 'Inpatient'
                        ? 'bg-amber-500 text-white'
                        : 'bg-emerald-500 text-white'
                    }`}
                  >
                    {activePatient.status}
                  </span>
                </div>
                <div className="text-xs text-slate-300 mt-1 flex flex-wrap gap-x-4 gap-y-1">
                  <span>DOB: {activePatient.dob} ({activePatient.age}y)</span>
                  <span>Blood: <strong className="text-white">{activePatient.bloodGroup}</strong></span>
                  <span>Gender: {activePatient.gender}</span>
                  <span>Attending: {activePatient.primaryPhysicianName}</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {activePatient.status === 'Inpatient' && (
                  <button
                    onClick={() => {
                      if (window.confirm(`Discharge ${activePatient.firstName} ${activePatient.lastName} from hospital ward?`)) {
                        dischargePatient(activePatient.id);
                      }
                    }}
                    className="px-2 py-1 bg-red-600/80 hover:bg-red-600 text-white text-[10px] font-semibold rounded flex items-center gap-1 transition"
                    title="Discharge patient and release ward bed"
                  >
                    <UserX className="w-3 h-3" /> Discharge
                  </button>
                )}
                <button
                  onClick={() => onSelectPatient(null)}
                  className="p-1 text-slate-400 hover:text-white rounded"
                  title="Close chart view"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Quick Contact & Allergies Bar */}
            <div className="bg-slate-50 p-2.5 border-b border-slate-200 text-xs flex flex-wrap items-center justify-between gap-2 text-slate-600">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1">
                  <Phone className="w-3 h-3 text-slate-400" /> {activePatient.phone}
                </span>
                <span className="hidden sm:flex items-center gap-1">
                  <Mail className="w-3 h-3 text-slate-400" /> {activePatient.email}
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-bold uppercase text-slate-400">Allergies:</span>
                {activePatient.allergies.length === 0 ? (
                  <span className="text-slate-500 text-[11px]">NKDA (No Known Drug Allergies)</span>
                ) : (
                  activePatient.allergies.map((a, i) => (
                    <span
                      key={i}
                      className="px-1.5 py-0.5 bg-rose-100 text-rose-800 text-[10px] font-bold rounded"
                    >
                      {a.allergen} ({a.severity})
                    </span>
                  ))
                )}
              </div>
            </div>

            {/* Tabs for Vitals, Medications, Labs, Notes, Insurance */}
            <div className="flex border-b border-slate-200 bg-white">
              {[
                { id: 'vitals', label: 'Vitals & Telemetry', icon: Activity, count: activePatient.vitals.length },
                { id: 'meds', label: 'Medications', icon: Pill, count: activePatient.medications.length },
                { id: 'labs', label: 'Diagnostic Labs', icon: TestTube2, count: activePatient.labResults.length },
                { id: 'notes', label: 'Clinical Notes', icon: FileText, count: activePatient.clinicalNotes.length },
                { id: 'insurance', label: 'Insurance & Billing', icon: ShieldCheck, count: null },
              ].map((tab) => {
                const Icon = tab.icon;
                const isActive = activeDetailTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveDetailTab(tab.id as typeof activeDetailTab)}
                    className={`flex-1 py-2.5 px-2 text-center text-xs font-semibold flex items-center justify-center gap-1.5 border-b-2 transition ${
                      isActive
                        ? 'border-blue-600 text-blue-600 bg-blue-50/20'
                        : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">{tab.label}</span>
                    {tab.count !== null && (
                      <span className="text-[10px] font-mono bg-slate-100 px-1 py-0.2 rounded text-slate-600">
                        {tab.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Tab Content Container */}
            <div className="p-4 flex-1 overflow-y-auto max-h-[500px]">
              {/* TAB 1: VITALS */}
              {activeDetailTab === 'vitals' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                      Telemetry & Vitals History
                    </h3>
                    <button
                      onClick={() => setShowVitalsForm(!showVitalsForm)}
                      className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded flex items-center gap-1"
                    >
                      <Plus className="w-3 h-3" /> Log New Vitals
                    </button>
                  </div>

                  {/* Form to log new vitals */}
                  {showVitalsForm && (
                    <form onSubmit={handleSaveVitals} className="p-3 bg-slate-50 border border-slate-200 rounded-md space-y-3">
                      <div className="text-xs font-bold text-slate-800">Record Live Vitals</div>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                        <div>
                          <label className="text-[10px] text-slate-500 font-semibold block">Heart Rate (bpm)</label>
                          <input
                            type="number"
                            value={vitalsData.heartRate}
                            onChange={(e) => setVitalsData({ ...vitalsData, heartRate: Number(e.target.value) })}
                            className="w-full bg-white border border-slate-300 rounded p-1 text-xs"
                            required
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-500 font-semibold block">BP Systolic (mmHg)</label>
                          <input
                            type="number"
                            value={vitalsData.bloodPressureSys}
                            onChange={(e) => setVitalsData({ ...vitalsData, bloodPressureSys: Number(e.target.value) })}
                            className="w-full bg-white border border-slate-300 rounded p-1 text-xs"
                            required
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-500 font-semibold block">BP Diastolic (mmHg)</label>
                          <input
                            type="number"
                            value={vitalsData.bloodPressureDia}
                            onChange={(e) => setVitalsData({ ...vitalsData, bloodPressureDia: Number(e.target.value) })}
                            className="w-full bg-white border border-slate-300 rounded p-1 text-xs"
                            required
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-500 font-semibold block">SpO2 Oxygen (%)</label>
                          <input
                            type="number"
                            value={vitalsData.spO2}
                            onChange={(e) => setVitalsData({ ...vitalsData, spO2: Number(e.target.value) })}
                            className="w-full bg-white border border-slate-300 rounded p-1 text-xs"
                            required
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-500 font-semibold block">Temp (°F)</label>
                          <input
                            type="number"
                            step="0.1"
                            value={vitalsData.temperature}
                            onChange={(e) => setVitalsData({ ...vitalsData, temperature: Number(e.target.value) })}
                            className="w-full bg-white border border-slate-300 rounded p-1 text-xs"
                            required
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-500 font-semibold block">Respiration (br/m)</label>
                          <input
                            type="number"
                            value={vitalsData.respiratoryRate}
                            onChange={(e) => setVitalsData({ ...vitalsData, respiratoryRate: Number(e.target.value) })}
                            className="w-full bg-white border border-slate-300 rounded p-1 text-xs"
                            required
                          />
                        </div>
                      </div>
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setShowVitalsForm(false)}
                          className="px-2.5 py-1 text-xs text-slate-600 hover:bg-slate-200 rounded"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded"
                        >
                          Commit Record
                        </button>
                      </div>
                    </form>
                  )}

                  {/* Latest Vitals Snapshot Cards */}
                  {activePatient.vitals[0] && (
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <div className="p-2.5 bg-slate-50 border border-slate-200 rounded">
                        <div className="text-[10px] text-slate-500 font-semibold uppercase flex items-center gap-1">
                          <Heart className="w-3 h-3 text-rose-500" /> Heart Rate
                        </div>
                        <div className="text-lg font-bold font-mono text-slate-800 mt-1">
                          {activePatient.vitals[0].heartRate} <span className="text-[10px] font-normal text-slate-500">bpm</span>
                        </div>
                      </div>

                      <div className="p-2.5 bg-slate-50 border border-slate-200 rounded">
                        <div className="text-[10px] text-slate-500 font-semibold uppercase flex items-center gap-1">
                          <Activity className="w-3 h-3 text-blue-500" /> Blood Pressure
                        </div>
                        <div className="text-lg font-bold font-mono text-slate-800 mt-1">
                          {activePatient.vitals[0].bloodPressureSys}/{activePatient.vitals[0].bloodPressureDia}
                        </div>
                      </div>

                      <div className="p-2.5 bg-slate-50 border border-slate-200 rounded">
                        <div className="text-[10px] text-slate-500 font-semibold uppercase flex items-center gap-1">
                          <Droplets className="w-3 h-3 text-sky-500" /> SpO2 Oxygen
                        </div>
                        <div className="text-lg font-bold font-mono text-slate-800 mt-1">
                          {activePatient.vitals[0].spO2}%
                        </div>
                      </div>

                      <div className="p-2.5 bg-slate-50 border border-slate-200 rounded">
                        <div className="text-[10px] text-slate-500 font-semibold uppercase flex items-center gap-1">
                          <Thermometer className="w-3 h-3 text-amber-500" /> Temperature
                        </div>
                        <div className="text-lg font-bold font-mono text-slate-800 mt-1">
                          {activePatient.vitals[0].temperature}°F
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Vitals History List */}
                  <div className="space-y-2">
                    <div className="text-[11px] font-bold text-slate-500 uppercase">Chronological Records</div>
                    {activePatient.vitals.map((v, i) => (
                      <div key={i} className="p-2.5 bg-white border border-slate-200 rounded text-xs flex items-center justify-between">
                        <div className="space-y-0.5">
                          <div className="font-semibold text-slate-800">
                            HR {v.heartRate} bpm • BP {v.bloodPressureSys}/{v.bloodPressureDia} • SpO2 {v.spO2}% • {v.temperature}°F
                          </div>
                          <div className="text-[10px] text-slate-400">
                            Respiration: {v.respiratoryRate} breaths/min
                          </div>
                        </div>
                        <span className="text-[10px] font-mono text-slate-400">
                          {new Date(v.recordedAt).toLocaleString()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 2: MEDICATIONS */}
              {activeDetailTab === 'meds' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                      Prescribed Drug Regimen
                    </h3>
                    <button
                      onClick={() => setShowMedForm(!showMedForm)}
                      className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded flex items-center gap-1"
                    >
                      <Plus className="w-3 h-3" /> Prescribe Drug
                    </button>
                  </div>

                  {showMedForm && (
                    <form onSubmit={handleSaveMedication} className="p-3 bg-slate-50 border border-slate-200 rounded-md space-y-3">
                      <div className="text-xs font-bold text-slate-800">Prescribe Medication</div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                        <div>
                          <label className="text-[10px] text-slate-500 font-semibold block">Medication Name</label>
                          <input
                            type="text"
                            placeholder="e.g. Lisinopril"
                            value={medData.name}
                            onChange={(e) => setMedData({ ...medData, name: e.target.value })}
                            className="w-full bg-white border border-slate-300 rounded p-1 text-xs"
                            required
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-500 font-semibold block">Dosage</label>
                          <input
                            type="text"
                            placeholder="e.g. 10 mg"
                            value={medData.dosage}
                            onChange={(e) => setMedData({ ...medData, dosage: e.target.value })}
                            className="w-full bg-white border border-slate-300 rounded p-1 text-xs"
                            required
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-500 font-semibold block">Frequency</label>
                          <select
                            value={medData.frequency}
                            onChange={(e) => setMedData({ ...medData, frequency: e.target.value })}
                            className="w-full bg-white border border-slate-300 rounded p-1 text-xs"
                          >
                            <option value="Once daily">Once daily</option>
                            <option value="Twice daily">Twice daily</option>
                            <option value="Three times daily">Three times daily</option>
                            <option value="Every 4-6 hours PRN">Every 4-6 hours PRN</option>
                          </select>
                        </div>
                      </div>
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setShowMedForm(false)}
                          className="px-2.5 py-1 text-xs text-slate-600 hover:bg-slate-200 rounded"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded"
                        >
                          Sign & Prescribe
                        </button>
                      </div>
                    </form>
                  )}

                  <div className="space-y-2">
                    {activePatient.medications.length === 0 ? (
                      <div className="p-6 text-center text-xs text-slate-400">
                        No active medications prescribed for this patient.
                      </div>
                    ) : (
                      activePatient.medications.map((med) => (
                        <div key={med.id} className="p-3 bg-white border border-slate-200 rounded-md text-xs flex items-center justify-between">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-slate-800">{med.name}</span>
                              <span className="px-1.5 py-0.2 bg-blue-50 text-blue-700 text-[10px] font-mono rounded font-semibold">
                                {med.dosage}
                              </span>
                              <span className="text-[10px] text-slate-400">({med.route})</span>
                            </div>
                            <div className="text-[11px] text-slate-500 mt-0.5">
                              {med.frequency} • Prescribed by {med.prescribedBy} • Started: {med.startDate}
                            </div>
                          </div>
                          <span
                            className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                              med.status === 'Active'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {med.status}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

              {/* TAB 3: DIAGNOSTIC LABS */}
              {activeDetailTab === 'labs' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                      Laboratory & Radiology Orders
                    </h3>
                    <button
                      onClick={() => setShowLabForm(!showLabForm)}
                      className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded flex items-center gap-1"
                    >
                      <Plus className="w-3 h-3" /> Order Diagnostic Lab
                    </button>
                  </div>

                  {showLabForm && (
                    <form onSubmit={handleSaveLab} className="p-3 bg-slate-50 border border-slate-200 rounded-md space-y-3">
                      <div className="text-xs font-bold text-slate-800">Order New Diagnostic Test</div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                        <div>
                          <label className="text-[10px] text-slate-500 font-semibold block">Test Name</label>
                          <input
                            type="text"
                            placeholder="e.g. Complete Blood Count (CBC)"
                            value={labData.testName}
                            onChange={(e) => setLabData({ ...labData, testName: e.target.value })}
                            className="w-full bg-white border border-slate-300 rounded p-1 text-xs"
                            required
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-500 font-semibold block">Category</label>
                          <select
                            value={labData.category}
                            onChange={(e) => setLabData({ ...labData, category: e.target.value as any })}
                            className="w-full bg-white border border-slate-300 rounded p-1 text-xs"
                          >
                            <option value="Hematology">Hematology</option>
                            <option value="Radiology">Radiology</option>
                            <option value="Biochemistry">Biochemistry</option>
                            <option value="Pathology">Pathology</option>
                            <option value="Cardiology">Cardiology</option>
                          </select>
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-500 font-semibold block">Finding / Value</label>
                          <input
                            type="text"
                            placeholder="e.g. 14.2 g/dL"
                            value={labData.value}
                            onChange={(e) => setLabData({ ...labData, value: e.target.value })}
                            className="w-full bg-white border border-slate-300 rounded p-1 text-xs"
                            required
                          />
                        </div>
                      </div>
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setShowLabForm(false)}
                          className="px-2.5 py-1 text-xs text-slate-600 hover:bg-slate-200 rounded"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded"
                        >
                          Submit Lab Order
                        </button>
                      </div>
                    </form>
                  )}

                  <div className="space-y-2">
                    {activePatient.labResults.length === 0 ? (
                      <div className="p-6 text-center text-xs text-slate-400">
                        No lab diagnostic results recorded.
                      </div>
                    ) : (
                      activePatient.labResults.map((lab) => (
                        <div key={lab.id} className="p-3 bg-white border border-slate-200 rounded-md text-xs">
                          <div className="flex items-start justify-between">
                            <div>
                              <div className="font-bold text-slate-800">{lab.testName}</div>
                              <span className="text-[10px] font-mono text-slate-400">
                                {lab.category} • Ordered: {lab.orderedDate} by {lab.orderedBy}
                              </span>
                            </div>
                            <span
                              className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                                lab.status === 'Critical'
                                  ? 'bg-red-100 text-red-800'
                                  : lab.status === 'Elevated'
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-emerald-100 text-emerald-800'
                              }`}
                            >
                              {lab.status}
                            </span>
                          </div>
                          <div className="mt-2 p-2 bg-slate-50 rounded border border-slate-100 text-[11px] text-slate-700">
                            <strong>Observed Value:</strong> {lab.value}
                            {lab.referenceRange && (
                              <span className="text-slate-500 ml-2">
                                (Reference: {lab.referenceRange})
                              </span>
                            )}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

              {/* TAB 4: CLINICAL NOTES */}
              {activeDetailTab === 'notes' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                      Physician Consult & Progress Notes
                    </h3>
                    <button
                      onClick={() => setShowNoteForm(!showNoteForm)}
                      className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded flex items-center gap-1"
                    >
                      <Plus className="w-3 h-3" /> Add Clinical Note
                    </button>
                  </div>

                  {showNoteForm && (
                    <form onSubmit={handleSaveNote} className="p-3 bg-slate-50 border border-slate-200 rounded-md space-y-3">
                      <div className="text-xs font-bold text-slate-800">Append SOAP Clinical Note</div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        <div>
                          <label className="text-[10px] text-slate-500 font-semibold block">Chief Complaint</label>
                          <input
                            type="text"
                            placeholder="e.g. Chest tightness on exertion"
                            value={noteData.chiefComplaint}
                            onChange={(e) => setNoteData({ ...noteData, chiefComplaint: e.target.value })}
                            className="w-full bg-white border border-slate-300 rounded p-1 text-xs"
                            required
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-500 font-semibold block">ICU / ICD-10 Code</label>
                          <input
                            type="text"
                            placeholder="e.g. ICD-10 I20.9"
                            value={noteData.diagnosisCode}
                            onChange={(e) => setNoteData({ ...noteData, diagnosisCode: e.target.value })}
                            className="w-full bg-white border border-slate-300 rounded p-1 text-xs"
                            required
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="text-[10px] text-slate-500 font-semibold block">Assessment</label>
                          <textarea
                            rows={2}
                            placeholder="Clinical assessment details..."
                            value={noteData.assessment}
                            onChange={(e) => setNoteData({ ...noteData, assessment: e.target.value })}
                            className="w-full bg-white border border-slate-300 rounded p-1 text-xs"
                            required
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="text-[10px] text-slate-500 font-semibold block">Treatment Plan</label>
                          <textarea
                            rows={2}
                            placeholder="Immediate treatment protocol..."
                            value={noteData.treatmentPlan}
                            onChange={(e) => setNoteData({ ...noteData, treatmentPlan: e.target.value })}
                            className="w-full bg-white border border-slate-300 rounded p-1 text-xs"
                            required
                          />
                        </div>
                      </div>
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setShowNoteForm(false)}
                          className="px-2.5 py-1 text-xs text-slate-600 hover:bg-slate-200 rounded"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded"
                        >
                          Sign & Save Note
                        </button>
                      </div>
                    </form>
                  )}

                  <div className="space-y-3">
                    {activePatient.clinicalNotes.map((note) => (
                      <div key={note.id} className="p-3 bg-white border border-slate-200 rounded-md text-xs space-y-1.5">
                        <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
                          <div className="font-bold text-slate-800">
                            {note.doctorName} <span className="font-normal text-slate-500">({note.doctorSpecialty})</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-[10px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-700">
                              {note.diagnosisCode}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono">{note.date}</span>
                          </div>
                        </div>
                        <div>
                          <strong className="text-slate-700">Chief Complaint:</strong> {note.chiefComplaint}
                        </div>
                        <div>
                          <strong className="text-slate-700">Assessment:</strong> {note.assessment}
                        </div>
                        <div>
                          <strong className="text-slate-700">Plan:</strong> {note.treatmentPlan}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 5: INSURANCE & BILLING */}
              {activeDetailTab === 'insurance' && (
                <div className="space-y-4">
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <ShieldCheck className="w-5 h-5 text-blue-600" />
                        <h4 className="text-sm font-bold text-slate-800">
                          {activePatient.insurance.provider}
                        </h4>
                      </div>
                      <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                        {activePatient.insurance.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs pt-2 border-t border-slate-200">
                      <div>
                        <span className="text-[10px] text-slate-400 font-semibold block">Policy Number</span>
                        <span className="font-mono font-bold text-slate-800">{activePatient.insurance.policyNumber}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-semibold block">Group Number</span>
                        <span className="font-mono font-bold text-slate-800">{activePatient.insurance.groupNumber}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-semibold block">Coverage Ratio</span>
                        <span className="font-bold text-emerald-600">{activePatient.insurance.coveragePercentage}% Covered</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-semibold block">Standard Copay</span>
                        <span className="font-mono font-bold text-slate-800">${activePatient.insurance.copayAmount}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-semibold block">Policy Expiration</span>
                        <span className="text-slate-700 font-mono">{activePatient.insurance.expiryDate}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
