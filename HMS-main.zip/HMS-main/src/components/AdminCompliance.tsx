import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  FileText,
  UserCheck,
  Search,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  KeyRound,
  Download,
  Database,
  Globe,
  Radio,
  Sliders,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { UserRole, RoleDefinition } from '../types';

const roleDefinitions: Record<UserRole, RoleDefinition> = {
  admin: {
    role: 'admin',
    label: 'Hospital Administrator',
    description: 'Full supervisory authority across clinical, financial, and compliance modules.',
    permissions: {
      canRegisterPatients: true,
      canEditEMR: true,
      canPrescribeMeds: true,
      canDispenseMeds: true,
      canRunLabTests: true,
      canReviewRadiology: true,
      canManageBilling: true,
      canAccessAuditLogs: true,
    },
  },
  doctor: {
    role: 'doctor',
    label: 'Attending Physician',
    description: 'Diagnose patients, write clinical notes, prescribe meds, review diagnostics.',
    permissions: {
      canRegisterPatients: true,
      canEditEMR: true,
      canPrescribeMeds: true,
      canDispenseMeds: false,
      canRunLabTests: true,
      canReviewRadiology: true,
      canManageBilling: false,
      canAccessAuditLogs: false,
    },
  },
  nurse: {
    role: 'nurse',
    label: 'Registered Nurse',
    description: 'Record vitals, administer medications, manage ward bed allocations.',
    permissions: {
      canRegisterPatients: true,
      canEditEMR: true,
      canPrescribeMeds: false,
      canDispenseMeds: true,
      canRunLabTests: true,
      canReviewRadiology: true,
      canManageBilling: false,
      canAccessAuditLogs: false,
    },
  },
  pharmacist: {
    role: 'pharmacist',
    label: 'Clinical Pharmacist',
    description: 'Formulary inventory management, dispense meds, safety screening.',
    permissions: {
      canRegisterPatients: false,
      canEditEMR: false,
      canPrescribeMeds: false,
      canDispenseMeds: true,
      canRunLabTests: false,
      canReviewRadiology: false,
      canManageBilling: true,
      canAccessAuditLogs: false,
    },
  },
  receptionist: {
    role: 'receptionist',
    label: 'Patient Registrar',
    description: 'Patient check-in, schedule appointments, queue triage, invoicing.',
    permissions: {
      canRegisterPatients: true,
      canEditEMR: false,
      canPrescribeMeds: false,
      canDispenseMeds: false,
      canRunLabTests: false,
      canReviewRadiology: false,
      canManageBilling: true,
      canAccessAuditLogs: false,
    },
  },
  lab: {
    role: 'lab',
    label: 'Lab Technologist',
    description: 'Pathology specimen processing, biochemistry assays, critical flag verification.',
    permissions: {
      canRegisterPatients: false,
      canEditEMR: false,
      canPrescribeMeds: false,
      canDispenseMeds: false,
      canRunLabTests: true,
      canReviewRadiology: false,
      canManageBilling: false,
      canAccessAuditLogs: false,
    },
  },
  radiology: {
    role: 'radiology',
    label: 'Diagnostic Radiologist',
    description: 'DICOM imaging reviews, PACS modality triage, radiologic diagnostic reports.',
    permissions: {
      canRegisterPatients: false,
      canEditEMR: true,
      canPrescribeMeds: false,
      canDispenseMeds: false,
      canRunLabTests: false,
      canReviewRadiology: true,
      canManageBilling: false,
      canAccessAuditLogs: false,
    },
  },
};

const roleDefinitionList: RoleDefinition[] = Object.values(roleDefinitions);

export const AdminCompliance: React.FC = () => {
  const {
    compliance,
    updateCompliance,
    auditLogs,
    currentRole,
    setCurrentRole,
    staff,
    logAuditEvent,
  } = useHospital();

  const [searchAudit, setSearchAudit] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [showRoleModal, setShowRoleModal] = useState(false);

  const filteredLogs = auditLogs.filter((log) => {
    const matchesSearch =
      log.action.toLowerCase().includes(searchAudit.toLowerCase()) ||
      log.userName.toLowerCase().includes(searchAudit.toLowerCase()) ||
      log.details.toLowerCase().includes(searchAudit.toLowerCase()) ||
      (log.complianceFlag && log.complianceFlag.toLowerCase().includes(searchAudit.toLowerCase()));
    const matchesRole = roleFilter === 'all' || log.userRole === roleFilter;
    return matchesSearch && matchesRole;
  });

  const toggleCompliance = (key: keyof typeof compliance) => {
    const newVal = !compliance[key];
    updateCompliance({ [key]: newVal });
    logAuditEvent(
      'UPDATE',
      'Security Settings',
      'SYS-CONF',
      `Toggled ${String(key)} to ${newVal ? 'ENABLED' : 'DISABLED'}`,
      'HIPAA Access Log'
    );
  };

  const handleExportAuditCSV = () => {
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      'Timestamp,User,Role,Action,Details,IP,ComplianceFlag\n' +
      auditLogs
        .map(
          (l) =>
            `"${l.timestamp}","${l.userName}","${l.userRole}","${l.action}","${l.details}","${l.ipAddress}","${l.complianceFlag || ''}"`
        )
        .join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `apexhealth_hipaa_audit_trail_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-blue-600" />
            <h1 className="text-base lg:text-lg font-bold text-slate-800 tracking-tight">
              Hospital Admin, RBAC Permissions & HIPAA Audit Trails
            </h1>
            <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-100 text-emerald-800 rounded">
              ENCRYPTED COMPLIANCE
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            System access privileges, automated cryptographic access logs, FHIR standard mappings, and compliance toggles.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Fast Role Switcher for preview & testing */}
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded border border-slate-200">
            <span className="text-[11px] font-bold text-slate-600 pl-1.5 flex items-center gap-1">
              <KeyRound className="w-3 h-3 text-blue-600" />
              Active Role:
            </span>
            <select
              value={currentRole}
              onChange={(e) => setCurrentRole(e.target.value as UserRole)}
              className="text-xs font-bold capitalize bg-white text-slate-800 py-1 px-2 border border-slate-200 rounded focus:outline-none"
            >
              <option value="admin">Hospital Administrator</option>
              <option value="receptionist">Intake Receptionist</option>
              <option value="doctor">Attending Doctor</option>
              <option value="nurse">Floor Nurse (Triage & Wards)</option>
              <option value="lab">Lab Technologist</option>
              <option value="radiology">Diagnostic Radiologist (PACS)</option>
              <option value="pharmacist">Lead Pharmacist</option>
            </select>
          </div>

          <button
            onClick={handleExportAuditCSV}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded text-xs font-semibold flex items-center gap-1.5 shadow-sm transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Audit Trail</span>
          </button>
        </div>
      </div>

      {/* Compliance & Standards Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Card 1: Regulatory Standard Toggles */}
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <h3 className="font-bold text-xs uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-blue-600" />
              Data Privacy & Healthcare Mandates
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-800">HIPAA Security Rule (US)</div>
                <div className="text-[11px] text-slate-500">ePHI access auditing & 256-bit encryption</div>
              </div>
              <button
                onClick={() => toggleCompliance('hipaaAuditLogEnabled')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  compliance.hipaaAuditLogEnabled
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-slate-100 text-slate-500 border border-slate-300'
                }`}
              >
                {compliance.hipaaAuditLogEnabled ? 'ACTIVE' : 'DISABLED'}
              </button>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-800">GDPR Healthcare Privacy (EU)</div>
                <div className="text-[11px] text-slate-500">Explicit consent & right to forget</div>
              </div>
              <button
                onClick={() => toggleCompliance('gdprConsentTracking')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  compliance.gdprConsentTracking
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-slate-100 text-slate-500 border border-slate-300'
                }`}
              >
                {compliance.gdprConsentTracking ? 'ACTIVE' : 'DISABLED'}
              </button>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-800">AES-256 Storage Encryption</div>
                <div className="text-[11px] text-slate-500">Hardware security module at-rest encryption</div>
              </div>
              <button
                onClick={() => toggleCompliance('aes256EncryptionAtRest')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  compliance.aes256EncryptionAtRest
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-slate-100 text-slate-500 border border-slate-300'
                }`}
              >
                {compliance.aes256EncryptionAtRest ? 'ACTIVE' : 'DISABLED'}
              </button>
            </div>
          </div>
        </div>

        {/* Card 2: Interoperability & Sync */}
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <h3 className="font-bold text-xs uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-blue-600" />
              Interoperability & Network Sync
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-800">HL7 / FHIR R4 Gateways</div>
                <div className="text-[11px] text-slate-500">Fast Healthcare Interoperability endpoint</div>
              </div>
              <button
                onClick={() => toggleCompliance('hl7FhirInteropEnabled')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  compliance.hl7FhirInteropEnabled
                    ? 'bg-purple-100 text-purple-800 border border-purple-300'
                    : 'bg-slate-100 text-slate-500 border border-slate-300'
                }`}
              >
                {compliance.hl7FhirInteropEnabled ? 'CONNECTED' : 'STANDALONE'}
              </button>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-800">Offline Clinic First Cache</div>
                <div className="text-[11px] text-slate-500">Local indexedDB cache with conflict resolver</div>
              </div>
              <button
                onClick={() => toggleCompliance('offlineSyncCache')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  compliance.offlineSyncCache
                    ? 'bg-blue-100 text-blue-800 border border-blue-300'
                    : 'bg-slate-100 text-slate-500 border border-slate-300'
                }`}
              >
                {compliance.offlineSyncCache ? 'SYNCING' : 'PAUSED'}
              </button>
            </div>

            <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
              <span>Cluster Node:</span>
              <span className="font-mono text-slate-700 font-bold">us-central1-med-node-09</span>
            </div>
          </div>
        </div>

        {/* Card 3: RBAC Matrix Overview */}
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <h3 className="font-bold text-xs uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
              <UserCheck className="w-3.5 h-3.5 text-blue-600" />
              Role Permission Matrix
            </h3>
            <span className="text-[10px] font-mono text-purple-600 font-bold">7 ACTIVE ROLES</span>
          </div>

          <div className="space-y-1.5 text-xs max-h-52 overflow-y-auto pr-1">
            {roleDefinitionList.map((def) => {
              const isCurrent = currentRole === def.role;
              return (
                <div
                  key={def.role}
                  onClick={() => setCurrentRole(def.role)}
                  className={`flex items-center justify-between p-1.5 rounded cursor-pointer transition ${
                    isCurrent
                      ? 'bg-purple-50 border border-purple-300 font-bold'
                      : 'bg-slate-50 hover:bg-slate-100 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-1.5 min-w-0">
                    <span className="font-bold text-slate-800 text-[11px] truncate">
                      {def.label}
                    </span>
                    {isCurrent && (
                      <span className="text-[9px] bg-purple-600 text-white px-1 rounded">Active</span>
                    )}
                  </div>
                  <span className="text-[9px] font-mono text-slate-500 truncate max-w-[150px] text-right">
                    {def.description.split('.')[0]}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Role-Based Access Control (RBAC) Granular Permissions Matrix */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-3 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-purple-600" />
            <h3 className="font-bold text-xs text-slate-800 uppercase tracking-wider">
              RBAC Granular Capabilities & Enforcement Directory
            </h3>
          </div>
          <span className="text-[10px] text-slate-500 font-medium">
            Strict Zero-Trust Privilege Boundaries
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100/70 text-slate-600 font-semibold border-b border-slate-200 text-[10px] uppercase tracking-wider">
              <tr>
                <th className="py-2.5 px-3">Role Tier</th>
                <th className="py-2.5 px-2 text-center">Patient Reg</th>
                <th className="py-2.5 px-2 text-center">EMR Records</th>
                <th className="py-2.5 px-2 text-center">Prescribe</th>
                <th className="py-2.5 px-2 text-center">Dispense</th>
                <th className="py-2.5 px-2 text-center">Lab Tests</th>
                <th className="py-2.5 px-2 text-center">Radiology</th>
                <th className="py-2.5 px-2 text-center">Billing</th>
                <th className="py-2.5 px-2 text-center">Audit Logs</th>
                <th className="py-2.5 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {roleDefinitionList.map((r) => {
                const isSelected = currentRole === r.role;
                return (
                  <tr
                    key={r.role}
                    className={`transition hover:bg-slate-50 ${
                      isSelected ? 'bg-purple-50/40 font-medium' : ''
                    }`}
                  >
                    <td className="py-2.5 px-3">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-slate-800">{r.label}</span>
                        {isSelected && (
                          <span className="text-[9px] font-bold text-purple-700 bg-purple-100 px-1 py-0.2 rounded">
                            Active
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-400 block">{r.description}</span>
                    </td>

                    <td className="py-2.5 px-2 text-center">
                      {r.permissions.canRegisterPatients ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto" />
                      ) : (
                        <span className="text-slate-300 font-mono">—</span>
                      )}
                    </td>

                    <td className="py-2.5 px-2 text-center">
                      {r.permissions.canEditEMR ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto" />
                      ) : (
                        <span className="text-slate-300 font-mono">—</span>
                      )}
                    </td>

                    <td className="py-2.5 px-2 text-center">
                      {r.permissions.canPrescribeMeds ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto" />
                      ) : (
                        <span className="text-slate-300 font-mono">—</span>
                      )}
                    </td>

                    <td className="py-2.5 px-2 text-center">
                      {r.permissions.canDispenseMeds ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto" />
                      ) : (
                        <span className="text-slate-300 font-mono">—</span>
                      )}
                    </td>

                    <td className="py-2.5 px-2 text-center">
                      {r.permissions.canRunLabTests ? (
                        <CheckCircle2 className="w-4 h-4 text-cyan-600 mx-auto" />
                      ) : (
                        <span className="text-slate-300 font-mono">—</span>
                      )}
                    </td>

                    <td className="py-2.5 px-2 text-center">
                      {r.permissions.canReviewRadiology ? (
                        <CheckCircle2 className="w-4 h-4 text-purple-600 mx-auto" />
                      ) : (
                        <span className="text-slate-300 font-mono">—</span>
                      )}
                    </td>

                    <td className="py-2.5 px-2 text-center">
                      {r.permissions.canManageBilling ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto" />
                      ) : (
                        <span className="text-slate-300 font-mono">—</span>
                      )}
                    </td>

                    <td className="py-2.5 px-2 text-center">
                      {r.permissions.canAccessAuditLogs ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto" />
                      ) : (
                        <span className="text-slate-300 font-mono">—</span>
                      )}
                    </td>

                    <td className="py-2.5 px-3 text-right">
                      <button
                        onClick={() => setCurrentRole(r.role)}
                        className={`text-[11px] px-2.5 py-1 rounded font-semibold transition ${
                          isSelected
                            ? 'bg-purple-600 text-white shadow-xs'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                        }`}
                      >
                        {isSelected ? 'Active Profile' : 'Switch To'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* HIPAA / GDPR Audit Trail Log Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-3 border-b border-slate-200 bg-slate-50/70 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 flex-1 min-w-[240px]">
            <div className="relative flex-1">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search audit trail by user, action, record, or security flag..."
                value={searchAudit}
                onChange={(e) => setSearchAudit(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded text-xs focus:outline-none focus:border-blue-500"
              />
            </div>

            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="p-1.5 border border-slate-200 rounded text-slate-700 bg-white text-xs"
            >
              <option value="all">All Roles</option>
              <option value="admin">Admin</option>
              <option value="doctor">Doctor</option>
              <option value="nurse">Nurse</option>
              <option value="pharmacist">Pharmacist</option>
              <option value="receptionist">Receptionist</option>
            </select>
          </div>

          <span className="text-[11px] text-slate-500 font-mono">
            {filteredLogs.length} immutable security entries recorded
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-[10px] uppercase font-bold text-slate-500">
              <tr>
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3">Staff Identity & Role</th>
                <th className="py-2.5 px-3">Action Executed</th>
                <th className="py-2.5 px-3">Audit Details</th>
                <th className="py-2.5 px-3">Client IP</th>
                <th className="py-2.5 px-3 text-right">Compliance Tag</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    No audit records match the search filter.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 whitespace-nowrap font-mono text-[11px] text-slate-500">
                      {log.timestamp}
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <div className="font-semibold text-slate-800">{log.userName}</div>
                      <span className="text-[10px] uppercase font-bold text-blue-600 bg-blue-50 px-1 rounded">
                        {log.userRole}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-medium text-slate-700">
                      {log.action}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600 max-w-md truncate">
                      {log.details}
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap font-mono text-slate-500 text-[11px]">
                      {log.ipAddress}
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap text-right">
                      {log.complianceFlag && (
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                          {log.complianceFlag}
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
