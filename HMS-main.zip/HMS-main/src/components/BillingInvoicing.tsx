import React, { useState } from 'react';
import {
  CreditCard,
  ReceiptText,
  Plus,
  Search,
  CheckCircle2,
  AlertTriangle,
  DollarSign,
  ShieldCheck,
  FileCheck2,
  Download,
  Printer,
  ChevronRight,
  Send,
  Lock,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { Invoice, PaymentMethod, PaymentStatus } from '../types';

interface BillingInvoicingProps {
  onOpenNewInvoice: () => void;
  onSelectPatient: (id: string) => void;
}

export const BillingInvoicing: React.FC<BillingInvoicingProps> = ({
  onOpenNewInvoice,
  onSelectPatient,
}) => {
  const { invoices, processPayment, patients } = useHospital();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(invoices[0] || null);

  // Payment processing modal state
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Credit/Debit Card');
  const [cardLast4, setCardLast4] = useState('4242');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSuccessMsg, setPaymentSuccessMsg] = useState<string | null>(null);

  const filteredInvoices = invoices.filter((inv) => {
    const matchesSearch =
      inv.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inv.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inv.patientId.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || inv.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const activeInvoice = selectedInvoice || filteredInvoices[0] || null;

  const handleOpenPayment = (inv: Invoice) => {
    setSelectedInvoice(inv);
    setPaymentAmount(inv.balanceDue);
    setPaymentSuccessMsg(null);
    setShowPaymentModal(true);
  };

  const handlePaySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeInvoice) return;
    setIsProcessing(true);

    try {
      const result = await processPayment(activeInvoice.id, {
        amount: paymentAmount,
        method: paymentMethod,
        cardLast4: paymentMethod === 'Credit/Debit Card' ? cardLast4 : undefined,
      });

      if (result.success) {
        setPaymentSuccessMsg(`Payment of $${paymentAmount.toFixed(2)} captured (Auth: ${result.transaction.authCode})`);
        setTimeout(() => {
          setShowPaymentModal(false);
          setIsProcessing(false);
          setPaymentSuccessMsg(null);
        }, 1200);
      }
    } catch {
      setIsProcessing(false);
    }
  };

  const totalBilled = invoices.reduce((sum, inv) => sum + inv.subtotal, 0);
  const totalCoveredByInsurance = invoices.reduce((sum, inv) => sum + inv.insuranceCoveredAmount, 0);
  const totalCollected = invoices.reduce((sum, inv) => sum + inv.amountPaid, 0);
  const totalOutstanding = invoices.reduce((sum, inv) => sum + inv.balanceDue, 0);

  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-blue-600" />
            <h1 className="text-base lg:text-lg font-bold text-slate-800 tracking-tight">
              Hospital Billing, Invoicing & Insurance Claims
            </h1>
            <span className="px-2 py-0.5 text-[10px] font-bold bg-purple-100 text-purple-800 rounded">
              PCI-DSS SECURE
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Itemized clinical encounters, real-time insurance co-pays, and encrypted point-of-sale gateway settlement.
          </p>
        </div>

        <button
          onClick={onOpenNewInvoice}
          className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-semibold flex items-center gap-1.5 shadow-sm transition"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Create New Invoice</span>
        </button>
      </div>

      {/* Financial Metrics Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Gross Billed Value</span>
          <div className="text-xl font-bold text-slate-800 font-mono mt-1">
            ${totalBilled.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <span className="text-[11px] text-slate-500">Total itemized services</span>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Insurance Claims Paid</span>
          <div className="text-xl font-bold text-blue-600 font-mono mt-1">
            ${totalCoveredByInsurance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <span className="text-[11px] text-slate-500">Direct insurer reimbursements</span>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Patient Copays Collected</span>
          <div className="text-xl font-bold text-emerald-600 font-mono mt-1">
            ${totalCollected.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <span className="text-[11px] text-slate-500">Settled via card, HSA, or ACH</span>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Outstanding Balance Due</span>
          <div className="text-xl font-bold text-rose-600 font-mono mt-1">
            ${totalOutstanding.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <span className="text-[11px] text-slate-500">Pending patient settlement</span>
        </div>
      </div>

      {/* Main 2-Col Layout: Invoices List on Left, Itemized Invoice on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Col: Invoice List (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[700px]">
          <div className="p-3 border-b border-slate-200 bg-slate-50 space-y-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search invoice # or patient name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded text-xs focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="flex items-center gap-1 overflow-x-auto text-[11px]">
              {['all', 'Pending', 'Partially Paid', 'Paid', 'Insurance Processing'].map((status) => (
                <button
                  key={status}
                  onClick={() => setStatusFilter(status)}
                  className={`px-2 py-0.5 rounded font-medium whitespace-nowrap transition ${
                    statusFilter === status
                      ? 'bg-slate-800 text-white font-semibold'
                      : 'text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>
          </div>

          <div className="divide-y divide-slate-100 overflow-y-auto flex-1">
            {filteredInvoices.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">
                No invoices matching search criteria.
              </div>
            ) : (
              filteredInvoices.map((inv) => {
                const isSelected = activeInvoice?.id === inv.id;
                return (
                  <div
                    key={inv.id}
                    onClick={() => setSelectedInvoice(inv)}
                    className={`p-3 cursor-pointer transition ${
                      isSelected
                        ? 'bg-blue-50/70 border-l-3 border-blue-600'
                        : 'hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="text-xs font-mono font-bold text-slate-800">{inv.id}</span>
                        <h4 className="text-xs font-semibold text-slate-700 mt-0.5">{inv.patientName}</h4>
                      </div>
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                          inv.status === 'Paid'
                            ? 'bg-emerald-100 text-emerald-700'
                            : inv.status === 'Partially Paid'
                            ? 'bg-blue-100 text-blue-700'
                            : inv.status === 'Insurance Processing'
                            ? 'bg-purple-100 text-purple-700'
                            : 'bg-amber-100 text-amber-700'
                        }`}
                      >
                        {inv.status}
                      </span>
                    </div>

                    <div className="mt-2 flex items-center justify-between text-xs">
                      <span className="font-mono text-slate-500 text-[11px]">Due: {inv.dueDate}</span>
                      <span className="font-mono font-bold text-slate-800">
                        ${inv.balanceDue.toFixed(2)} due
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Col: Itemized Invoice Detail (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[700px]">
          {activeInvoice ? (
            <>
              {/* Invoice Header */}
              <div className="p-4 border-b border-slate-200 bg-slate-50/60 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-sm font-bold text-slate-800 font-mono">{activeInvoice.id}</h2>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        activeInvoice.status === 'Paid'
                          ? 'bg-emerald-100 text-emerald-800'
                          : activeInvoice.status === 'Partially Paid'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {activeInvoice.status}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Issued: {activeInvoice.issueDate} • Due: {activeInvoice.dueDate}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {activeInvoice.balanceDue > 0 && (
                    <button
                      onClick={() => handleOpenPayment(activeInvoice)}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-semibold flex items-center gap-1.5 shadow-sm transition"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>Process Payment</span>
                    </button>
                  )}
                  <button
                    onClick={() => window.print()}
                    className="p-1.5 border border-slate-300 hover:bg-slate-100 text-slate-600 rounded transition"
                    title="Print invoice"
                  >
                    <Printer className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Patient & Insurance Summary Header */}
              <div className="p-4 border-b border-slate-100 bg-white grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="text-slate-400 font-bold uppercase text-[10px] block mb-1">Billed To</span>
                  <div className="font-bold text-slate-800">{activeInvoice.patientName}</div>
                  <div className="text-slate-500 font-mono text-[11px]">{activeInvoice.patientId}</div>
                  <div className="text-slate-500 text-[11px]">{activeInvoice.patientPhone}</div>
                </div>
                <div>
                  <span className="text-slate-400 font-bold uppercase text-[10px] block mb-1">Insurance Claim Status</span>
                  <div className="font-medium text-slate-800">
                    {activeInvoice.insuranceClaimNumber || 'Direct Health Claim Submitted'}
                  </div>
                  <div className="text-slate-500 text-[11px]">
                    Insurance Covered: <span className="font-bold text-blue-600 font-mono">${activeInvoice.insuranceCoveredAmount.toFixed(2)}</span>
                  </div>
                  <div className="text-slate-500 text-[11px]">
                    Copay Applied: <span className="font-bold text-slate-800 font-mono">${(activeInvoice.copayAmount || 0).toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Line Items Table */}
              <div className="p-4 flex-1 overflow-y-auto space-y-4">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-[10px] uppercase font-bold text-slate-500">
                    <tr>
                      <th className="py-2 px-2.5">Line Item Description</th>
                      <th className="py-2 px-2.5">Category</th>
                      <th className="py-2 px-2.5 text-center">Qty</th>
                      <th className="py-2 px-2.5 text-right">Unit Price</th>
                      <th className="py-2 px-2.5 text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {activeInvoice.items.map((item) => (
                      <tr key={item.id}>
                        <td className="py-2 px-2.5 font-medium text-slate-800">{item.description}</td>
                        <td className="py-2 px-2.5 text-slate-500 text-[11px]">{item.category}</td>
                        <td className="py-2 px-2.5 text-center font-mono">{item.quantity}</td>
                        <td className="py-2 px-2.5 text-right font-mono text-slate-600">${item.unitCost.toFixed(2)}</td>
                        <td className="py-2 px-2.5 text-right font-mono font-bold text-slate-800">${item.amount.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* Subtotal Calculations */}
                <div className="pt-3 border-t border-slate-200 space-y-1 text-xs max-w-xs ml-auto">
                  <div className="flex justify-between text-slate-600">
                    <span>Subtotal:</span>
                    <span className="font-mono">${activeInvoice.subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-blue-600">
                    <span>Insurance Coverage:</span>
                    <span className="font-mono">-${activeInvoice.insuranceCoveredAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Patient Copay:</span>
                    <span className="font-mono">${(activeInvoice.copayAmount || 0).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-bold text-slate-800 pt-1 border-t border-slate-200">
                    <span>Total Patient Payable:</span>
                    <span className="font-mono">${activeInvoice.patientPayable.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-emerald-600 font-semibold">
                    <span>Amount Paid:</span>
                    <span className="font-mono">${activeInvoice.amountPaid.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-rose-600 font-bold text-sm pt-1 border-t border-slate-200">
                    <span>Balance Due:</span>
                    <span className="font-mono">${activeInvoice.balanceDue.toFixed(2)}</span>
                  </div>
                </div>

                {/* Prior Gateway Transactions Log */}
                {activeInvoice.transactions.length > 0 && (
                  <div className="pt-4 border-t border-slate-200">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-2">
                      Settlement Gateway Audit History
                    </span>
                    <div className="space-y-1.5">
                      {activeInvoice.transactions.map((tx, idx) => (
                        <div key={idx} className="p-2 bg-slate-50 rounded border border-slate-200 text-[11px] flex items-center justify-between">
                          <div>
                            <span className="font-mono font-bold text-slate-800">{tx.transactionId}</span>
                            <span className="text-slate-500 ml-2">via {tx.method}</span>
                            {tx.cardLast4 && <span className="text-slate-400 font-mono"> (•••• {tx.cardLast4})</span>}
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-emerald-600 font-bold">+${tx.amountPaid.toFixed(2)}</span>
                            <span className="text-[10px] font-mono bg-emerald-100 text-emerald-800 px-1 rounded">{tx.authCode}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="p-12 text-center text-slate-400 text-xs">
              Select an invoice from the directory to review line items.
            </div>
          )}
        </div>
      </div>

      {/* Payment Processing Modal */}
      {showPaymentModal && activeInvoice && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-md w-full p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-emerald-600" />
                <h3 className="font-bold text-sm text-slate-800">
                  Process Secure Payment — {activeInvoice.id}
                </h3>
              </div>
              <button onClick={() => setShowPaymentModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            {paymentSuccessMsg ? (
              <div className="p-6 text-center space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto animate-bounce" />
                <h4 className="font-bold text-sm text-slate-800">Transaction Approved</h4>
                <p className="text-xs text-slate-600">{paymentSuccessMsg}</p>
              </div>
            ) : (
              <form onSubmit={handlePaySubmit} className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Patient Name</label>
                  <input
                    type="text"
                    value={activeInvoice.patientName}
                    disabled
                    className="w-full p-2 bg-slate-100 border border-slate-200 rounded font-semibold text-slate-700"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 font-medium mb-1">Payment Amount ($)</label>
                    <input
                      type="number"
                      step="0.01"
                      max={activeInvoice.balanceDue}
                      value={paymentAmount}
                      onChange={(e) => setPaymentAmount(Number(e.target.value))}
                      className="w-full p-2 border border-slate-200 rounded font-mono font-bold text-slate-800 text-sm"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 font-medium mb-1">Payment Method</label>
                    <select
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                      className="w-full p-2 border border-slate-200 rounded text-slate-800"
                    >
                      <option value="Credit/Debit Card">Credit/Debit Card</option>
                      <option value="HSA/FSA">HSA / FSA Health Card</option>
                      <option value="Direct Insurance">Direct Insurance Pay</option>
                      <option value="ACH/Bank Transfer">ACH Bank Wire</option>
                      <option value="Cash">Cash at Desk</option>
                    </select>
                  </div>
                </div>

                {paymentMethod === 'Credit/Debit Card' && (
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded space-y-2">
                    <span className="text-[10px] font-bold uppercase text-slate-500 block">Encrypted Card Terminal</span>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Card Number (4242 •••• •••• 4242)"
                        defaultValue="•••• •••• •••• 4242"
                        className="flex-1 p-2 bg-white border border-slate-200 rounded font-mono text-xs"
                      />
                      <input
                        type="text"
                        placeholder="MM/YY"
                        defaultValue="12/28"
                        className="w-20 p-2 bg-white border border-slate-200 rounded font-mono text-xs text-center"
                      />
                      <input
                        type="text"
                        placeholder="CVC"
                        defaultValue="382"
                        className="w-16 p-2 bg-white border border-slate-200 rounded font-mono text-xs text-center"
                      />
                    </div>
                  </div>
                )}

                <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded text-[11px] text-emerald-800 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>256-bit TLS handshake with Point-of-Sale Tokenization gateway.</span>
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={() => setShowPaymentModal(false)}
                    className="px-3 py-1.5 border border-slate-300 rounded text-slate-600 hover:bg-slate-100"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isProcessing}
                    className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-semibold flex items-center gap-1"
                  >
                    {isProcessing ? 'Authorizing...' : `Charge $${paymentAmount.toFixed(2)}`}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
