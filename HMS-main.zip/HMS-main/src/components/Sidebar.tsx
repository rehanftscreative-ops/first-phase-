import React from 'react';
import {
  LayoutDashboard,
  Users,
  Calendar,
  CreditCard,
  BedDouble,
  Activity,
  ShieldCheck,
  Stethoscope,
  Pill,
  FlaskConical,
  Scan,
  BarChart3,
  CircleDot,
  KeyRound,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { NavigationTab } from '../context/HospitalContext';

export const Sidebar: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    patients,
    appointments,
    invoices,
    wardBeds,
    doctors,
    staff,
    pharmacy,
    currentRole,
  } = useHospital();

  const totalPatients = patients.length;
  const activeQueueCount = appointments.filter(
    (a) => a.status === 'Checked-In' || a.status === 'In Consultation' || a.status === 'Scheduled'
  ).length;
  const pendingBillsCount = invoices.filter((i) => i.status === 'Pending').length;
  const lowPharmacyCount = pharmacy.filter((p) => p.stockQuantity <= p.minThreshold).length;
  const occupiedBedsCount = wardBeds.filter((b) => b.status === 'Occupied').length;
  const totalBeds = wardBeds.length;
  const erCapacityPercent = Math.min(100, Math.round((occupiedBedsCount / totalBeds) * 100));

  const navItems = [
    {
      id: 'overview' as NavigationTab,
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: null,
      category: 'Clinical Core',
    },
    {
      id: 'patients' as NavigationTab,
      label: 'Patient EMR',
      icon: Users,
      badge: totalPatients,
      category: 'Clinical Core',
    },
    {
      id: 'appointments' as NavigationTab,
      label: 'Appointments',
      icon: Calendar,
      badge: activeQueueCount,
      category: 'Clinical Core',
    },
    {
      id: 'staff' as NavigationTab,
      label: 'Doctors & Staff',
      icon: Stethoscope,
      badge: staff.length,
      category: 'Operations',
    },
    {
      id: 'billing' as NavigationTab,
      label: 'Billing & Claims',
      icon: CreditCard,
      badge: pendingBillsCount > 0 ? pendingBillsCount : null,
      category: 'Operations',
    },
    {
      id: 'pharmacy' as NavigationTab,
      label: 'Pharmacy Stock',
      icon: Pill,
      badge: lowPharmacyCount > 0 ? `${lowPharmacyCount} low` : null,
      category: 'Clinical Core',
    },
    {
      id: 'labs' as NavigationTab,
      label: 'Lab Diagnostics',
      icon: FlaskConical,
      badge: null,
      category: 'Clinical Core',
    },
    {
      id: 'radiology' as NavigationTab,
      label: 'Radiology & PACS',
      icon: Scan,
      badge: null,
      category: 'Clinical Core',
    },
    {
      id: 'wards' as NavigationTab,
      label: 'Ward & Beds',
      icon: BedDouble,
      badge: `${occupiedBedsCount}/${totalBeds}`,
      category: 'Operations',
    },
    {
      id: 'reports' as NavigationTab,
      label: 'Analytics & Reports',
      icon: BarChart3,
      badge: null,
      category: 'Governance',
    },
    {
      id: 'admin' as NavigationTab,
      label: 'Admin & HIPAA',
      icon: ShieldCheck,
      badge: 'SECURE',
      category: 'Governance',
    },
  ];

  return (
    <aside className="w-56 bg-slate-900 border-r border-slate-800 flex flex-col p-3 shrink-0 select-none overflow-y-auto">
      {/* Current Active Role Indicator */}
      <div className="mb-3 px-2 py-1.5 bg-slate-800/80 rounded border border-slate-700/60 flex items-center justify-between">
        <div className="flex items-center gap-1.5 min-w-0">
          <KeyRound className="w-3.5 h-3.5 text-blue-400 shrink-0" />
          <div className="min-w-0">
            <span className="text-[9px] uppercase tracking-wider text-slate-400 block font-semibold leading-none">
              Active Role
            </span>
            <span className="text-xs font-bold text-white capitalize truncate block leading-tight">
              {currentRole}
            </span>
          </div>
        </div>
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
      </div>

      {/* Navigation Links */}
      <div className="space-y-0.5">
        <div className="text-[10px] uppercase font-bold text-slate-500 mb-1 px-2 tracking-widest">
          Hospital Modules
        </div>
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          const Icon = item.icon;
          return (
            <div
              key={item.id}
              id={`nav-${item.id}-link`}
              onClick={() => setActiveTab(item.id)}
              className={`px-2.5 py-1.5 rounded text-xs font-medium transition-colors cursor-pointer flex justify-between items-center ${
                isActive
                  ? 'bg-blue-600 text-white font-semibold shadow-sm'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-2 min-w-0">
                <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span className="truncate">{item.label}</span>
              </div>
              {item.badge !== null && (
                <span
                  className={`text-[9px] px-1.5 py-0.2 rounded font-mono shrink-0 ml-1 ${
                    isActive
                      ? 'bg-blue-800 text-blue-100 font-bold'
                      : typeof item.badge === 'string' && item.badge.includes('low')
                      ? 'bg-amber-900/80 text-amber-200 font-bold'
                      : item.badge === 'SECURE'
                      ? 'bg-emerald-950 text-emerald-300 font-bold'
                      : 'bg-slate-800 text-slate-300 font-medium'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </div>
          );
        })}
      </div>

      {/* On-Duty Physicians Quick Roster */}
      <div className="mt-4 pt-3 border-t border-slate-800">
        <div className="text-[10px] uppercase font-bold text-slate-500 mb-1.5 px-2 tracking-widest flex items-center justify-between">
          <span>Duty Clinicians</span>
          <span className="text-emerald-400 font-mono text-[9px]">LIVE</span>
        </div>
        <div className="space-y-1">
          {doctors.slice(0, 3).map((doc) => (
            <div
              key={doc.id}
              className="p-1 rounded bg-slate-800/40 border border-slate-800 text-xs flex items-center justify-between"
            >
              <div className="min-w-0 pr-1">
                <p className="text-slate-200 font-medium truncate text-[10px]">
                  {doc.name.replace(', MD', '').replace(', FACS', '')}
                </p>
                <p className="text-slate-400 text-[9px] truncate">{doc.specialty}</p>
              </div>
              <span
                className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                  doc.status === 'Available'
                    ? 'bg-emerald-400'
                    : doc.status === 'In Surgery'
                    ? 'bg-rose-400'
                    : 'bg-amber-400'
                }`}
                title={doc.status}
              />
            </div>
          ))}
        </div>
      </div>

      {/* Emergency Capacity Status */}
      <div className="mt-auto pt-3 border-t border-slate-800">
        <div className="px-2.5 py-1.5 bg-red-950/40 border border-red-900/60 rounded">
          <div className="flex justify-between items-center mb-1">
            <span className="text-red-400 text-[9px] font-bold tracking-wider uppercase">ER Inpatient Load</span>
            <span className="text-red-400 text-[10px] font-bold font-mono">{erCapacityPercent}%</span>
          </div>
          <div className="w-full bg-red-950 rounded-full h-1 overflow-hidden">
            <div
              className="bg-red-500 h-1 rounded-full transition-all duration-500"
              style={{ width: `${erCapacityPercent}%` }}
            />
          </div>
        </div>

        <div className="mt-2 px-1 text-[9px] text-slate-500 flex items-center justify-between">
          <span className="flex items-center gap-1 text-slate-400">
            <ShieldCheck className="w-3 h-3 text-emerald-500" />
            HIPAA Validated
          </span>
          <span className="font-mono text-slate-500">v4.3.0</span>
        </div>
      </div>
    </aside>
  );
};
