import React, { useState } from 'react';
import {
  Video,
  Calendar,
  Clock,
  Search,
  Filter,
  UserCheck,
  PhoneCall,
  Plus,
  ShieldCheck,
  Wifi,
  ExternalLink,
  Copy,
  Check,
  AlertTriangle,
  FileText,
  User,
  Sparkles,
  CheckCircle2,
  Stethoscope,
  Activity,
  Send,
} from 'lucide-react';
import { Appointment } from '../types';
import { useHospital } from '../context/HospitalContext';
import { TelehealthVideoModal } from './TelehealthVideoModal';

interface TelehealthViewProps {
  onOpenNewAppointment: () => void;
  onSelectPatient: (id: string) => void;
}

export const TelehealthView: React.FC<TelehealthViewProps> = ({
  onOpenNewAppointment,
  onSelectPatient,
}) => {
  const {
    appointments,
    doctors,
    updateAppointmentStatus,
    addNotification,
  } = useHospital();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>('all');
  const [activeVideoApt, setActiveVideoApt] = useState<Appointment | null>(null);
  const [copiedAptId, setCopiedAptId] = useState<string | null>(null);

  // Filter for telehealth appointments: either explicitly marked isTelehealth or type has Telehealth / Remote
  const telehealthAppointments = appointments.filter(
    (apt) =>
      apt.isTelehealth ||
      apt.type.toLowerCase().includes('telehealth') ||
      apt.type.toLowerCase().includes('remote') ||
      apt.roomNumber.toLowerCase().includes('virtual')
  );

  // Apply filters
  const filteredTelehealth = telehealthAppointments.filter((apt) => {
    const matchesSearch =
      apt.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      apt.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      apt.doctorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      apt.reason.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (apt.telehealthDetails?.roomId || '').toLowerCase().includes(searchQuery.toLowerCase());

    const matchesDoctor = selectedDoctorId === 'all' || apt.doctorId === selectedDoctorId;

    let matchesStatus = true;
    if (statusFilter === 'waiting') {
      matchesStatus =
        apt.status === 'Checked-In' ||
        apt.telehealthDetails?.patientStatus === 'Waiting in Room';
    } else if (statusFilter === 'scheduled') {
      matchesStatus = apt.status === 'Scheduled';
    } else if (statusFilter === 'in_consultation') {
      matchesStatus = apt.status === 'In Consultation';
    } else if (statusFilter === 'completed') {
      matchesStatus = apt.status === 'Completed';
    }

    return matchesSearch && matchesDoctor && matchesStatus;
  });

  // Calculate quick metrics
  const inWaitingRoom = telehealthAppointments.filter(
    (a) =>
      a.status === 'Checked-In' ||
      a.telehealthDetails?.patientStatus === 'Waiting in Room'
  );
  const inLiveCall = telehealthAppointments.filter((a) => a.status === 'In Consultation');
  const scheduledToday = telehealthAppointments.filter((a) => a.status === 'Scheduled');
  const completedToday = telehealthAppointments.filter((a) => a.status === 'Completed');

  const handleCopyLink = (apt: Appointment) => {
    const link =
      apt.telehealthDetails?.meetingLink ||
      `https://telehealth.medcore.health/room/${apt.telehealthDetails?.roomId || apt.id}`;
    navigator.clipboard.writeText(link);
    setCopiedAptId(apt.id);
    setTimeout(() => setCopiedAptId(null), 2500);
    addNotification('Link Copied', `Direct video link copied for ${apt.patientName}.`, 'info');
  };

  const handleSendReminder = (apt: Appointment) => {
    addNotification(
      'SMS Reminder Sent',
      `Secure video invite re-sent via SMS and Patient Portal to ${apt.patientName}.`,
      'success',
      apt.patientId
    );
  };

  return (
    <div id="telehealth-dashboard" className="space-y-4">
      {/* Top Telehealth Alert Banner: Patient Waiting in Virtual Lobby */}
      {inWaitingRoom.length > 0 && (
        <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 border border-emerald-500/50 p-4 rounded-xl shadow-md text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/20 text-emerald-400 rounded-lg border border-emerald-500/40 relative">
              <Video className="w-5 h-5 animate-pulse" />
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-sm text-emerald-300">
                  {inWaitingRoom.length} Patient{inWaitingRoom.length > 1 ? 's' : ''} in Virtual Waiting Room Ready
                </h2>
                <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-500/30 text-emerald-200 rounded-full uppercase tracking-wider">
                  Hardware Verified
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                <strong className="text-white">{inWaitingRoom[0].patientName}</strong> has completed check-in and is waiting with camera & microphone online for{' '}
                <span className="text-emerald-300">{inWaitingRoom[0].doctorName}</span>.
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveVideoApt(inWaitingRoom[0])}
            className="w-full sm:w-auto px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-lg shadow-lg flex items-center justify-center gap-2 transition transform active:scale-95 whitespace-nowrap"
          >
            <Video className="w-4 h-4" />
            <span>Initiate Video Session Now</span>
          </button>
        </div>
      )}

      {/* Telehealth Velocity & System Status KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-3.5 bg-white rounded-lg border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[10px] font-bold uppercase tracking-wider">Virtual Lobby</span>
            <span className="p-1 bg-emerald-50 text-emerald-600 rounded">
              <UserCheck className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="text-2xl font-bold text-slate-900 font-mono mt-1">
            {inWaitingRoom.length}{' '}
            <span className="text-xs font-normal text-emerald-600 font-sans">waiting</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Checked in & verified online</p>
        </div>

        <div className="p-3.5 bg-white rounded-lg border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[10px] font-bold uppercase tracking-wider">Live Video Calls</span>
            <span className="p-1 bg-blue-50 text-blue-600 rounded">
              <Video className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="text-2xl font-bold text-blue-600 font-mono mt-1">
            {inLiveCall.length}{' '}
            <span className="text-xs font-normal text-blue-600 font-sans">in consult</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Physicians in active sessions</p>
        </div>

        <div className="p-3.5 bg-white rounded-lg border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[10px] font-bold uppercase tracking-wider">Scheduled Today</span>
            <span className="p-1 bg-amber-50 text-amber-600 rounded">
              <Clock className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="text-2xl font-bold text-slate-800 font-mono mt-1">
            {scheduledToday.length}{' '}
            <span className="text-xs font-normal text-slate-500 font-sans">upcoming</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Automated SMS invites dispatched</p>
        </div>

        <div className="p-3.5 bg-white rounded-lg border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[10px] font-bold uppercase tracking-wider">WebRTC Infrastructure</span>
            <span className="p-1 bg-purple-50 text-purple-600 rounded">
              <ShieldCheck className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="text-xs font-bold text-emerald-700 flex items-center gap-1.5 mt-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>AES-256 E2EE Tunnel Active</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Average Latency: 22ms • 0% Loss</p>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
          {/* Search */}
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by patient, room ID, reason, or physician..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 border border-slate-200 rounded text-xs focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Status Tabs */}
          <div className="flex items-center bg-slate-100 p-0.5 rounded border border-slate-200 text-[11px]">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-2.5 py-1 rounded font-medium transition ${
                statusFilter === 'all'
                  ? 'bg-white text-slate-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All ({telehealthAppointments.length})
            </button>
            <button
              onClick={() => setStatusFilter('waiting')}
              className={`px-2.5 py-1 rounded font-medium transition flex items-center gap-1 ${
                statusFilter === 'waiting'
                  ? 'bg-white text-emerald-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>Waiting Lobby</span>
              {inWaitingRoom.length > 0 && (
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              )}
            </button>
            <button
              onClick={() => setStatusFilter('scheduled')}
              className={`px-2.5 py-1 rounded font-medium transition ${
                statusFilter === 'scheduled'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Upcoming ({scheduledToday.length})
            </button>
            <button
              onClick={() => setStatusFilter('completed')}
              className={`px-2.5 py-1 rounded font-medium transition ${
                statusFilter === 'completed'
                  ? 'bg-white text-slate-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Completed ({completedToday.length})
            </button>
          </div>

          {/* Doctor Filter */}
          <select
            value={selectedDoctorId}
            onChange={(e) => setSelectedDoctorId(e.target.value)}
            className="p-1.5 border border-slate-200 rounded text-slate-700 bg-white text-xs"
          >
            <option value="all">All Attending Physicians</option>
            {doctors.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.specialty})
              </option>
            ))}
          </select>
        </div>

        <button
          onClick={onOpenNewAppointment}
          className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-semibold flex items-center gap-1.5 shadow-xs transition"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Book Telehealth Consult</span>
        </button>
      </div>

      {/* Telehealth Consultations List */}
      <div className="space-y-3">
        {filteredTelehealth.length === 0 ? (
          <div className="bg-white rounded-lg border border-slate-200 p-12 text-center text-slate-500">
            <Video className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-700">No Telehealth Consultations Found</p>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              No remote visits match the chosen filters. Click "Book Telehealth Consult" to schedule a remote session.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {filteredTelehealth.map((apt) => {
              const isPatientWaiting =
                apt.status === 'Checked-In' ||
                apt.telehealthDetails?.patientStatus === 'Waiting in Room';
              const isInSession = apt.status === 'In Consultation';
              const isCompleted = apt.status === 'Completed';

              return (
                <div
                  key={apt.id}
                  className={`bg-white rounded-xl border transition shadow-xs hover:shadow-md flex flex-col justify-between overflow-hidden ${
                    isPatientWaiting
                      ? 'border-emerald-400 ring-1 ring-emerald-300'
                      : isInSession
                      ? 'border-blue-400 ring-1 ring-blue-300'
                      : 'border-slate-200'
                  }`}
                >
                  {/* Card Header */}
                  <div className="p-4 border-b border-slate-100 bg-slate-50/60">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-700 text-white font-bold flex items-center justify-center text-sm shadow-xs shrink-0">
                          {apt.patientName
                            .split(' ')
                            .map((n) => n[0])
                            .join('')}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => onSelectPatient(apt.patientId)}
                              className="font-bold text-sm text-slate-900 hover:text-blue-600 text-left"
                            >
                              {apt.patientName}
                            </button>
                            <span className="text-[10px] font-mono text-slate-400">
                              {apt.patientId}
                            </span>
                          </div>
                          <div className="text-xs text-slate-500">
                            {apt.patientGender} • {apt.patientAge} years • Room: {apt.roomNumber}
                          </div>
                        </div>
                      </div>

                      {/* Connection Status Badge */}
                      <div>
                        {isPatientWaiting ? (
                          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1.5 shadow-xs">
                            <span className="w-2 h-2 rounded-full bg-emerald-600 animate-ping"></span>
                            <span>Waiting in Room</span>
                          </span>
                        ) : isInSession ? (
                          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-300 flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></span>
                            <span>In Call</span>
                          </span>
                        ) : isCompleted ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 text-slate-600">
                            Completed
                          </span>
                        ) : (
                          <span className="px-2.5 py-1 rounded-full text-[10px] font-medium bg-amber-50 text-amber-700 border border-amber-200">
                            Scheduled
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Date, Time & Priority Row */}
                    <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
                      <span className="px-2 py-0.5 bg-white border border-slate-200 rounded font-mono font-semibold text-slate-700 flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span>{apt.timeSlot}</span>
                      </span>

                      <span className="px-2 py-0.5 bg-white border border-slate-200 rounded text-slate-600">
                        {apt.date}
                      </span>

                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          apt.priority === 'Urgent'
                            ? 'bg-amber-100 text-amber-700'
                            : apt.priority === 'Emergency'
                            ? 'bg-red-100 text-red-700'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {apt.priority} Priority
                      </span>
                    </div>
                  </div>

                  {/* Card Body: Clinical Details */}
                  <div className="p-4 space-y-2.5 flex-1 text-xs">
                    <div>
                      <div className="text-[10px] uppercase font-bold text-slate-400">
                        Attending Physician
                      </div>
                      <div className="font-semibold text-slate-800 flex items-center gap-1.5 mt-0.5">
                        <Stethoscope className="w-3.5 h-3.5 text-blue-600" />
                        <span>{apt.doctorName}</span>
                        <span className="text-[11px] text-slate-500 font-normal">
                          ({apt.department})
                        </span>
                      </div>
                    </div>

                    <div>
                      <div className="text-[10px] uppercase font-bold text-slate-400">
                        Consultation Reason
                      </div>
                      <p className="text-slate-700 mt-0.5 leading-relaxed bg-slate-50 p-2 rounded border border-slate-100">
                        {apt.reason}
                      </p>
                    </div>

                    {/* Virtual Technical Readiness Indicator */}
                    <div className="p-2 bg-slate-50 rounded border border-slate-200 text-[11px] flex items-center justify-between">
                      <div className="flex items-center gap-2 text-slate-600">
                        <Wifi className="w-3.5 h-3.5 text-emerald-600" />
                        <span>
                          Room:{' '}
                          <strong className="font-mono text-slate-800">
                            {apt.telehealthDetails?.roomId || 'TH-MAIN'}
                          </strong>
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleCopyLink(apt)}
                          className="px-2 py-0.5 text-[10px] bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded flex items-center gap-1 transition"
                          title="Copy Direct Video Link"
                        >
                          {copiedAptId === apt.id ? (
                            <Check className="w-3 h-3 text-emerald-600" />
                          ) : (
                            <Copy className="w-3 h-3 text-slate-400" />
                          )}
                          <span>{copiedAptId === apt.id ? 'Copied' : 'Copy Link'}</span>
                        </button>

                        <button
                          onClick={() => handleSendReminder(apt)}
                          className="px-2 py-0.5 text-[10px] bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded flex items-center gap-1 transition"
                          title="Send SMS and Email reminder to patient"
                        >
                          <Send className="w-3 h-3 text-blue-500" />
                          <span>Send SMS</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Card Footer Actions */}
                  <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-2">
                    <button
                      onClick={() => onSelectPatient(apt.patientId)}
                      className="px-2.5 py-1.5 text-xs text-slate-600 hover:text-blue-600 font-semibold flex items-center gap-1"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>View Chart</span>
                    </button>

                    <div className="flex items-center gap-2">
                      {isCompleted ? (
                        <button
                          onClick={() => setActiveVideoApt(apt)}
                          className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded text-xs font-semibold flex items-center gap-1.5 transition"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>Review Session</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => setActiveVideoApt(apt)}
                          className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 shadow-sm transition transform active:scale-95 ${
                            isPatientWaiting
                              ? 'bg-emerald-600 hover:bg-emerald-500 text-white ring-2 ring-emerald-300'
                              : 'bg-blue-600 hover:bg-blue-500 text-white'
                          }`}
                        >
                          <Video className="w-4 h-4" />
                          <span>Initiate Video Session</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Active Video Session Modal */}
      {activeVideoApt && (
        <TelehealthVideoModal
          appointment={activeVideoApt}
          isOpen={!!activeVideoApt}
          onClose={() => setActiveVideoApt(null)}
          onSelectPatient={onSelectPatient}
        />
      )}
    </div>
  );
};
