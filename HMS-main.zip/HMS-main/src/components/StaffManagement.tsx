import React, { useState } from 'react';
import {
  Stethoscope,
  Users,
  Plus,
  Search,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Phone,
  Mail,
  Building,
  UserCheck,
  Award,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { StaffMember, UserRole } from '../types';

export const StaffManagement: React.FC = () => {
  const {
    staff,
    addStaff,
    updateStaff,
    currentRole,
    setCurrentRole,
    currentUser,
    setCurrentUserId,
  } = useHospital();

  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    role: 'doctor' as UserRole,
    department: 'Cardiovascular Care',
    shift: 'Morning (07:00 - 15:00)' as StaffMember['shift'],
    phone: '+1 (555) 912-3000',
    email: '',
    roomOrStation: 'Clinic Suite 201',
    licenseNumber: 'MD-IL-00000',
    status: 'On Duty' as StaffMember['status'],
  });

  const filteredStaff = staff.filter((s) => {
    const matchesSearch =
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.licenseNumber.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRole = roleFilter === 'all' || s.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addStaff(formData);
    setFormData({
      name: '',
      role: 'doctor',
      department: 'Cardiovascular Care',
      shift: 'Morning (07:00 - 15:00)',
      phone: '+1 (555) 912-3000',
      email: '',
      roomOrStation: 'Clinic Suite 201',
      licenseNumber: 'MD-IL-00000',
      status: 'On Duty',
    });
    setShowAddModal(false);
  };

  const handleStatusChange = (id: string, newStatus: StaffMember['status']) => {
    updateStaff(id, { status: newStatus });
  };

  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Stethoscope className="w-5 h-5 text-blue-600" />
            <h1 className="text-base lg:text-lg font-bold text-slate-800 tracking-tight">
              Doctor & Medical Staff Management
            </h1>
            <span className="px-2 py-0.5 text-[10px] font-bold bg-purple-100 text-purple-800 rounded">
              DUTY ROSTER
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Clinical credentials, specialty assignments, active duty shifts, and on-call operational status.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-semibold flex items-center gap-1.5 shadow-sm transition"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Register Staff Member</span>
        </button>
      </div>

      {/* Staff Roster Overview Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Total Staff</span>
          <div className="text-xl font-bold text-slate-800 font-mono mt-1">{staff.length}</div>
          <span className="text-[11px] text-slate-500">Across all hospital units</span>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Currently On Duty</span>
          <div className="text-xl font-bold text-emerald-600 font-mono mt-1">
            {staff.filter((s) => s.status === 'On Duty' || s.status === 'In Consultation' || s.status === 'In Surgery').length}
          </div>
          <span className="text-[11px] text-slate-500">Active in hospital wards</span>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">In Surgery / Consult</span>
          <div className="text-xl font-bold text-blue-600 font-mono mt-1">
            {staff.filter((s) => s.status === 'In Surgery' || s.status === 'In Consultation').length}
          </div>
          <span className="text-[11px] text-slate-500">Occupied clinicians</span>
        </div>
        <div className="p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Active Shift</span>
          <div className="text-xl font-bold text-slate-700 font-mono mt-1">Morning</div>
          <span className="text-[11px] text-slate-500">07:00 - 15:00 Shift Cycle</span>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
          <div className="relative flex-1 min-w-[180px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search staff by name, department, or license..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 border border-slate-200 rounded text-xs focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex items-center gap-1 flex-wrap">
            {['all', 'admin', 'receptionist', 'doctor', 'nurse', 'lab', 'radiology', 'pharmacist'].map((role) => (
              <button
                key={role}
                onClick={() => setRoleFilter(role)}
                className={`px-2 py-1 rounded font-medium capitalize transition text-xs ${
                  roleFilter === role
                    ? 'bg-slate-800 text-white font-semibold'
                    : 'text-slate-600 hover:bg-slate-200'
                }`}
              >
                {role === 'all' ? 'All Roles' : role === 'radiology' ? 'Radiology' : role === 'lab' ? 'Lab Techs' : `${role}s`}
              </button>
            ))}
          </div>
        </div>

        <span className="text-[11px] text-slate-500 font-mono">
          Showing {filteredStaff.length} clinical profiles
        </span>
      </div>

      {/* Staff Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredStaff.map((member) => {
          const isCurrentStaff = currentUser?.id === member.id;
          const roleBadgeColor =
            member.role === 'admin'
              ? 'bg-purple-100 text-purple-800 border-purple-200'
              : member.role === 'doctor'
              ? 'bg-blue-100 text-blue-800 border-blue-200'
              : member.role === 'nurse'
              ? 'bg-teal-100 text-teal-800 border-teal-200'
              : member.role === 'lab'
              ? 'bg-cyan-100 text-cyan-800 border-cyan-200'
              : member.role === 'radiology'
              ? 'bg-violet-100 text-violet-800 border-violet-200'
              : member.role === 'pharmacist'
              ? 'bg-indigo-100 text-indigo-800 border-indigo-200'
              : 'bg-amber-100 text-amber-800 border-amber-200';

          return (
            <div
              key={member.id}
              className={`bg-white rounded-lg border shadow-sm p-4 flex flex-col justify-between space-y-3 transition ${
                isCurrentStaff ? 'border-blue-400 ring-2 ring-blue-100' : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <h3 className="font-bold text-sm text-slate-800 truncate">{member.name}</h3>
                      {isCurrentStaff && (
                        <span className="text-[9px] font-bold bg-blue-600 text-white px-1.5 py-0.2 rounded shrink-0">
                          Active User
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                      <span
                        className={`text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded border ${roleBadgeColor}`}
                      >
                        {member.role}
                      </span>
                      <span className="text-xs text-slate-500 font-medium truncate">
                        {member.department}
                      </span>
                    </div>
                  </div>

                  <select
                    value={member.status}
                    onChange={(e) => handleStatusChange(member.id, e.target.value as StaffMember['status'])}
                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded border focus:outline-none shrink-0 ${
                      member.status === 'On Duty'
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : member.status === 'In Surgery'
                        ? 'bg-red-50 text-red-700 border-red-200'
                        : member.status === 'In Consultation'
                        ? 'bg-blue-50 text-blue-700 border-blue-200'
                        : member.status === 'On Break'
                        ? 'bg-amber-50 text-amber-700 border-amber-200'
                        : 'bg-slate-100 text-slate-600 border-slate-200'
                    }`}
                  >
                    <option value="On Duty">On Duty</option>
                    <option value="In Consultation">In Consultation</option>
                    <option value="In Surgery">In Surgery</option>
                    <option value="On Break">On Break</option>
                    <option value="Off Duty">Off Duty</option>
                  </select>
                </div>

                <div className="mt-3 space-y-1 text-xs text-slate-600">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Shift Schedule:</span>
                    <span className="font-medium text-slate-700">{member.shift}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Station / Room:</span>
                    <span className="font-medium text-slate-700">{member.roomOrStation}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">License ID:</span>
                    <span className="font-mono text-slate-800">{member.licenseNumber}</span>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500 gap-2">
                <span className="flex items-center gap-1 font-mono truncate">
                  <Phone className="w-3 h-3 text-slate-400 shrink-0" />
                  {member.phone}
                </span>

                {!isCurrentStaff ? (
                  <button
                    onClick={() => {
                      setCurrentUserId(member.id);
                    }}
                    className="px-2 py-0.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-600 border border-slate-200 hover:border-blue-200 rounded text-[10px] font-semibold transition shrink-0 cursor-pointer"
                  >
                    Switch to Profile
                  </button>
                ) : (
                  <span className="text-[10px] text-emerald-600 font-bold shrink-0 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Logged In
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Staff Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-md w-full p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h3 className="font-bold text-sm text-slate-800">
                Register Clinical or Administrative Staff
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-600 font-medium mb-1">Full Name & Degree</label>
                <input
                  type="text"
                  placeholder="e.g. Dr. Jennifer Wu, MD, FACS"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full p-2 border border-slate-200 rounded font-semibold text-slate-800"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Role / Access Level</label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value as UserRole })}
                    className="w-full p-2 border border-slate-200 rounded"
                  >
                    <option value="doctor">Doctor / Physician</option>
                    <option value="nurse">Nurse / RN</option>
                    <option value="lab">Lab Technologist</option>
                    <option value="radiology">Radiologist (Diagnostic Imaging / PACS)</option>
                    <option value="pharmacist">Pharmacist</option>
                    <option value="receptionist">Receptionist / Intake</option>
                    <option value="admin">Hospital Administrator</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Department</label>
                  <input
                    type="text"
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="w-full p-2 border border-slate-200 rounded"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Shift</label>
                  <select
                    value={formData.shift}
                    onChange={(e) => setFormData({ ...formData, shift: e.target.value as StaffMember['shift'] })}
                    className="w-full p-2 border border-slate-200 rounded"
                  >
                    <option value="Morning (07:00 - 15:00)">Morning (07:00 - 15:00)</option>
                    <option value="Evening (15:00 - 23:00)">Evening (15:00 - 23:00)</option>
                    <option value="Night (23:00 - 07:00)">Night (23:00 - 07:00)</option>
                    <option value="On-Call">On-Call</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">License #</label>
                  <input
                    type="text"
                    value={formData.licenseNumber}
                    onChange={(e) => setFormData({ ...formData, licenseNumber: e.target.value })}
                    className="w-full p-2 border border-slate-200 rounded font-mono"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Station / Room</label>
                  <input
                    type="text"
                    value={formData.roomOrStation}
                    onChange={(e) => setFormData({ ...formData, roomOrStation: e.target.value })}
                    className="w-full p-2 border border-slate-200 rounded"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-1">Phone</label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full p-2 border border-slate-200 rounded font-mono"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Staff Email</label>
                <input
                  type="email"
                  placeholder="name@apexhealth.org"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full p-2 border border-slate-200 rounded"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 border border-slate-300 rounded text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded font-semibold"
                >
                  Register Staff
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
