import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  Download,
  Calendar,
  DollarSign,
  Users,
  BedDouble,
  Activity,
  Filter,
  CheckCircle2,
  AlertTriangle,
  FileSpreadsheet,
  Clock,
  Building,
  Film,
  FlaskConical,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';

export const ReportsAnalytics: React.FC = () => {
  const {
    patients,
    appointments,
    invoices,
    wardBeds,
    radiologyScans,
    doctors,
    staff,
    currentRole,
    currentRoleDefinition,
  } = useHospital();

  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d' | 'ytd'>('30d');
  const [selectedDepartment, setSelectedDepartment] = useState<string>('all');

  // Computed metrics
  const totalBeds = wardBeds.length;
  const occupiedBeds = wardBeds.filter((b) => b.status === 'Occupied').length;
  const bedOccupancyRate = totalBeds > 0 ? Math.round((occupiedBeds / totalBeds) * 100) : 0;

  const totalInvoiced = invoices.reduce((acc, inv) => acc + inv.totalAmount, 0);
  const totalCollected = invoices.reduce((acc, inv) => acc + inv.amountPaid, 0);
  const collectionRate = totalInvoiced > 0 ? Math.round((totalCollected / totalInvoiced) * 100) : 0;

  const completedAppointments = appointments.filter((a) => a.status === 'Completed').length;
  const activeAppointments = appointments.filter((a) => a.status !== 'Completed' && a.status !== 'Cancelled').length;

  const statScans = radiologyScans.filter((s) => s.urgency === 'STAT / Emergency').length;
  const completedScans = radiologyScans.filter((s) => s.status === 'Completed').length;

  // Department analytics data
  const departmentStats = [
    { name: 'Cardiovascular Care', patients: 142, revenue: '$48,200', occupancy: '88%', waitTime: '14 min' },
    { name: 'Emergency Medicine', patients: 310, revenue: '$72,600', occupancy: '94%', waitTime: '6 min' },
    { name: 'Orthopedic Surgery', patients: 86, revenue: '$34,100', occupancy: '76%', waitTime: '18 min' },
    { name: 'Internal & Family Medicine', patients: 220, revenue: '$29,400', occupancy: '65%', waitTime: '12 min' },
    { name: 'Diagnostic Imaging (PACS)', patients: 178, revenue: '$39,800', occupancy: '82%', waitTime: '22 min' },
    { name: 'Pathology & Laboratory', patients: 405, revenue: '$21,900', occupancy: '91%', waitTime: '8 min' },
  ];

  // Daily admissions trend for chart
  const weeklyTrend = [
    { day: 'Mon', admissions: 34, discharges: 28, revenue: 14200 },
    { day: 'Tue', admissions: 42, discharges: 36, revenue: 16800 },
    { day: 'Wed', admissions: 38, discharges: 31, revenue: 15400 },
    { day: 'Thu', admissions: 45, discharges: 39, revenue: 18200 },
    { day: 'Fri', admissions: 48, discharges: 44, revenue: 19500 },
    { day: 'Sat', admissions: 29, discharges: 26, revenue: 11300 },
    { day: 'Sun', admissions: 24, discharges: 22, revenue: 9800 },
  ];

  const maxAdmissions = Math.max(...weeklyTrend.map((d) => d.admissions));

  // Top ICD-10 Diagnoses
  const topDiagnoses = [
    { code: 'I10', desc: 'Essential Primary Hypertension', count: 68, pct: 32 },
    { code: 'E11.9', desc: 'Type 2 Diabetes Mellitus', count: 54, pct: 25 },
    { code: 'J20.9', desc: 'Acute Bronchitis Unspecified', count: 39, pct: 18 },
    { code: 'M54.5', desc: 'Low Back Pain / Lumbar Spondylosis', count: 31, pct: 14 },
    { code: 'E78.5', desc: 'Hyperlipidemia Primary', count: 24, pct: 11 },
  ];

  const handleExportSummary = () => {
    const reportData = [
      ['Metric', 'Value'],
      ['Report Range', timeRange.toUpperCase()],
      ['Total Registered Patients', patients.length.toString()],
      ['Bed Occupancy Rate', `${bedOccupancyRate}%`],
      ['Total Invoiced Amount', `$${totalInvoiced.toLocaleString()}`],
      ['Total Collections', `$${totalCollected.toLocaleString()}`],
      ['Claims Collection Rate', `${collectionRate}%`],
      ['Completed Appointments', completedAppointments.toString()],
      ['Active Queue Appointments', activeAppointments.toString()],
      ['Radiology Scans Completed', completedScans.toString()],
      ['STAT Scans', statScans.toString()],
    ];

    const csv = 'data:text/csv;charset=utf-8,' + reportData.map((e) => e.join(',')).join('\n');
    const link = document.createElement('a');
    link.setAttribute('href', encodeURI(csv));
    link.setAttribute('download', `ApexHealth_Executive_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto space-y-4">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-blue-600" />
            <h1 className="text-base lg:text-lg font-bold text-slate-800 tracking-tight">
              Hospital Operations, Clinical Quality & Revenue Analytics
            </h1>
            <span className="px-2 py-0.5 text-[10px] font-bold bg-blue-100 text-blue-800 rounded">
              EXECUTIVE BI
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Real-time throughput metrics, bed utilization indices, diagnostic cycle times, and insurance collection ratios.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-100 p-0.5 rounded border border-slate-200 text-xs">
            {(['7d', '30d', '90d', 'ytd'] as const).map((r) => (
              <button
                key={r}
                onClick={() => setTimeRange(r)}
                className={`px-2.5 py-1 rounded font-semibold uppercase text-[11px] transition ${
                  timeRange === r
                    ? 'bg-white text-slate-800 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                {r}
              </button>
            ))}
          </div>

          <button
            onClick={handleExportSummary}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded text-xs font-semibold flex items-center gap-1.5 shadow-sm transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Role Context Alert / Insight */}
      <div className="bg-slate-900 text-white rounded-lg p-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3 border border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-blue-500/20 border border-blue-400/40 flex items-center justify-center shrink-0">
            <Activity className="w-4 h-4 text-blue-400" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-200 flex items-center gap-2">
              <span>Persona-Tailored Intelligence for:</span>
              <span className="capitalize text-blue-400 font-extrabold">{currentRoleDefinition?.label || currentRole}</span>
            </div>
            <p className="text-[11px] text-slate-400">
              {currentRole === 'doctor' && 'Review your assigned patient caseload, encounter completion rates, and outstanding diagnostic reviews.'}
              {currentRole === 'nurse' && 'Monitor ward occupancy levels, pending medication administrations, and bed turnover velocity.'}
              {currentRole === 'lab' && 'Track specimen turnaround duration, critical assay notifications, and clinical chemistry throughput.'}
              {currentRole === 'radiology' && 'Monitor PACS imaging queue velocity, STAT scan triage, and radiologist sign-off timelines.'}
              {currentRole === 'receptionist' && 'Oversee patient registration flow, queue wait times, and copay intake reconciliation.'}
              {currentRole === 'admin' && 'Enterprise view: monitor HIPAA security logs, gross receivables, and multi-department performance.'}
              {currentRole === 'pharmacist' && 'Check prescription fulfillment rate, low-stock formulary alerts, and dispense verification.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0 text-xs font-mono">
          <div className="bg-slate-800/80 px-2.5 py-1.5 rounded border border-slate-700">
            <span className="text-slate-400 text-[10px] block">CENSUS OCCUPANCY</span>
            <span className="text-emerald-400 font-bold text-sm">{bedOccupancyRate}%</span>
          </div>
          <div className="bg-slate-800/80 px-2.5 py-1.5 rounded border border-slate-700">
            <span className="text-slate-400 text-[10px] block">COLLECTION RATIO</span>
            <span className="text-blue-400 font-bold text-sm">{collectionRate}%</span>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[10px] uppercase font-bold tracking-wider">Bed Occupancy Index</span>
            <BedDouble className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-800 mt-1">
            {occupiedBeds} / {totalBeds}
          </div>
          <div className="flex items-center gap-1 mt-1 text-[11px] text-emerald-600 font-medium">
            <TrendingUp className="w-3 h-3" />
            <span>{bedOccupancyRate}% capacity utilization</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[10px] uppercase font-bold tracking-wider">Gross Billed Invoices</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-800 mt-1">
            ${totalInvoiced.toLocaleString()}
          </div>
          <div className="flex items-center gap-1 mt-1 text-[11px] text-slate-500">
            <span>Collected: </span>
            <span className="font-bold text-slate-700 font-mono">${totalCollected.toLocaleString()}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[10px] uppercase font-bold tracking-wider">Clinical Consultations</span>
            <Calendar className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-800 mt-1">
            {completedAppointments + activeAppointments}
          </div>
          <div className="flex items-center gap-1 mt-1 text-[11px] text-indigo-600 font-medium">
            <CheckCircle2 className="w-3 h-3" />
            <span>{completedAppointments} completed • {activeAppointments} in queue</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[10px] uppercase font-bold tracking-wider">Diagnostic Studies (PACS/LIMS)</span>
            <Film className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-800 mt-1">
            {radiologyScans.length} Studies
          </div>
          <div className="flex items-center gap-1 mt-1 text-[11px] text-purple-600 font-medium">
            <span>{statScans} STAT emergency priority</span>
          </div>
        </div>
      </div>

      {/* Main Analytics Grid: Weekly Patient Admissions Trend & Top ICD-10 Diagnoses */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Weekly Trend Bar Chart */}
        <div className="lg:col-span-2 bg-white p-4 rounded-lg border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-xs uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-blue-600" />
                Inpatient Admissions vs Discharge Velocity (7-Day Cycle)
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Comparison of daily patient intake, successful discharges, and hospital floor flow.
              </p>
            </div>
            <div className="flex items-center gap-3 text-[11px]">
              <div className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded bg-blue-600" />
                <span className="text-slate-600 font-medium">Admissions</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded bg-teal-400" />
                <span className="text-slate-600 font-medium">Discharges</span>
              </div>
            </div>
          </div>

          <div className="pt-4 pb-2">
            <div className="h-44 flex items-end justify-between gap-3 px-2 border-b border-slate-200">
              {weeklyTrend.map((item) => {
                const admissionHeight = Math.round((item.admissions / maxAdmissions) * 100);
                const dischargeHeight = Math.round((item.discharges / maxAdmissions) * 100);

                return (
                  <div key={item.day} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end group">
                    <div className="w-full flex items-end justify-center gap-1 h-36">
                      {/* Admissions Bar */}
                      <div
                        style={{ height: `${admissionHeight}%` }}
                        className="w-4 bg-blue-600 hover:bg-blue-700 rounded-t transition relative group-hover:scale-y-105"
                        title={`${item.admissions} admissions`}
                      >
                        <span className="hidden group-hover:block absolute -top-5 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[9px] px-1 rounded font-mono z-10 whitespace-nowrap">
                          +{item.admissions}
                        </span>
                      </div>

                      {/* Discharges Bar */}
                      <div
                        style={{ height: `${dischargeHeight}%` }}
                        className="w-4 bg-teal-400 hover:bg-teal-500 rounded-t transition relative group-hover:scale-y-105"
                        title={`${item.discharges} discharges`}
                      >
                        <span className="hidden group-hover:block absolute -top-5 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[9px] px-1 rounded font-mono z-10 whitespace-nowrap">
                          -{item.discharges}
                        </span>
                      </div>
                    </div>
                    <span className="text-[11px] font-bold text-slate-600 font-mono">{item.day}</span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-100 text-xs">
            <div className="p-2 bg-slate-50 rounded">
              <span className="text-slate-400 text-[10px] block">Average Daily Census</span>
              <span className="font-bold text-slate-800 font-mono text-sm">38.5 / day</span>
            </div>
            <div className="p-2 bg-slate-50 rounded">
              <span className="text-slate-400 text-[10px] block">Average Inpatient LOS</span>
              <span className="font-bold text-slate-800 font-mono text-sm">3.4 Days</span>
            </div>
            <div className="p-2 bg-slate-50 rounded">
              <span className="text-slate-400 text-[10px] block">Readmission Rate (30-day)</span>
              <span className="font-bold text-emerald-600 font-mono text-sm">3.2% (Target: &lt;4%)</span>
            </div>
          </div>
        </div>

        {/* Top Diagnoses & Clinical Distribution */}
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm space-y-3">
          <div className="border-b border-slate-100 pb-2">
            <h3 className="font-bold text-xs uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-blue-600" />
              Prevalent Pathologies (ICD-10)
            </h3>
            <span className="text-[11px] text-slate-500">Most frequent active diagnoses</span>
          </div>

          <div className="space-y-3">
            {topDiagnoses.map((diag) => (
              <div key={diag.code} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <div className="min-w-0 pr-2">
                    <span className="font-bold text-slate-800 font-mono text-[11px] mr-1.5">
                      [{diag.code}]
                    </span>
                    <span className="text-slate-700 text-[11px] truncate">{diag.desc}</span>
                  </div>
                  <span className="text-slate-500 font-mono text-[10px] shrink-0 font-bold">
                    {diag.count} pts ({diag.pct}%)
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-blue-600 h-full rounded-full"
                    style={{ width: `${diag.pct * 2.5}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-slate-100 text-[11px] text-slate-500">
            <div className="flex items-center justify-between py-0.5">
              <span>Chronic Disease Cohort:</span>
              <span className="font-bold text-slate-700">57%</span>
            </div>
            <div className="flex items-center justify-between py-0.5">
              <span>Surgical / Post-Op Recovery:</span>
              <span className="font-bold text-slate-700">24%</span>
            </div>
            <div className="flex items-center justify-between py-0.5">
              <span>Acute Trauma / Critical Care:</span>
              <span className="font-bold text-slate-700">19%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Department Performance Matrix Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-3 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Building className="w-4 h-4 text-slate-600" />
            <h3 className="font-bold text-xs text-slate-800 uppercase tracking-wider">
              Department Operations & Financial Throughput
            </h3>
          </div>
          <span className="text-[10px] text-slate-500">
            All 6 clinical service lines reporting
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100/70 text-slate-600 font-semibold border-b border-slate-200 text-[10px] uppercase tracking-wider">
              <tr>
                <th className="py-2.5 px-3">Service Line / Department</th>
                <th className="py-2.5 px-3 text-right">Patient Encounters</th>
                <th className="py-2.5 px-3 text-right">Monthly Revenue</th>
                <th className="py-2.5 px-3 text-center">Unit Occupancy</th>
                <th className="py-2.5 px-3 text-right">Avg Intake Wait</th>
                <th className="py-2.5 px-3 text-center">Operational Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {departmentStats.map((dept) => (
                <tr key={dept.name} className="hover:bg-slate-50 transition">
                  <td className="py-2.5 px-3 font-bold text-slate-800">
                    {dept.name}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-medium text-slate-700">
                    {dept.patients}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-800">
                    {dept.revenue}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-100 text-slate-700">
                      {dept.occupancy}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-slate-600">
                    {dept.waitTime}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      Optimal
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
