import React, { useState, useEffect } from 'react';
import {
  Bell,
  Search,
  UserPlus,
  CalendarPlus,
  ReceiptText,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Info,
  X,
  ShieldCheck,
  Activity,
  Clock,
  Sparkles,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';

interface HeaderProps {
  onOpenNewPatient: () => void;
  onOpenNewAppointment: () => void;
  onOpenNewInvoice: () => void;
  onSelectPatient: (id: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenNewPatient,
  onOpenNewAppointment,
  onOpenNewInvoice,
  onSelectPatient,
}) => {
  const {
    notifications,
    markNotificationRead,
    clearAllNotifications,
    patients,
    resetHospitalData,
    setActiveTab,
  } = useHospital();

  const [currentTime, setCurrentTime] = useState<string>('');
  const [showNotifications, setShowNotifications] = useState(false);
  const [globalSearch, setGlobalSearch] = useState('');
  const [searchFocused, setSearchFocused] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const searchResults = globalSearch.trim()
    ? patients.filter(
        (p) =>
          p.firstName.toLowerCase().includes(globalSearch.toLowerCase()) ||
          p.lastName.toLowerCase().includes(globalSearch.toLowerCase()) ||
          p.id.toLowerCase().includes(globalSearch.toLowerCase()) ||
          p.chronicConditions.some((c) => c.toLowerCase().includes(globalSearch.toLowerCase()))
      )
    : [];

  const emergencyPatientsCount = patients.filter((p) => p.status === 'Emergency').length;

  return (
    <nav className="h-14 bg-white border-b border-slate-200 flex items-center justify-between px-4 lg:px-6 shrink-0 z-30 select-none">
      {/* Brand & Global Search */}
      <div className="flex items-center gap-6 lg:gap-8">
        <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => setActiveTab('overview')}>
          <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center text-white font-bold text-lg shadow-sm shadow-blue-600/30">
            +
          </div>
          <span className="font-bold text-base lg:text-lg tracking-tight text-slate-800">
            MEDCORE<span className="text-blue-600">OS</span>
          </span>
        </div>

        {/* Global Patient & Record Search */}
        <div className="relative hidden md:block">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              id="header-global-search"
              placeholder="Search records, patients, or doctors (Cmd+K)"
              value={globalSearch}
              onChange={(e) => setGlobalSearch(e.target.value)}
              onFocus={() => setSearchFocused(true)}
              onBlur={() => setTimeout(() => setSearchFocused(false), 250)}
              className="w-72 lg:w-80 bg-slate-50 border border-slate-200 rounded-md py-1.5 pl-8 pr-8 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 text-slate-900 placeholder-slate-400 transition"
            />
            {globalSearch && (
              <button
                onClick={() => setGlobalSearch('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>

          {/* Quick Search Dropdown */}
          {searchFocused && searchResults.length > 0 && (
            <div className="absolute top-full left-0 mt-1.5 w-96 bg-white border border-slate-200 rounded-md shadow-lg overflow-hidden z-50">
              <div className="p-2 bg-slate-50 border-b border-slate-200 text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                Matching Patient Records ({searchResults.length})
              </div>
              <div className="max-h-60 overflow-y-auto divide-y divide-slate-100">
                {searchResults.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => {
                      onSelectPatient(p.id);
                      setGlobalSearch('');
                      setActiveTab('patients');
                    }}
                    className="w-full text-left p-2.5 hover:bg-slate-50 flex items-center justify-between transition group"
                  >
                    <div>
                      <div className="font-semibold text-xs text-slate-800 group-hover:text-blue-600">
                        {p.firstName} {p.lastName}{' '}
                        <span className="text-[10px] text-slate-400 font-mono">({p.id})</span>
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {p.age}y • {p.gender} • Blood: <span className="font-semibold">{p.bloodGroup}</span> • {p.primaryPhysicianName}
                      </div>
                    </div>
                    <span
                      className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                        p.status === 'Emergency'
                          ? 'bg-red-100 text-red-700'
                          : p.status === 'Inpatient'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {p.status}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Center status badges */}
      <div className="hidden xl:flex items-center gap-3">
        <div className="flex items-center gap-1.5 text-xs text-slate-600 bg-slate-100 px-2.5 py-1 rounded border border-slate-200 font-mono">
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          <span>{currentTime || '00:00:00'} EST</span>
        </div>

        {emergencyPatientsCount > 0 && (
          <div className="flex items-center gap-1.5 text-xs font-bold text-red-600 bg-red-50 border border-red-200 px-2.5 py-1 rounded animate-pulse">
            <AlertTriangle className="w-3.5 h-3.5 text-red-600" />
            <span>{emergencyPatientsCount} ER ADMISSIONS ACTIVE</span>
          </div>
        )}
      </div>

      {/* Right Controls: Action triggers, Notifications, Profile */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Quick Action Buttons */}
        <button
          id="btn-quick-new-patient"
          onClick={onOpenNewPatient}
          className="flex items-center gap-1.5 px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold transition shadow-sm"
          title="Admit new patient or log record"
        >
          <UserPlus className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Admit Patient</span>
        </button>

        <button
          id="btn-quick-new-appointment"
          onClick={onOpenNewAppointment}
          className="hidden md:flex items-center gap-1.5 px-2.5 py-1 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-700 rounded text-xs font-semibold transition"
          title="Schedule patient appointment"
        >
          <CalendarPlus className="w-3.5 h-3.5 text-slate-500" />
          <span>Book Slot</span>
        </button>

        <button
          id="btn-quick-new-invoice"
          onClick={onOpenNewInvoice}
          className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-700 rounded text-xs font-semibold transition"
          title="Generate billing invoice"
        >
          <ReceiptText className="w-3.5 h-3.5 text-slate-500" />
          <span>New Invoice</span>
        </button>

        {/* Notifications Popover */}
        <div className="relative">
          <button
            id="btn-header-notifications"
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded transition"
            aria-label="Alerts"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute top-0.5 right-0.5 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-blue-600 text-[9px] font-bold text-white">
                {unreadCount}
              </span>
            )}
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-md shadow-xl border border-slate-200 overflow-hidden z-50">
              <div className="p-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Activity className="w-3.5 h-3.5 text-blue-600" />
                  <span className="font-bold text-xs uppercase tracking-wide text-slate-800">
                    Live Telemetry Feeds ({unreadCount})
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={clearAllNotifications}
                    className="text-[10px] text-slate-500 hover:text-slate-700 uppercase font-semibold underline"
                  >
                    Clear
                  </button>
                  <button
                    onClick={() => setShowNotifications(false)}
                    className="text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                {notifications.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-400">
                    All telemetry feeds operational. No alerts.
                  </div>
                ) : (
                  notifications.map((notif) => (
                    <div
                      key={notif.id}
                      onClick={() => markNotificationRead(notif.id)}
                      className={`p-3 transition cursor-pointer hover:bg-slate-50 ${
                        notif.read ? 'bg-white' : 'bg-blue-50/40'
                      }`}
                    >
                      <div className="flex items-start gap-2.5">
                        {notif.type === 'critical' ? (
                          <div className="w-2 h-2 mt-1 rounded-full bg-red-500 shrink-0" />
                        ) : notif.type === 'warning' ? (
                          <div className="w-2 h-2 mt-1 rounded-full bg-amber-500 shrink-0" />
                        ) : notif.type === 'success' ? (
                          <div className="w-2 h-2 mt-1 rounded-full bg-emerald-500 shrink-0" />
                        ) : (
                          <div className="w-2 h-2 mt-1 rounded-full bg-blue-500 shrink-0" />
                        )}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <h4 className="text-xs font-bold text-slate-800 truncate">{notif.title}</h4>
                            <span className="text-[10px] text-slate-400 font-mono">{notif.timestamp}</span>
                          </div>
                          <p className="text-[11px] text-slate-600 mt-0.5 leading-tight">
                            {notif.message}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              <div className="p-2 bg-slate-50 border-t border-slate-200 text-center flex items-center justify-center gap-1.5 text-[10px] text-slate-500">
                <ShieldCheck className="w-3 h-3 text-emerald-600" />
                <span>PCI-DSS & HIPAA Compliant Session</span>
              </div>
            </div>
          )}
        </div>

        {/* Reset System Data */}
        <button
          id="btn-header-reset"
          onClick={() => {
            if (window.confirm('Reset hospital database to default sample records?')) {
              resetHospitalData();
            }
          }}
          className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded transition"
          title="Reset hospital demo records"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>

        {/* User / Doctor Profile Badge */}
        <div className="flex items-center gap-3 pl-2 border-l border-slate-200">
          <div className="hidden sm:flex flex-col items-end">
            <span className="text-xs font-semibold text-slate-700">Dr. Julian Thorne</span>
            <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">
              Chief of Surgery
            </span>
          </div>
          <div className="w-8 h-8 rounded-full bg-blue-100 border border-blue-200 text-blue-700 font-bold text-xs flex items-center justify-center">
            JT
          </div>
        </div>
      </div>
    </nav>
  );
};

