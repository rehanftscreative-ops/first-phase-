import React, { useState, useMemo } from 'react';
import {
  Scan,
  Search,
  Plus,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Eye,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Sliders,
  Printer,
  FileCheck,
  Activity,
  Layers,
  Sparkles,
  Info,
  Calendar,
  User,
  Stethoscope,
  ChevronLeft,
  ChevronRight,
  Shield,
  FileText
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { LabResult } from '../types';

export interface ImagingStudy {
  id: string; // e.g. RAD-2026-8801
  accessionNumber: string;
  patientId: string;
  patientName: string;
  patientAge: number;
  patientGender: string;
  modality: 'X-Ray' | 'CT' | 'MRI' | 'Ultrasound' | 'Mammography';
  bodyPart: string;
  studyDate: string;
  status: 'Completed' | 'In Review' | 'Scheduled' | 'STAT Emergency';
  priority: 'Routine' | 'Urgent' | 'STAT';
  orderingPhysician: string;
  radiologist: string;
  clinicalIndication: string;
  findings: string;
  impression: string;
  technique: string;
  totalSlices: number;
  criticalFinding: boolean;
  contrastUsed: boolean;
  radiationDose?: string;
  signedOff: boolean;
  addenda?: string[];
}

export const RadiologyImaging: React.FC = () => {
  const { patients, doctors, addLabResult, logAuditEvent, setSelectedPatientId, setActiveTab } = useHospital();

  // Initial rich studies collection
  const [studies, setStudies] = useState<ImagingStudy[]>([
    {
      id: 'RAD-2026-8801',
      accessionNumber: 'ACC-89102-XRAY',
      patientId: patients[0]?.id || 'PT-10492',
      patientName: patients[0] ? `${patients[0].firstName} ${patients[0].lastName}` : 'Eleanor Pemberton',
      patientAge: patients[0]?.age || 58,
      patientGender: patients[0]?.gender || 'Female',
      modality: 'X-Ray',
      bodyPart: 'Chest 2-View (PA & Lateral)',
      studyDate: '2026-03-28 09:15 AM',
      status: 'Completed',
      priority: 'Routine',
      orderingPhysician: 'Dr. Julian Thorne, MD',
      radiologist: 'Dr. Sarah Jenkins, MD (Cardiothoracic Radiology)',
      clinicalIndication: 'Persistent dry cough, mild exertional dyspnea, evaluate for pneumonia or congestive heart failure.',
      technique: 'PA and lateral views of the chest obtained in upright inspiration. Exposure: 120 kVp, 3.2 mAs.',
      findings: 'Heart size is at the upper limit of normal with cardiothoracic ratio of 0.51. Mediastinal and hilar contours are stable without lymphadenopathy. Mild bilateral interstitial markings noted in perihilar zones without focal consolidation. No pneumothorax or pleural effusion. Costophrenic angles remain sharp. Osseous structures demonstrate mild degenerative changes of thoracic spine.',
      impression: '1. No acute lobar consolidation or pneumothorax.\n2. Mild cardiomegaly and subtle perihilar vascular prominence, suggestive of early mild volume overload vs baseline age-related changes.\n3. Clinical correlation with cardiac biomarkers recommended.',
      totalSlices: 1,
      criticalFinding: false,
      contrastUsed: false,
      radiationDose: '0.08 mSv',
      signedOff: true,
      addenda: ['2026-03-28 11:30 AM: Clinical team notified of stable cardiothoracic ratio.']
    },
    {
      id: 'RAD-2026-8802',
      accessionNumber: 'ACC-89105-CT',
      patientId: patients[1]?.id || 'PT-10493',
      patientName: patients[1] ? `${patients[1].firstName} ${patients[1].lastName}` : 'Marcus Vance',
      patientAge: patients[1]?.age || 44,
      patientGender: patients[1]?.gender || 'Male',
      modality: 'CT',
      bodyPart: 'Head / Brain Non-Contrast',
      studyDate: '2026-03-28 11:45 AM',
      status: 'STAT Emergency',
      priority: 'STAT',
      orderingPhysician: 'Dr. Julian Thorne, MD (Trauma & Emergency)',
      radiologist: 'Dr. Elena Rostova, MD (Neuroradiology)',
      clinicalIndication: 'Acute neurological deficit, left facial droop and right upper extremity weakness. Rule out acute intracranial hemorrhage vs ischemic stroke.',
      technique: 'Axial contiguous volumetric non-contrast CT slices reconstructed at 1.25mm and 5mm from skull base to vertex. Helical acquisition.',
      findings: 'No hyperdense acute intra-axial or extra-axial hemorrhage identified. Ventricular system, basal cisterns, and cerebral sulci are within normal limits for age without midline shift or mass effect. Subtle hypoattenuation noted within the left middle cerebral artery (MCA) territory cortex/subcortical white matter. Gray-white differentiation is slightly blurred along the left insular ribbon (early ischemic sign). Orbits, paranasal sinuses, and mastoid air cells are clear.',
      impression: '1. No intracranial hemorrhage, midline shift, or cerebral herniation.\n2. Subtle loss of insular ribbon definition in left MCA territory concerning for hyperacute non-hemorrhagic ischemic infarction.\n3. STAT emergent stroke neurology evaluation and consider CT angiogram / perfusion.',
      totalSlices: 16,
      criticalFinding: true,
      contrastUsed: false,
      radiationDose: '1.8 mSv (CTDIvol: 52 mGy)',
      signedOff: true,
      addenda: ['2026-03-28 12:05 PM: STAT verbal notification communicated directly to Dr. Thorne (ED Trauma Bay 2).']
    },
    {
      id: 'RAD-2026-8803',
      accessionNumber: 'ACC-89109-MRI',
      patientId: patients[2]?.id || 'PT-10494',
      patientName: patients[2] ? `${patients[2].firstName} ${patients[2].lastName}` : 'Sophia Lin',
      patientAge: patients[2]?.age || 32,
      patientGender: patients[2]?.gender || 'Female',
      modality: 'MRI',
      bodyPart: 'Lumbar Spine Multi-Sequence',
      studyDate: '2026-03-27 03:20 PM',
      status: 'Completed',
      priority: 'Urgent',
      orderingPhysician: 'Dr. Marcus Vance, MD, FACS',
      radiologist: 'Dr. Elena Rostova, MD (Musculoskeletal & Spine)',
      clinicalIndication: 'Severe unremitting lower back pain radiating down left L5 distribution with tingling. Failed conservative physical therapy.',
      technique: 'Sagittal and axial T1-weighted, T2-weighted, and STIR MR images of the lumbar spine obtained on a 3.0 Tesla high-field scanner.',
      findings: 'Vertebral body heights and lumbar lordosis are preserved. Normal bone marrow signal without compression fracture. At L4-L5: Moderate disc desiccation with a focal left paracentral/foraminal disc extrusion measuring 4.8 mm, causing compression on the exiting left L5 nerve root and mild thecal sac impingement. L1-L2, L2-L3, and L5-S1 levels demonstrate normal disc contour without significant stenosis.',
      impression: '1. Left paracentral disc extrusion at L4-L5 impinging upon the traversing and exiting left L5 nerve root.\n2. No canal stenosis or cord termination abnormality.',
      totalSlices: 12,
      criticalFinding: false,
      contrastUsed: false,
      radiationDose: '0 mSv (Non-ionizing)',
      signedOff: true,
    },
    {
      id: 'RAD-2026-8804',
      accessionNumber: 'ACC-89114-US',
      patientId: patients[3]?.id || 'PT-10495',
      patientName: patients[3] ? `${patients[3].firstName} ${patients[3].lastName}` : 'Carlos Ramirez',
      patientAge: patients[3]?.age || 67,
      patientGender: patients[3]?.gender || 'Male',
      modality: 'Ultrasound',
      bodyPart: 'Abdomen Complete & Doppler',
      studyDate: '2026-03-27 10:00 AM',
      status: 'In Review',
      priority: 'Routine',
      orderingPhysician: 'Dr. Sarah Jenkins, MD',
      radiologist: 'Dr. Anita Patel, MD',
      clinicalIndication: 'Right upper quadrant postprandial discomfort, mildly elevated AST/ALT and alkaline phosphatase.',
      technique: 'Real-time B-mode and color Doppler ultrasonography of the upper abdomen performed using curved and linear transducers.',
      findings: 'Liver demonstrates diffusely increased echogenicity consistent with grade 2 hepatic steatosis. No focal hepatic mass. Gallbladder contains multiple mobile acoustic shadowing echogenic calculi measuring up to 11 mm. Gallbladder wall thickness is 2.8 mm (normal). No sonographic Murphy sign or pericholecystic fluid. Common bile duct measures 4.2 mm, within normal limits. Spleen, pancreas, and kidneys are unremarkable.',
      impression: '1. Cholelithiasis without sonographic evidence of acute cholecystitis.\n2. Moderate diffuse hepatic steatosis.\n3. Common bile duct caliber is normal without choledocholithiasis.',
      totalSlices: 6,
      criticalFinding: false,
      contrastUsed: false,
      radiationDose: '0 mSv (Ultrasound)',
      signedOff: false,
    }
  ]);

  // Selected study for PACS DICOM viewer
  const [selectedStudyId, setSelectedStudyId] = useState<string>(studies[1].id);
  const currentStudy = studies.find(s => s.id === selectedStudyId) || studies[0];

  // Viewer interactive states
  const [currentSlice, setCurrentSlice] = useState<number>(8);
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [brightness, setBrightness] = useState<number>(100);
  const [contrast, setContrast] = useState<number>(100);
  const [invertGrayscale, setInvertGrayscale] = useState<boolean>(false);
  const [windowPreset, setWindowPreset] = useState<'standard' | 'bone' | 'lung' | 'softTissue' | 'brain'>('standard');
  const [measureToolActive, setMeasureToolActive] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [modalityFilter, setModalityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Modal for new Imaging Order
  const [showOrderModal, setShowOrderModal] = useState<boolean>(false);
  const [newOrder, setNewOrder] = useState({
    patientId: patients[0]?.id || '',
    modality: 'CT' as ImagingStudy['modality'],
    bodyPart: 'Chest / Thorax with IV Contrast',
    priority: 'Urgent' as ImagingStudy['priority'],
    clinicalIndication: '',
    orderingPhysician: doctors[0]?.name || 'Dr. Julian Thorne, MD',
    contrastUsed: true,
  });

  // Windowing preset adjustments
  const applyPreset = (preset: 'standard' | 'bone' | 'lung' | 'softTissue' | 'brain') => {
    setWindowPreset(preset);
    if (preset === 'bone') {
      setBrightness(110);
      setContrast(165);
    } else if (preset === 'lung') {
      setBrightness(130);
      setContrast(140);
    } else if (preset === 'softTissue') {
      setBrightness(100);
      setContrast(115);
    } else if (preset === 'brain') {
      setBrightness(95);
      setContrast(135);
    } else {
      setBrightness(100);
      setContrast(100);
    }
  };

  const handleResetViewer = () => {
    setZoomLevel(100);
    setBrightness(100);
    setContrast(100);
    setInvertGrayscale(false);
    setWindowPreset('standard');
    setMeasureToolActive(false);
  };

  // Filtered studies
  const filteredStudies = useMemo(() => {
    return studies.filter((study) => {
      const matchesSearch =
        study.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        study.accessionNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        study.bodyPart.toLowerCase().includes(searchQuery.toLowerCase()) ||
        study.patientId.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesModality = modalityFilter === 'all' || study.modality === modalityFilter;
      const matchesStatus = statusFilter === 'all' || study.status === statusFilter;
      return matchesSearch && matchesModality && matchesStatus;
    });
  }, [studies, searchQuery, modalityFilter, statusFilter]);

  const handleCreateOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const patientObj = patients.find(p => p.id === newOrder.patientId) || patients[0];
    const newId = `RAD-2026-${Math.floor(8800 + Math.random() * 1000)}`;
    const accession = `ACC-${Math.floor(89000 + Math.random() * 1000)}-${newOrder.modality.toUpperCase()}`;

    const createdStudy: ImagingStudy = {
      id: newId,
      accessionNumber: accession,
      patientId: patientObj.id,
      patientName: `${patientObj.firstName} ${patientObj.lastName}`,
      patientAge: patientObj.age,
      patientGender: patientObj.gender,
      modality: newOrder.modality,
      bodyPart: newOrder.bodyPart,
      studyDate: new Date().toLocaleString([], { month: '2-digit', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }),
      status: newOrder.priority === 'STAT' ? 'STAT Emergency' : 'Scheduled',
      priority: newOrder.priority,
      orderingPhysician: newOrder.orderingPhysician,
      radiologist: 'Assigned to On-Call Radiologist',
      clinicalIndication: newOrder.clinicalIndication || 'Clinical investigation as indicated.',
      technique: `Standard acquisition protocol for ${newOrder.modality} of ${newOrder.bodyPart}.`,
      findings: 'Study ordered and scheduled in PACS queue. Awaiting examination acquisition and radiologist interpretation.',
      impression: 'Pending examination acquisition.',
      totalSlices: newOrder.modality === 'CT' ? 16 : newOrder.modality === 'MRI' ? 12 : 1,
      criticalFinding: newOrder.priority === 'STAT',
      contrastUsed: newOrder.contrastUsed,
      radiationDose: newOrder.modality === 'X-Ray' ? '0.1 mSv' : newOrder.modality === 'CT' ? '2.5 mSv' : '0 mSv',
      signedOff: false,
    };

    setStudies(prev => [createdStudy, ...prev]);
    setSelectedStudyId(newId);

    // Sync to patient's lab/imaging records
    addLabResult(patientObj.id, {
      testName: `${newOrder.modality} - ${newOrder.bodyPart}`,
      category: 'Radiology',
      orderedDate: new Date().toISOString().split('T')[0],
      status: 'Pending',
      value: 'Imaging Scheduled in PACS',
      referenceRange: 'Normal anatomy without acute pathology',
      orderedBy: newOrder.orderingPhysician,
      notes: `Accession: ${accession}. Priority: ${newOrder.priority}`,
    });

    logAuditEvent(
      'CREATE',
      'Lab Result',
      newId,
      `Ordered ${newOrder.modality} imaging study (${newOrder.bodyPart}) for patient ${patientObj.firstName} ${patientObj.lastName} (MRN ${patientObj.id}). Priority: ${newOrder.priority}.`,
      'HIPAA Access Log'
    );

    setShowOrderModal(false);
  };

  const handleSignOffReport = (studyId: string) => {
    setStudies(prev =>
      prev.map(s => (s.id === studyId ? { ...s, signedOff: true, status: 'Completed' } : s))
    );
    logAuditEvent(
      'UPDATE',
      'Lab Result',
      studyId,
      `Radiologist finalized and electronically signed diagnostic report for study ${currentStudy.accessionNumber}`,
      'HIPAA Access Log'
    );
  };

  return (
    <div id="radiology-imaging-module" className="flex flex-col h-full bg-slate-900 text-slate-100 overflow-hidden">
      {/* Top Header Bar */}
      <div className="bg-slate-950 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
            <Scan className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold text-white tracking-wide">Radiology & PACS Imaging Suite</h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                DICOM 3.0 / HL7 Compliant
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Picture Archiving, Diagnostic Imaging Review, and Radiologist Structured Reporting
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            id="order-imaging-study-btn"
            onClick={() => setShowOrderModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold shadow transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            Order Imaging Study
          </button>
        </div>
      </div>

      {/* Main Workspace: Left Study Worklist & Right Interactive PACS Viewer */}
      <div className="flex-1 flex min-h-0 overflow-hidden">
        {/* Left Column: Studies Worklist (Width: 360px) */}
        <div className="w-80 md:w-96 border-r border-slate-800 bg-slate-950/60 flex flex-col shrink-0 min-h-0">
          {/* Worklist Filters */}
          <div className="p-3 border-b border-slate-800 space-y-2 bg-slate-900/40">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search patient, accession, body part..."
                className="w-full pl-8 pr-3 py-1.5 bg-slate-800 border border-slate-700 rounded text-xs text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="flex items-center gap-1.5 text-xs">
              <select
                value={modalityFilter}
                onChange={(e) => setModalityFilter(e.target.value)}
                className="flex-1 bg-slate-800 border border-slate-700 text-slate-200 rounded px-2 py-1 text-xs focus:outline-none focus:border-blue-500"
              >
                <option value="all">All Modalities</option>
                <option value="X-Ray">X-Ray (CXR/Skeletal)</option>
                <option value="CT">CT Scan</option>
                <option value="MRI">MRI</option>
                <option value="Ultrasound">Ultrasound</option>
              </select>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="flex-1 bg-slate-800 border border-slate-700 text-slate-200 rounded px-2 py-1 text-xs focus:outline-none focus:border-blue-500"
              >
                <option value="all">All Statuses</option>
                <option value="STAT Emergency">STAT Emergency</option>
                <option value="Completed">Completed</option>
                <option value="In Review">In Review</option>
                <option value="Scheduled">Scheduled</option>
              </select>
            </div>
          </div>

          {/* Worklist Items */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-800/80 p-1">
            {filteredStudies.map((study) => {
              const isSelected = study.id === selectedStudyId;
              return (
                <div
                  key={study.id}
                  onClick={() => {
                    setSelectedStudyId(study.id);
                    setCurrentSlice(Math.ceil(study.totalSlices / 2));
                    handleResetViewer();
                  }}
                  className={`p-2.5 rounded cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-blue-600/15 border border-blue-500/40 text-white'
                      : 'hover:bg-slate-800/60 text-slate-300 border border-transparent'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <div className="font-semibold text-xs text-white truncate flex items-center gap-1.5">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-cyan-300 border border-slate-700">
                        {study.modality}
                      </span>
                      <span className="truncate">{study.patientName}</span>
                    </div>
                    {study.priority === 'STAT' ? (
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-rose-950 text-rose-300 border border-rose-600 animate-pulse">
                        STAT
                      </span>
                    ) : (
                      <span className={`px-1.5 py-0.5 rounded text-[9px] font-medium ${
                        study.status === 'Completed' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                        study.status === 'In Review' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                        'bg-slate-800 text-slate-300 border border-slate-700'
                      }`}>
                        {study.status}
                      </span>
                    )}
                  </div>

                  <div className="text-[11px] text-slate-300 font-medium mb-1 truncate">
                    {study.bodyPart}
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-400">
                    <span>{study.accessionNumber}</span>
                    <span>{study.studyDate.split(' ')[0]}</span>
                  </div>
                </div>
              );
            })}
            {filteredStudies.length === 0 && (
              <div className="text-center py-8 text-xs text-slate-500">
                No imaging studies match criteria.
              </div>
            )}
          </div>
        </div>

        {/* Right Column: High-Precision PACS Viewer & Diagnostic Report */}
        <div className="flex-1 flex flex-col min-h-0 bg-black">
          {/* Top Viewer Toolbar */}
          <div className="bg-slate-900 border-b border-slate-800 px-4 py-2 flex flex-wrap items-center justify-between gap-2 shrink-0">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-white">
                {currentStudy.modality} - {currentStudy.bodyPart}
              </span>
              <span className="text-[11px] text-slate-400">
                ({currentStudy.accessionNumber})
              </span>
            </div>

            {/* Viewer Controls */}
            <div className="flex items-center gap-1.5">
              {/* Presets */}
              <div className="flex items-center bg-slate-800 rounded p-0.5 border border-slate-700 text-[11px]">
                <button
                  onClick={() => applyPreset('standard')}
                  className={`px-2 py-0.5 rounded ${windowPreset === 'standard' ? 'bg-blue-600 text-white font-semibold' : 'text-slate-300 hover:text-white'}`}
                  title="Standard Radiographic Preset"
                >
                  Standard
                </button>
                <button
                  onClick={() => applyPreset('bone')}
                  className={`px-2 py-0.5 rounded ${windowPreset === 'bone' ? 'bg-blue-600 text-white font-semibold' : 'text-slate-300 hover:text-white'}`}
                  title="Bone Window (High contrast cortical detail)"
                >
                  Bone
                </button>
                <button
                  onClick={() => applyPreset('lung')}
                  className={`px-2 py-0.5 rounded ${windowPreset === 'lung' ? 'bg-blue-600 text-white font-semibold' : 'text-slate-300 hover:text-white'}`}
                  title="Lung Window (Pulmonary parenchymal detail)"
                >
                  Lung
                </button>
                <button
                  onClick={() => applyPreset('brain')}
                  className={`px-2 py-0.5 rounded ${windowPreset === 'brain' ? 'bg-blue-600 text-white font-semibold' : 'text-slate-300 hover:text-white'}`}
                  title="Brain Window (Gray/White differentiation)"
                >
                  Brain
                </button>
              </div>

              {/* Invert */}
              <button
                onClick={() => setInvertGrayscale(!invertGrayscale)}
                className={`p-1.5 rounded border text-xs ${invertGrayscale ? 'bg-amber-600 text-white border-amber-500' : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'}`}
                title="Invert Grayscale (Negative/Positive)"
              >
                <Sliders className="w-3.5 h-3.5" />
              </button>

              {/* Zoom Out / Zoom In */}
              <div className="flex items-center bg-slate-800 rounded border border-slate-700">
                <button
                  onClick={() => setZoomLevel(prev => Math.max(50, prev - 25))}
                  className="p-1.5 text-slate-300 hover:text-white"
                  title="Zoom Out"
                >
                  <ZoomOut className="w-3.5 h-3.5" />
                </button>
                <span className="text-[10px] px-1 text-slate-300 font-mono">{zoomLevel}%</span>
                <button
                  onClick={() => setZoomLevel(prev => Math.min(300, prev + 25))}
                  className="p-1.5 text-slate-300 hover:text-white"
                  title="Zoom In"
                >
                  <ZoomIn className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Reset */}
              <button
                onClick={handleResetViewer}
                className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded"
                title="Reset Image Geometry"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>

              {/* Measure Tool */}
              <button
                onClick={() => setMeasureToolActive(!measureToolActive)}
                className={`px-2 py-1 rounded border text-[11px] flex items-center gap-1 ${
                  measureToolActive ? 'bg-emerald-600 text-white border-emerald-500' : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'
                }`}
                title="Toggle Electronic Calipers"
              >
                <Activity className="w-3 h-3" />
                Caliper
              </button>
            </div>
          </div>

          {/* Viewer Stage and Report Split */}
          <div className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden">
            {/* Left/Center: High-Tech Medical Display Canvas */}
            <div className="flex-1 bg-black relative flex flex-col justify-center items-center overflow-hidden select-none border-b lg:border-b-0 lg:border-r border-slate-800">
              {/* Medical Image Canvas (Radiograph simulation) */}
              <div
                className="relative flex items-center justify-center transition-transform duration-100 ease-out"
                style={{
                  transform: `scale(${zoomLevel / 100})`,
                  filter: `brightness(${brightness}%) contrast(${contrast}%) ${invertGrayscale ? 'invert(1)' : ''}`,
                }}
              >
                {/* Visual Medical Radiographic Renderer */}
                <div className="w-[380px] h-[380px] sm:w-[440px] sm:h-[440px] bg-slate-950 rounded-lg shadow-2xl relative overflow-hidden border border-slate-800/80 flex items-center justify-center">
                  {/* Subtle Grid Backdrop */}
                  <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-20 pointer-events-none" />

                  {/* Radiographic Anatomical Schematics according to modality */}
                  {currentStudy.modality === 'X-Ray' && (
                    <svg viewBox="0 0 400 400" className="w-full h-full text-slate-200">
                      {/* Thoracic rib cage */}
                      <g fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" opacity="0.85">
                        {/* Spine column */}
                        <line x1="200" y1="40" x2="200" y2="360" strokeWidth="10" strokeDasharray="14 4" opacity="0.5" />
                        {/* Clavicles */}
                        <path d="M 120 70 Q 160 85 200 80 Q 240 85 280 70" strokeWidth="6" />
                        {/* Rib pairs */}
                        <path d="M 200 90 C 130 95 100 130 110 170" />
                        <path d="M 200 90 C 270 95 300 130 290 170" />
                        <path d="M 200 115 C 120 120 85 160 100 210" />
                        <path d="M 200 115 C 280 120 315 160 300 210" />
                        <path d="M 200 145 C 110 150 75 200 90 250" />
                        <path d="M 200 145 C 290 150 325 200 310 250" />
                        <path d="M 200 180 C 105 185 70 240 85 290" />
                        <path d="M 200 180 C 295 185 330 240 315 290" />
                        <path d="M 200 220 C 100 225 70 280 90 330" />
                        <path d="M 200 220 C 300 225 330 280 310 330" />
                      </g>
                      {/* Cardiac Silhouette */}
                      <path
                        d="M 195 160 C 170 190 150 240 180 290 C 205 310 250 300 255 250 C 260 210 240 170 200 160 Z"
                        fill="white"
                        opacity="0.45"
                      />
                      {/* Bilateral Hemidiaphragms */}
                      <path
                        d="M 60 330 Q 130 280 200 310 Q 270 280 340 330"
                        fill="none"
                        stroke="white"
                        strokeWidth="5"
                        opacity="0.7"
                      />
                    </svg>
                  )}

                  {currentStudy.modality === 'CT' && (
                    <svg viewBox="0 0 400 400" className="w-full h-full text-slate-200">
                      {/* Calvarium skull ring */}
                      <ellipse cx="200" cy="200" rx="140" ry="160" fill="none" stroke="white" strokeWidth="8" opacity="0.9" />
                      {/* Brain parenchyma background */}
                      <ellipse cx="200" cy="200" rx="134" ry="154" fill="#334155" opacity="0.75" />
                      {/* Interhemispheric fissure */}
                      <line x1="200" y1="50" x2="200" y2="350" stroke="#0f172a" strokeWidth="3" opacity="0.9" />
                      {/* Lateral Ventricles (dynamic based on slice) */}
                      <path
                        d={`M 185 160 Q 165 ${190 + (currentSlice - 8) * 3} 180 ${230} Q 195 210 195 160 Z`}
                        fill="#020617"
                      />
                      <path
                        d={`M 215 160 Q 235 ${190 + (currentSlice - 8) * 3} 220 ${230} Q 205 210 215 160 Z`}
                        fill="#020617"
                      />
                      {/* Subarachnoid Sulcal markings */}
                      <g fill="none" stroke="#0f172a" strokeWidth="2" opacity="0.6">
                        <path d="M 120 120 Q 140 140 110 160" />
                        <path d="M 280 120 Q 260 140 290 160" />
                        <path d="M 90 200 Q 120 210 100 240" />
                        <path d="M 310 200 Q 280 210 300 240" />
                      </g>
                      {/* Subtle MCA ischemic zone marker on slice 8-10 */}
                      {currentStudy.criticalFinding && currentSlice >= 7 && currentSlice <= 10 && (
                        <circle cx="130" cy="180" r="18" fill="#475569" opacity="0.5" stroke="#ef4444" strokeWidth="1" strokeDasharray="3 3" />
                      )}
                    </svg>
                  )}

                  {currentStudy.modality === 'MRI' && (
                    <svg viewBox="0 0 400 400" className="w-full h-full text-slate-200">
                      {/* Sagittal Spine Vertebral Bodies */}
                      <g fill="#475569" stroke="#94a3b8" strokeWidth="1.5">
                        <rect x="180" y="60" width="45" height="30" rx="3" />
                        <rect x="180" y="105" width="46" height="32" rx="3" />
                        <rect x="178" y="152" width="48" height="34" rx="3" />
                        <rect x="175" y="202" width="50" height="36" rx="3" />
                        <rect x="170" y="254" width="52" height="38" rx="3" />
                        {/* Sacrum */}
                        <polygon points="168,305 220,305 205,370 180,370" fill="#334155" />
                      </g>
                      {/* Intervertebral Discs */}
                      <rect x="182" y="92" width="42" height="11" rx="2" fill="#1e293b" />
                      <rect x="180" y="139" width="44" height="11" rx="2" fill="#1e293b" />
                      <rect x="177" y="188" width="46" height="12" rx="2" fill="#1e293b" />
                      {/* Herniated L4-L5 Disc */}
                      <path d="M 174 240 L 222 240 L 235 247 L 222 252 L 172 252 Z" fill="#38bdf8" opacity="0.8" />
                      {/* Spinal Cord / Thecal Sac Canal */}
                      <path d="M 230 40 Q 235 200 230 360" stroke="#cbd5e1" strokeWidth="12" fill="none" opacity="0.6" />
                    </svg>
                  )}

                  {currentStudy.modality === 'Ultrasound' && (
                    <svg viewBox="0 0 400 400" className="w-full h-full">
                      {/* Pie-shaped acoustic sector field */}
                      <path
                        d="M 200 30 L 370 370 A 240 240 0 0 1 30 370 Z"
                        fill="#0f172a"
                        stroke="#334155"
                        strokeWidth="2"
                      />
                      {/* Liver acoustic texture speckle */}
                      <ellipse cx="200" cy="220" rx="90" ry="70" fill="#1e293b" opacity="0.8" />
                      {/* Gallbladder anechoic fluid cavity */}
                      <ellipse cx="200" cy="230" rx="40" ry="25" fill="#000000" stroke="#475569" strokeWidth="2" />
                      {/* Gallstones with acoustic shadow */}
                      <circle cx="190" cy="230" r="6" fill="#f8fafc" />
                      <path d="M 184 236 L 180 340 L 200 340 L 196 236 Z" fill="#020617" opacity="0.85" />
                    </svg>
                  )}

                  {/* Active Caliper Measurement Overlay */}
                  {measureToolActive && (
                    <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                      <div className="relative w-48 h-0 border-t-2 border-emerald-400 border-dashed">
                        <span className="absolute -top-3 left-0 w-2 h-2 rounded-full bg-emerald-400" />
                        <span className="absolute -top-3 right-0 w-2 h-2 rounded-full bg-emerald-400" />
                        <span className="absolute -top-5 left-1/2 -translate-x-1/2 bg-emerald-950/90 text-emerald-300 border border-emerald-500 text-[10px] px-1.5 py-0.2 rounded font-mono">
                          Dist: 34.2 mm
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* DICOM Professional Top-Left Watermark Overlay */}
              <div className="absolute top-3 left-3 pointer-events-none text-left font-mono text-[10px] text-emerald-400/90 leading-tight space-y-0.5 bg-black/60 p-2 rounded border border-emerald-500/20 backdrop-blur-xs">
                <div className="font-bold text-white uppercase">{currentStudy.patientName}</div>
                <div>ID: {currentStudy.patientId} | {currentStudy.patientGender}/{currentStudy.patientAge}y</div>
                <div>ACC: {currentStudy.accessionNumber}</div>
                <div className="text-slate-300">{currentStudy.studyDate}</div>
              </div>

              {/* DICOM Top-Right Parameters */}
              <div className="absolute top-3 right-3 pointer-events-none text-right font-mono text-[10px] text-cyan-400/90 leading-tight space-y-0.5 bg-black/60 p-2 rounded border border-cyan-500/20 backdrop-blur-xs">
                <div className="font-bold text-white">METRO GENERAL RADIOLOGY</div>
                <div>{currentStudy.modality} / {currentStudy.bodyPart.split(' ')[0]}</div>
                <div>Dose: {currentStudy.radiationDose || 'N/A'}</div>
                <div>W:{contrast * 4} / C:{brightness * 2}</div>
              </div>

              {/* DICOM Bottom-Right Slice Info & Scrubber */}
              {currentStudy.totalSlices > 1 && (
                <div className="absolute bottom-3 inset-x-4 flex items-center justify-between bg-slate-950/80 p-2 rounded border border-slate-800 text-xs">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setCurrentSlice(prev => Math.max(1, prev - 1))}
                      disabled={currentSlice <= 1}
                      className="p-1 hover:bg-slate-800 rounded disabled:opacity-30 text-slate-300"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <span className="font-mono text-emerald-400 text-xs">
                      Slice {currentSlice} / {currentStudy.totalSlices} (Axial {currentSlice * 1.5}mm)
                    </span>
                    <button
                      onClick={() => setCurrentSlice(prev => Math.min(currentStudy.totalSlices, prev + 1))}
                      disabled={currentSlice >= currentStudy.totalSlices}
                      className="p-1 hover:bg-slate-800 rounded disabled:opacity-30 text-slate-300"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>

                  <input
                    type="range"
                    min={1}
                    max={currentStudy.totalSlices}
                    value={currentSlice}
                    onChange={(e) => setCurrentSlice(parseInt(e.target.value))}
                    className="w-48 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                  />
                </div>
              )}
            </div>

            {/* Right/Bottom: Structured Radiologist Diagnostic Report (Width: 380px) */}
            <div className="w-full lg:w-[420px] bg-slate-900 border-l border-slate-800 flex flex-col min-h-0">
              {/* Report Header */}
              <div className="p-3 border-b border-slate-800 bg-slate-950/40 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-blue-400" />
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    Diagnostic Imaging Report
                  </span>
                </div>
                {currentStudy.signedOff ? (
                  <span className="flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    <CheckCircle2 className="w-3 h-3" /> Signed & Finalized
                  </span>
                ) : (
                  <span className="flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                    <Clock className="w-3 h-3" /> Preliminary Draft
                  </span>
                )}
              </div>

              {/* Report Content Details */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3.5 text-xs text-slate-300">
                {/* Critical Finding Callout if present */}
                {currentStudy.criticalFinding && (
                  <div className="p-2.5 rounded bg-rose-950/70 border border-rose-600/60 text-rose-200">
                    <div className="flex items-center gap-1.5 font-bold text-rose-400 text-xs mb-1">
                      <AlertTriangle className="w-4 h-4" />
                      CRITICAL FINDING COMMUNICATED
                    </div>
                    <p className="text-[11px] leading-relaxed">
                      Urgent acute finding identified. Radiologist verbal notification relayed to ordering physician per hospital emergency protocol.
                    </p>
                  </div>
                )}

                {/* Patient / Exam Meta Info Box */}
                <div className="bg-slate-950/60 p-3 rounded border border-slate-800 space-y-1 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Patient:</span>
                    <span className="font-semibold text-white">{currentStudy.patientName} (MRN: {currentStudy.patientId})</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Ordering MD:</span>
                    <span className="text-slate-200">{currentStudy.orderingPhysician}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Radiologist:</span>
                    <span className="text-slate-200">{currentStudy.radiologist}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Acquisition:</span>
                    <span className="text-slate-200">{currentStudy.studyDate}</span>
                  </div>
                </div>

                {/* Clinical Indication */}
                <div>
                  <div className="font-bold text-slate-200 text-xs mb-1 uppercase tracking-wide">
                    Clinical Indication
                  </div>
                  <p className="text-slate-400 text-xs leading-relaxed bg-slate-950/40 p-2 rounded border border-slate-800/60">
                    {currentStudy.clinicalIndication}
                  </p>
                </div>

                {/* Examination Technique */}
                <div>
                  <div className="font-bold text-slate-200 text-xs mb-1 uppercase tracking-wide">
                    Technique & Protocol
                  </div>
                  <p className="text-slate-400 text-xs leading-relaxed">
                    {currentStudy.technique}
                  </p>
                </div>

                {/* Findings Section */}
                <div>
                  <div className="font-bold text-slate-200 text-xs mb-1 uppercase tracking-wide">
                    Radiological Findings
                  </div>
                  <p className="text-slate-300 text-xs leading-relaxed bg-slate-950/30 p-2.5 rounded border border-slate-800 whitespace-pre-line font-sans">
                    {currentStudy.findings}
                  </p>
                </div>

                {/* Impression Section */}
                <div>
                  <div className="font-bold text-amber-400 text-xs mb-1 uppercase tracking-wide flex items-center gap-1">
                    <FileCheck className="w-3.5 h-3.5" />
                    Impression & Conclusions
                  </div>
                  <div className="text-white text-xs leading-relaxed bg-blue-950/30 p-2.5 rounded border border-blue-800/40 whitespace-pre-line font-medium">
                    {currentStudy.impression}
                  </div>
                </div>

                {/* Addenda if present */}
                {currentStudy.addenda && currentStudy.addenda.length > 0 && (
                  <div>
                    <div className="font-bold text-slate-300 text-xs mb-1 uppercase tracking-wide">
                      Clinical Addendum Log
                    </div>
                    {currentStudy.addenda.map((addendum, idx) => (
                      <div key={idx} className="p-2 rounded bg-slate-950/70 border border-slate-800 text-[11px] text-slate-300 mb-1">
                        {addendum}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Report Action Footer */}
              <div className="p-3 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between shrink-0 gap-2">
                <button
                  onClick={() => {
                    setSelectedPatientId(currentStudy.patientId);
                    setActiveTab('patients');
                  }}
                  className="px-2.5 py-1.5 text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1 font-medium"
                >
                  <User className="w-3.5 h-3.5" />
                  View Patient EMR
                </button>

                {!currentStudy.signedOff && (
                  <button
                    onClick={() => handleSignOffReport(currentStudy.id)}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-semibold flex items-center gap-1.5 shadow transition-colors"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Sign & Finalize Report
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Order New Imaging Study Modal */}
      {showOrderModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-lg shadow-2xl w-full max-w-lg overflow-hidden text-slate-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="px-5 py-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Scan className="w-5 h-5 text-blue-400" />
                <h2 className="text-sm font-bold text-white">Order Diagnostic Imaging / PACS Study</h2>
              </div>
              <button
                onClick={() => setShowOrderModal(false)}
                className="text-slate-400 hover:text-white text-lg font-bold"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleCreateOrder} className="p-5 space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Select Patient</label>
                <select
                  value={newOrder.patientId}
                  onChange={(e) => setNewOrder({ ...newOrder, patientId: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                  required
                >
                  {patients.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.firstName} {p.lastName} (MRN: {p.id}, Age: {p.age}, {p.bloodGroup})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Modality</label>
                  <select
                    value={newOrder.modality}
                    onChange={(e) => setNewOrder({ ...newOrder, modality: e.target.value as ImagingStudy['modality'] })}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="CT">CT (Computed Tomography)</option>
                    <option value="MRI">MRI (Magnetic Resonance)</option>
                    <option value="X-Ray">X-Ray (Plain Radiography)</option>
                    <option value="Ultrasound">Ultrasound / Sonography</option>
                    <option value="Mammography">Mammography</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Priority</label>
                  <select
                    value={newOrder.priority}
                    onChange={(e) => setNewOrder({ ...newOrder, priority: e.target.value as ImagingStudy['priority'] })}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="Routine">Routine Elective</option>
                    <option value="Urgent">Urgent (Within 4 Hours)</option>
                    <option value="STAT">STAT Emergency (Immediate)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Anatomical Region / Examination Title</label>
                <input
                  type="text"
                  value={newOrder.bodyPart}
                  onChange={(e) => setNewOrder({ ...newOrder, bodyPart: e.target.value })}
                  placeholder="e.g. Chest 2-View, Abdomen & Pelvis with IV Contrast, Brain CTA"
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Clinical Indication / Reason for Exam</label>
                <textarea
                  rows={2}
                  value={newOrder.clinicalIndication}
                  onChange={(e) => setNewOrder({ ...newOrder, clinicalIndication: e.target.value })}
                  placeholder="Clinical history, symptoms, relevant labs, suspected pathology..."
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3 items-center">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Ordering Physician</label>
                  <select
                    value={newOrder.orderingPhysician}
                    onChange={(e) => setNewOrder({ ...newOrder, orderingPhysician: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                  >
                    {doctors.map(d => (
                      <option key={d.id} value={d.name}>{d.name} ({d.specialty})</option>
                    ))}
                  </select>
                </div>

                <div className="pt-5">
                  <label className="flex items-center gap-2 cursor-pointer text-slate-200">
                    <input
                      type="checkbox"
                      checked={newOrder.contrastUsed}
                      onChange={(e) => setNewOrder({ ...newOrder, contrastUsed: e.target.checked })}
                      className="w-4 h-4 rounded text-blue-600 bg-slate-800 border-slate-700"
                    />
                    <span>IV / Oral Contrast Required</span>
                  </label>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowOrderModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded text-slate-300 font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded font-semibold transition-colors shadow"
                >
                  Submit Order to PACS
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
