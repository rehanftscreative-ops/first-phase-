import React, { useState } from 'react';
import {
  Users,
  BedDouble,
  CreditCard,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  ChevronRight,
  PhoneCall,
  Activity,
  Plus,
  Search,
  CheckCircle2,
  AlertCircle,
  Stethoscope,
  Pill,
  FileCheck2,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';
import { AppointmentStatus } from '../types';

interface DashboardOverviewProps {
  onOpenNewPatient: () => void;
  onOpenNewAppointment: () => void;
  onOpenNewInvoice: () => void;
  onSelectPatient: (id: string) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  onOpenNewPatient,
  onOpenNewAppointment,
  onOpenNewInvoice,
  onSelectPatient,
}) => {
  const {
    patients,
    appointments,
    invoices,
    wardBeds,
    pharmacy,
    updateAppointmentStatus,
    setActiveTab,
    addNotification,
  } = useHospital();

  const [appointmentFilter, setAppointmentFilter] = useState<string>('all');
  const [calledPatientId, setCalledPatientId] = useState<string | null>(null);

  // High density calculations
  const totalPatientsCount = patients.length;
  const occupiedBedsCount = wardBeds.filter((b) => b.status === 'Occupied').length;
  const totalBedsCount = wardBeds.length;
  const bedOccupancyPercent = totalBedsCount > 0 ? Math.round((occupiedBedsCount / totalBedsCount) * 100) : 0;

  const pendingInvoices = invoices.filter((i) => i.status === 'Pending' || i.status === 'Partially Paid');
  const pendingAmount = pendingInvoices.reduce((sum, inv) => sum + inv.balanceDue, 0);
  const totalRevenueCollected = invoices.reduce((sum, inv) => sum + inv.amountPaid, 0);

  const lowStockMeds = pharmacy.filter((p) => p.stockQuantity <= p.minThreshold).length;

  const todayAppointments = appointments.filter((a) => {
    if (appointmentFilter === 'all') return true;
    if (appointmentFilter === 'active') return a.status === 'Checked-In' || a.status === 'In Consultation';
    return a.status.toLowerCase() === appointmentFilter.toLowerCase();
  });

  const handleCallPatient = (appointmentId: string, patientName: string, doctorName: string) => {
    setCalledPatientId(appointmentId);
    updateAppointmentStatus(appointmentId, 'In Consultation');
    addNotification(
      `Patient Summoned: ${patientName}`,
      `${patientName} is requested at Consultation Room with ${doctorName}.`,
      'info',
      appointmentId
    );
    setTimeout(() => {
      setCalledPatientId(null);
    }, 2500);
  };

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-7xl mx-auto">
      {/* Top High Density Metric Ribbon */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              Total Admissions
            </span>
            <div className="w-7 h-7 rounded bg-blue-50 text-blue-600 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-800">{totalPatientsCount}</span>
            <span className="text-xs font-semibold text-emerald-600 flex items-center">
              <ArrowUpRight className="w-3 h-3 mr-0.5" /> +12.4%
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            {patients.filter((p) => p.status === 'Inpatient').length} Active Inpatients | {patients.filter((p) => p.status === 'Emergency').length} In ER
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              Bed Occupancy
            </span>
            <div className="w-7 h-7 rounded bg-amber-50 text-amber-600 flex items-center justify-center">
              <BedDouble className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-800">{bedOccupancyPercent}%</span>
            <span className="text-xs font-semibold text-amber-600 flex items-center">
              {occupiedBedsCount}/{totalBedsCount} Units Occupied
            </span>
          </div>
          <div className="mt-2">
            <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
              <div
                className={`h-1.5 rounded-full transition-all duration-500 ${
                  bedOccupancyPercent > 80 ? 'bg-amber-500' : 'bg-emerald-500'
                }`}
                style={{ width: `${bedOccupancyPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              Pending Bills & Claims
            </span>
            <div className="w-7 h-7 rounded bg-purple-50 text-purple-600 flex items-center justify-center">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-800 font-mono">
              ${pendingAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className="text-xs font-semibold text-rose-600 flex items-center">
              {pendingInvoices.length} Unsettled
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            ${totalRevenueCollected.toLocaleString('en-US', { minimumFractionDigits: 2 })} collected this cycle
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              Pharmacy & Diagnostics
            </span>
            <div className="w-7 h-7 rounded bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Pill className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-800">
              {lowStockMeds > 0 ? `${lowStockMeds} Alerts` : 'Optimal'}
            </span>
            <span
              className={`text-xs font-semibold flex items-center ${
                lowStockMeds > 0 ? 'text-amber-600' : 'text-emerald-600'
              }`}
            >
              {lowStockMeds > 0 ? 'Requires Restock' : 'All Stock Sane'}
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            Avg ER Handover: 12m | Lab turn-around: 48m
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left 2 Cols: Real-Time Appointment & Triage Queue */}
        <div className="lg:col-span-2 bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden flex flex-col">
          {/* Header & Filter Tabs */}
          <div className="p-3.5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 bg-slate-50/50">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-blue-600" />
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                Live Appointment & Triage Queue
              </h2>
              <span className="text-[10px] bg-blue-100 text-blue-800 font-mono font-bold px-1.5 py-0.5 rounded">
                {todayAppointments.length} Total
              </span>
            </div>

            {/* Status Filters */}
            <div className="flex items-center gap-1">
              {[
                { id: 'all', label: 'All' },
                { id: 'active', label: 'In Clinic' },
                { id: 'Checked-In', label: 'Checked In' },
                { id: 'Scheduled', label: 'Scheduled' },
              ].map((filter) => (
                <button
                  key={filter.id}
                  onClick={() => setAppointmentFilter(filter.id)}
                  className={`px-2 py-1 text-[11px] rounded font-medium transition ${
                    appointmentFilter === filter.id
                      ? 'bg-blue-600 text-white font-semibold'
                      : 'text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {filter.label}
                </button>
              ))}
              <button
                onClick={onOpenNewAppointment}
                className="ml-1 px-2.5 py-1 text-[11px] bg-blue-50 border border-blue-200 hover:bg-blue-100 text-blue-700 font-semibold rounded flex items-center gap-1"
              >
                <Plus className="w-3 h-3" /> Book Slot
              </button>
            </div>
          </div>

          {/* Table Container */}
          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-100/75 text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                  <th className="py-2.5 px-3">Slot / Wait</th>
                  <th className="py-2.5 px-3">Patient</th>
                  <th className="py-2.5 px-3">Physician</th>
                  <th className="py-2.5 px-3">Priority</th>
                  <th className="py-2.5 px-3">Queue Status</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-normal">
                {todayAppointments.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-400">
                      No appointments matching current status filter.
                    </td>
                  </tr>
                ) : (
                  todayAppointments.map((appt) => {
                    const isCalled = calledPatientId === appt.id;
                    return (
                      <tr
                        key={appt.id}
                        className={`hover:bg-slate-50/80 transition-colors ${
                          isCalled ? 'bg-blue-50/60' : ''
                        }`}
                      >
                        <td className="py-2.5 px-3 whitespace-nowrap font-mono text-slate-700 font-medium">
                          <div>{appt.timeSlot}</div>
                          <span className="text-[10px] text-slate-400">
                            Est. {appt.estimatedWaitMinutes || 10}m
                          </span>
                        </td>
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          <button
                            onClick={() => onSelectPatient(appt.patientId)}
                            className="text-left group"
                          >
                            <span className="font-semibold text-slate-800 group-hover:text-blue-600 block">
                              {appt.patientName}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {appt.patientId} • {appt.patientAge}y {appt.patientGender}
                            </span>
                          </button>
                        </td>
                        <td className="py-2.5 px-3 whitespace-nowrap text-slate-600">
                          <div className="font-medium text-slate-800">{appt.doctorName}</div>
                          <div className="text-[10px] text-slate-400">{appt.department}</div>
                        </td>
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                              appt.priority === 'Emergency'
                                ? 'bg-red-100 text-red-700'
                                : appt.priority === 'Urgent'
                                ? 'bg-amber-100 text-amber-700'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {appt.priority}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          <span
                            className={`inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full font-medium ${
                              appt.status === 'In Consultation'
                                ? 'bg-blue-100 text-blue-700'
                                : appt.status === 'Checked-In'
                                ? 'bg-emerald-100 text-emerald-700'
                                : appt.status === 'Completed'
                                ? 'bg-slate-100 text-slate-500'
                                : 'bg-amber-100 text-amber-700'
                            }`}
                          >
                            <span
                              className={`w-1.5 h-1.5 rounded-full ${
                                appt.status === 'In Consultation'
                                  ? 'bg-blue-600 animate-pulse'
                                  : appt.status === 'Checked-In'
                                  ? 'bg-emerald-600'
                                  : appt.status === 'Completed'
                                  ? 'bg-slate-400'
                                  : 'bg-amber-600'
                              }`}
                            />
                            {appt.status}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 whitespace-nowrap text-right">
                          {appt.status === 'Checked-In' ? (
                            <button
                              onClick={() => handleCallPatient(appt.id, appt.patientName, appt.doctorName)}
                              className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded text-[11px] inline-flex items-center gap-1 shadow-2xs"
                            >
                              <PhoneCall className="w-3 h-3" /> Call In
                            </button>
                          ) : appt.status === 'Scheduled' ? (
                            <button
                              onClick={() => updateAppointmentStatus(appt.id, 'Checked-In')}
                              className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded text-[11px]"
                            >
                              Check-In
                            </button>
                          ) : appt.status === 'In Consultation' ? (
                            <button
                              onClick={() => updateAppointmentStatus(appt.id, 'Completed')}
                              className="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded text-[11px]"
                            >
                              Done
                            </button>
                          ) : (
                            <span className="text-[11px] text-slate-400">Archived</span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          <div className="p-2.5 bg-slate-50 border-t border-slate-200 flex justify-between items-center text-xs">
            <span className="text-slate-500 text-[11px]">
              Showing real-time appointments synchronized across clinic network.
            </span>
            <button
              onClick={() => setActiveTab('appointments')}
              className="text-blue-600 font-semibold hover:underline flex items-center gap-1 text-[11px]"
            >
              Full Scheduling Console <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Right Col: Quick Admission & Bed Unit Status */}
        <div className="space-y-4">
          {/* Quick Action Clinical Hub */}
          <div className="bg-white rounded-lg border border-slate-200 shadow-sm p-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 mb-3 flex items-center justify-between">
              <span>Rapid Clinical Intake</span>
              <Activity className="w-3.5 h-3.5 text-blue-600" />
            </h3>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={onOpenNewPatient}
                className="p-2.5 bg-blue-50/80 hover:bg-blue-100/80 border border-blue-200 rounded text-left transition"
              >
                <span className="block text-xs font-bold text-blue-900">+ Register Patient</span>
                <span className="text-[10px] text-blue-600">New EMR intake chart</span>
              </button>
              <button
                onClick={onOpenNewInvoice}
                className="p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded text-left transition"
              >
                <span className="block text-xs font-bold text-slate-800">Generate Invoice</span>
                <span className="text-[10px] text-slate-500">Itemize copay & claims</span>
              </button>
              <button
                onClick={() => setActiveTab('pharmacy')}
                className="p-2.5 bg-emerald-50/70 hover:bg-emerald-100/70 border border-emerald-200 rounded text-left transition"
              >
                <span className="block text-xs font-bold text-emerald-900">Dispense Rx</span>
                <span className="text-[10px] text-emerald-700">Check medicine stocks</span>
              </button>
              <button
                onClick={() => setActiveTab('labs')}
                className="p-2.5 bg-purple-50/70 hover:bg-purple-100/70 border border-purple-200 rounded text-left transition"
              >
                <span className="block text-xs font-bold text-purple-900">Diagnostics</span>
                <span className="text-[10px] text-purple-700">Verify lab specimens</span>
              </button>
            </div>
          </div>

          {/* Ward Bed Monitoring */}
          <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-3 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-2">
                <BedDouble className="w-4 h-4 text-blue-600" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                  Ward Bed Status
                </h3>
              </div>
              <button
                onClick={() => setActiveTab('wards')}
                className="text-[11px] text-blue-600 font-semibold hover:underline"
              >
                Manage Wards
              </button>
            </div>
            <div className="p-3 space-y-2 max-h-72 overflow-y-auto">
              {wardBeds.map((bed) => (
                <div
                  key={bed.id}
                  className="p-2 rounded border border-slate-100 bg-slate-50/50 flex items-center justify-between text-xs"
                >
                  <div className="min-w-0 pr-2">
                    <div className="font-semibold text-slate-800 text-[11px] truncate">
                      {bed.bedNumber} • <span className="font-normal text-slate-500">{bed.wardName}</span>
                    </div>
                    <div className="text-[10px] text-slate-500 truncate">
                      {bed.patientName ? `Assigned: ${bed.patientName}` : 'Sanitized & Ready'}
                    </div>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                      bed.status === 'Occupied'
                        ? 'bg-rose-100 text-rose-700'
                        : bed.status === 'Maintenance'
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-emerald-100 text-emerald-700'
                    }`}
                  >
                    {bed.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
