import React, { useState } from 'react';
import { HospitalProvider, useHospital } from './context/HospitalContext';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { DashboardOverview } from './components/DashboardOverview';
import { PatientsEMR } from './components/PatientsEMR';
import { AppointmentsManager } from './components/AppointmentsManager';
import { StaffManagement } from './components/StaffManagement';
import { BillingInvoicing } from './components/BillingInvoicing';
import { PharmacyInventory } from './components/PharmacyInventory';
import { LabDiagnostics } from './components/LabDiagnostics';
import { WardOccupancyView } from './components/WardOccupancyView';
import { ReportsAnalytics } from './components/ReportsAnalytics';
import { AdminCompliance } from './components/AdminCompliance';
import { FooterBar } from './components/FooterBar';
import { NewPatientModal } from './components/NewPatientModal';
import { NewAppointmentModal } from './components/NewAppointmentModal';
import { NewInvoiceModal } from './components/NewInvoiceModal';
import { PaymentModal } from './components/PaymentModal';
import { Invoice } from './types';

const MainLayout: React.FC = () => {
  const { activeTab, selectedPatient, setSelectedPatientId, setActiveTab } = useHospital();

  // Modal controls
  const [isNewPatientOpen, setIsNewPatientOpen] = useState(false);
  const [isNewAppointmentOpen, setIsNewAppointmentOpen] = useState(false);
  const [isNewInvoiceOpen, setIsNewInvoiceOpen] = useState(false);
  const [payingInvoice, setPayingInvoice] = useState<Invoice | null>(null);

  const handleSelectPatient = (id: string | null) => {
    setSelectedPatientId(id);
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-slate-100 font-sans text-slate-800 antialiased">
      {/* High-Density Header Bar */}
      <Header
        onOpenNewPatient={() => setIsNewPatientOpen(true)}
        onOpenNewAppointment={() => setIsNewAppointmentOpen(true)}
        onOpenNewInvoice={() => setIsNewInvoiceOpen(true)}
        onSelectPatient={(id) => handleSelectPatient(id)}
      />

      {/* Center Layout: Sidebar + Active View */}
      <div className="flex flex-1 min-h-0 overflow-hidden">
        {/* Dark High-Density Sidebar */}
        <Sidebar />

        {/* Scrollable Main Operations Area */}
        <main className="flex-1 overflow-y-auto bg-slate-100/90 relative">
          {activeTab === 'overview' && (
            <DashboardOverview
              onOpenNewPatient={() => setIsNewPatientOpen(true)}
              onOpenNewAppointment={() => setIsNewAppointmentOpen(true)}
              onOpenNewInvoice={() => setIsNewInvoiceOpen(true)}
              onSelectPatient={(id) => handleSelectPatient(id)}
            />
          )}

          {activeTab === 'patients' && (
            <PatientsEMR onOpenNewPatient={() => setIsNewPatientOpen(true)} />
          )}

          {activeTab === 'appointments' && (
            <AppointmentsManager
              onOpenNewAppointment={() => setIsNewAppointmentOpen(true)}
              onSelectPatient={(id) => {
                handleSelectPatient(id);
                setActiveTab('patients');
              }}
            />
          )}

          {activeTab === 'staff' && (
            <StaffManagement />
          )}

          {activeTab === 'billing' && (
            <BillingInvoicing
              onOpenNewInvoice={() => setIsNewInvoiceOpen(true)}
              onSelectPatient={(id) => {
                handleSelectPatient(id);
                setActiveTab('patients');
              }}
            />
          )}

          {activeTab === 'pharmacy' && (
            <PharmacyInventory />
          )}

          {activeTab === 'labs' && (
            <LabDiagnostics />
          )}

          {activeTab === 'wards' && (
            <WardOccupancyView
              onSelectPatient={(id) => {
                handleSelectPatient(id);
                setActiveTab('patients');
              }}
            />
          )}

          {activeTab === 'reports' && (
            <ReportsAnalytics />
          )}

          {activeTab === 'admin' && (
            <AdminCompliance />
          )}
        </main>
      </div>

      {/* High-Density Status Footer */}
      <FooterBar />

      {/* Modals */}
      <NewPatientModal
        isOpen={isNewPatientOpen}
        onClose={() => setIsNewPatientOpen(false)}
        onPatientCreated={(id) => {
          handleSelectPatient(id);
          setActiveTab('patients');
        }}
      />

      <NewAppointmentModal
        isOpen={isNewAppointmentOpen}
        onClose={() => setIsNewAppointmentOpen(false)}
      />

      <NewInvoiceModal
        isOpen={isNewInvoiceOpen}
        onClose={() => setIsNewInvoiceOpen(false)}
      />

      <PaymentModal
        isOpen={!!payingInvoice}
        invoice={payingInvoice}
        onClose={() => setPayingInvoice(null)}
      />
    </div>
  );
};

export default function App() {
  return (
    <HospitalProvider>
      <MainLayout />
    </HospitalProvider>
  );
}
