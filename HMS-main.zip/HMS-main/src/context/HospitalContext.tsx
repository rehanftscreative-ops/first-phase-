import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Patient,
  Doctor,
  Appointment,
  Invoice,
  WardBed,
  LiveNotification,
  AppointmentStatus,
  Vitals,
  Medication,
  ClinicalNote,
  LabResult,
  PaymentTransaction,
  PaymentMethod,
  UserRole,
  StaffMember,
  PharmacyItem,
  AuditLog,
  SystemCompliance,
  PatientDiagnosis,
  FacilityVisit,
} from '../types';
import {
  initialPatients,
  initialDoctors,
  initialAppointments,
  initialInvoices,
  initialWardBeds,
  initialStaff,
  initialPharmacy,
  initialAuditLogs,
  initialCompliance,
} from '../mockData';

export type NavigationTab =
  | 'overview'
  | 'patients'
  | 'appointments'
  | 'billing'
  | 'pharmacy'
  | 'labs'
  | 'staff'
  | 'wards'
  | 'reports'
  | 'admin';

interface HospitalContextType {
  patients: Patient[];
  doctors: Doctor[];
  appointments: Appointment[];
  invoices: Invoice[];
  wardBeds: WardBed[];
  staff: StaffMember[];
  pharmacy: PharmacyItem[];
  auditLogs: AuditLog[];
  compliance: SystemCompliance;
  notifications: LiveNotification[];
  selectedPatient: Patient | null;
  activeTab: NavigationTab;
  currentRole: UserRole;
  currentUser: StaffMember;
  setCurrentRole: (role: UserRole) => void;
  setActiveTab: (tab: NavigationTab) => void;
  setSelectedPatientId: (id: string | null) => void;
  // Patient Actions
  addPatient: (patientData: Omit<Patient, 'id' | 'createdAt' | 'updatedAt' | 'vitals' | 'medications' | 'labResults' | 'clinicalNotes'>) => Patient;
  updatePatient: (id: string, updates: Partial<Patient>) => void;
  addVitals: (patientId: string, vitals: Omit<Vitals, 'recordedAt'>) => void;
  addMedication: (patientId: string, medication: Omit<Medication, 'id'>) => void;
  addClinicalNote: (patientId: string, note: Omit<ClinicalNote, 'id' | 'date'>) => void;
  addLabResult: (patientId: string, lab: Omit<LabResult, 'id'>) => void;
  updateLabResult: (patientId: string, labId: string, updates: Partial<LabResult>) => void;
  dischargePatient: (patientId: string) => void;
  // Appointment Actions
  bookAppointment: (aptData: Omit<Appointment, 'id' | 'queueNumber' | 'createdAt'>) => Appointment;
  updateAppointmentStatus: (aptId: string, status: AppointmentStatus) => void;
  callNextAppointment: (doctorId?: string) => void;
  // Billing Actions
  createInvoice: (invData: Omit<Invoice, 'id' | 'subtotal' | 'patientPayable' | 'amountPaid' | 'balanceDue' | 'transactions'>) => Invoice;
  processPayment: (invoiceId: string, paymentData: { amount: number; method: PaymentMethod; cardLast4?: string }) => Promise<{ success: boolean; transaction: PaymentTransaction }>;
  // Ward Actions
  assignBedToPatient: (bedId: string, patientId: string) => void;
  releaseBed: (bedId: string) => void;
  // Staff Actions
  addStaff: (member: Omit<StaffMember, 'id'>) => void;
  updateStaff: (id: string, updates: Partial<StaffMember>) => void;
  // Pharmacy Actions
  dispensePharmacyItem: (itemId: string, quantity: number, patientId: string) => void;
  restockPharmacyItem: (itemId: string, quantity: number) => void;
  addPharmacyItem: (item: Omit<PharmacyItem, 'id'>) => void;
  // Compliance & Audit
  logAuditEvent: (
    action: AuditLog['action'],
    resourceType: AuditLog['resourceType'],
    resourceId: string,
    details: string,
    complianceFlag?: AuditLog['complianceFlag']
  ) => void;
  updateCompliance: (updates: Partial<SystemCompliance>) => void;
  // Notifications
  markNotificationRead: (id: string) => void;
  clearAllNotifications: () => void;
  addNotification: (title: string, message: string, type?: LiveNotification['type'], relatedEntityId?: string) => void;
  // Utilities
  resetHospitalData: () => void;
}

const HospitalContext = createContext<HospitalContextType | undefined>(undefined);

const STORAGE_KEYS = {
  PATIENTS: 'medcore_patients_v2',
  DOCTORS: 'medcore_doctors_v2',
  APPOINTMENTS: 'medcore_appointments_v2',
  INVOICES: 'medcore_invoices_v2',
  WARD_BEDS: 'medcore_ward_beds_v2',
  STAFF: 'medcore_staff_v2',
  PHARMACY: 'medcore_pharmacy_v2',
  AUDIT_LOGS: 'medcore_audit_logs_v2',
  COMPLIANCE: 'medcore_compliance_v2',
  NOTIFICATIONS: 'medcore_notifications_v2',
  ROLE: 'medcore_current_role_v2',
};

export const HospitalProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [patients, setPatients] = useState<Patient[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PATIENTS);
    return saved ? JSON.parse(saved) : initialPatients;
  });

  const [doctors, setDoctors] = useState<Doctor[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.DOCTORS);
    return saved ? JSON.parse(saved) : initialDoctors;
  });

  const [appointments, setAppointments] = useState<Appointment[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.APPOINTMENTS);
    return saved ? JSON.parse(saved) : initialAppointments;
  });

  const [invoices, setInvoices] = useState<Invoice[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.INVOICES);
    return saved ? JSON.parse(saved) : initialInvoices;
  });

  const [wardBeds, setWardBeds] = useState<WardBed[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.WARD_BEDS);
    return saved ? JSON.parse(saved) : initialWardBeds;
  });

  const [staff, setStaff] = useState<StaffMember[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.STAFF);
    return saved ? JSON.parse(saved) : initialStaff;
  });

  const [pharmacy, setPharmacy] = useState<PharmacyItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PHARMACY);
    return saved ? JSON.parse(saved) : initialPharmacy;
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
    return saved ? JSON.parse(saved) : initialAuditLogs;
  });

  const [compliance, setCompliance] = useState<SystemCompliance>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.COMPLIANCE);
    return saved ? JSON.parse(saved) : initialCompliance;
  });

  const [currentRole, setCurrentRoleState] = useState<UserRole>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ROLE);
    return (saved as UserRole) || 'admin';
  });

  const [notifications, setNotifications] = useState<LiveNotification[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'NOTIF-1',
        title: 'Emergency Admission',
        message: 'Patient Amara Okonkwo admitted to ER Triage Bay 2 with acute RLQ abdominal pain.',
        type: 'critical',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        read: false,
        relatedEntityId: 'PT-10494',
      },
      {
        id: 'NOTIF-2',
        title: 'Low Pharmacy Inventory Alert',
        message: 'Metformin HCl 850mg stock (28 units) fell below minimum safe threshold (75 units).',
        type: 'warning',
        timestamp: new Date(Date.now() - 1000 * 60 * 10).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        read: false,
        relatedEntityId: 'PHARM-02',
      },
      {
        id: 'NOTIF-3',
        title: 'Live Appointment Queue',
        message: 'Dr. Sarah Jenkins has started consultation with Eleanor Pemberton.',
        type: 'info',
        timestamp: new Date(Date.now() - 1000 * 60 * 20).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        read: false,
        relatedEntityId: 'APT-2026-001',
      },
    ];
  });

  const [activeTab, setActiveTab] = useState<NavigationTab>('overview');
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(null);

  // Sync state to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PATIENTS, JSON.stringify(patients));
  }, [patients]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.DOCTORS, JSON.stringify(doctors));
  }, [doctors]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.APPOINTMENTS, JSON.stringify(appointments));
  }, [appointments]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(invoices));
  }, [invoices]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.WARD_BEDS, JSON.stringify(wardBeds));
  }, [wardBeds]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STAFF, JSON.stringify(staff));
  }, [staff]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PHARMACY, JSON.stringify(pharmacy));
  }, [pharmacy]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(auditLogs));
  }, [auditLogs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.COMPLIANCE, JSON.stringify(compliance));
  }, [compliance]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ROLE, currentRole);
  }, [currentRole]);

  // Derived current user from staff list based on role
  const currentUser: StaffMember =
    staff.find((s) => s.role === currentRole) ||
    staff[0] || {
      id: 'STF-ADMIN',
      name: 'System Administrator',
      role: 'admin',
      department: 'Clinical Governance',
      shift: 'Morning (07:00 - 15:00)',
      phone: '+1 (555) 912-1001',
      email: 'admin@apexhealth.org',
      roomOrStation: 'Control Center',
      licenseNumber: 'FACHE-9921',
      status: 'On Duty',
    };

  const setCurrentRole = (role: UserRole) => {
    setCurrentRoleState(role);
    logAuditEvent('AUTHENTICATE', 'Security Settings', role, `Switched active session view to role: ${role.toUpperCase()}`, 'HIPAA Access Log');
    addNotification('Role Switched', `Active session switched to ${role.toUpperCase()} profile permissions.`, 'info');
  };

  // Audit Logging
  const logAuditEvent = (
    action: AuditLog['action'],
    resourceType: AuditLog['resourceType'],
    resourceId: string,
    details: string,
    complianceFlag: AuditLog['complianceFlag'] = 'HIPAA Access Log'
  ) => {
    if (!compliance.hipaaAuditLogEnabled) return;
    const newLog: AuditLog = {
      id: `LOG-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString(),
      userName: currentUser.name,
      userRole: currentRole,
      action,
      resourceType,
      resourceId,
      details,
      complianceFlag,
    };
    setAuditLogs((prev) => [newLog, ...prev.slice(0, 49)]);
  };

  const updateCompliance = (updates: Partial<SystemCompliance>) => {
    setCompliance((prev) => {
      const next = { ...prev, ...updates };
      return next;
    });
    logAuditEvent('UPDATE', 'Security Settings', 'SYS-CONF', `Compliance governance parameters updated`, 'HIPAA Access Log');
    addNotification('Security Settings Updated', 'System compliance settings synchronized successfully.', 'info');
  };

  // Notification helper
  const addNotification = (
    title: string,
    message: string,
    type: LiveNotification['type'] = 'info',
    relatedEntityId?: string
  ) => {
    const newNotif: LiveNotification = {
      id: `NOTIF-${Date.now()}`,
      title,
      message,
      type,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      read: false,
      relatedEntityId,
    };
    setNotifications((prev) => [newNotif, ...prev.slice(0, 24)]);
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const clearAllNotifications = () => {
    setNotifications([]);
  };

  // Patient Actions
  const addPatient = (
    patientData: Omit<Patient, 'id' | 'createdAt' | 'updatedAt' | 'vitals' | 'medications' | 'labResults' | 'clinicalNotes'>
  ): Patient => {
    const nextNum = 10492 + patients.length + 1;
    const newId = `PT-${nextNum}`;
    const nowIso = new Date().toISOString();

    const newPatient: Patient = {
      ...patientData,
      id: newId,
      vitals: [],
      medications: [],
      labResults: [],
      clinicalNotes: [],
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    setPatients((prev) => [newPatient, ...prev]);

    // If assigned to ward bed, update bed status
    if (newPatient.wardOrRoom) {
      setWardBeds((prev) =>
        prev.map((bed) =>
          bed.bedNumber.toLowerCase() === newPatient.wardOrRoom?.toLowerCase() ||
          bed.wardName.toLowerCase().includes(newPatient.wardOrRoom?.toLowerCase() || '___')
            ? {
                ...bed,
                status: 'Occupied',
                patientId: newId,
                patientName: `${newPatient.firstName} ${newPatient.lastName}`,
                assignedDoctor: newPatient.primaryPhysicianName,
                admissionDate: nowIso.split('T')[0],
              }
            : bed
        )
      );
    }

    logAuditEvent(
      'CREATE',
      'Patient Record',
      newId,
      `Registered ${newPatient.firstName} ${newPatient.lastName} (${newPatient.status}).`,
      'HIPAA Access Log'
    );

    addNotification(
      'New Patient Admitted',
      `${newPatient.firstName} ${newPatient.lastName} (${newId}) admitted to ${newPatient.status}.`,
      newPatient.status === 'Emergency' ? 'critical' : 'success',
      newId
    );

    return newPatient;
  };

  const updatePatient = (id: string, updates: Partial<Patient>) => {
    setPatients((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          return {
            ...p,
            ...updates,
            updatedAt: new Date().toISOString(),
          };
        }
        return p;
      })
    );
    logAuditEvent('UPDATE', 'Patient Record', id, `Updated patient clinical and demographic info`, 'HIPAA Access Log');
  };

  const addVitals = (patientId: string, vitalsData: Omit<Vitals, 'recordedAt'>) => {
    const recordedAt = new Date().toISOString();
    const newVitals: Vitals = { ...vitalsData, recordedAt };

    setPatients((prev) =>
      prev.map((p) => {
        if (p.id === patientId) {
          return {
            ...p,
            vitals: [newVitals, ...p.vitals],
            updatedAt: recordedAt,
          };
        }
        return p;
      })
    );

    const patient = patients.find((p) => p.id === patientId);
    const pName = patient ? `${patient.firstName} ${patient.lastName}` : patientId;

    logAuditEvent('UPDATE', 'Patient Record', patientId, `Recorded vitals: HR ${vitalsData.heartRate}, BP ${vitalsData.bloodPressureSys}/${vitalsData.bloodPressureDia}, SpO2 ${vitalsData.spO2}%`);

    if (vitalsData.spO2 < 92 || vitalsData.bloodPressureSys > 160 || vitalsData.heartRate > 120) {
      addNotification(
        'Critical Vitals Alert',
        `Telemetry alert for ${pName}: HR ${vitalsData.heartRate} bpm, BP ${vitalsData.bloodPressureSys}/${vitalsData.bloodPressureDia}, SpO2 ${vitalsData.spO2}%.`,
        'critical',
        patientId
      );
    } else {
      addNotification(
        'Vitals Synchronized',
        `Logged vitals for ${pName}: SpO2 ${vitalsData.spO2}%, Pulse ${vitalsData.heartRate} bpm.`,
        'info',
        patientId
      );
    }
  };

  const addMedication = (patientId: string, medData: Omit<Medication, 'id'>) => {
    const newMed: Medication = {
      ...medData,
      id: `MED-${Date.now().toString().slice(-4)}`,
    };

    setPatients((prev) =>
      prev.map((p) => {
        if (p.id === patientId) {
          return {
            ...p,
            medications: [newMed, ...p.medications],
            updatedAt: new Date().toISOString(),
          };
        }
        return p;
      })
    );

    logAuditEvent('CREATE', 'Prescription', newMed.id, `Prescribed ${newMed.name} (${newMed.dosage}) by ${newMed.prescribedBy}`);
    addNotification('Prescription Added', `${newMed.name} added to medication chart by ${newMed.prescribedBy}.`, 'info', patientId);
  };

  const addClinicalNote = (patientId: string, noteData: Omit<ClinicalNote, 'id' | 'date'>) => {
    const newNote: ClinicalNote = {
      ...noteData,
      id: `NOTE-${Date.now().toString().slice(-4)}`,
      date: new Date().toISOString().split('T')[0],
    };

    setPatients((prev) =>
      prev.map((p) => {
        if (p.id === patientId) {
          return {
            ...p,
            clinicalNotes: [newNote, ...p.clinicalNotes],
            updatedAt: new Date().toISOString(),
          };
        }
        return p;
      })
    );

    logAuditEvent('CREATE', 'Patient Record', patientId, `Encounter clinical note recorded by ${newNote.doctorName}`);
    addNotification('Clinical Note Logged', `Note by ${newNote.doctorName} (${newNote.diagnosisCode}).`, 'info', patientId);
  };

  const addLabResult = (patientId: string, labData: Omit<LabResult, 'id'>) => {
    const newLab: LabResult = {
      ...labData,
      id: `LAB-${Date.now().toString().slice(-4)}`,
    };

    setPatients((prev) =>
      prev.map((p) => {
        if (p.id === patientId) {
          return {
            ...p,
            labResults: [newLab, ...p.labResults],
            updatedAt: new Date().toISOString(),
          };
        }
        return p;
      })
    );

    logAuditEvent('CREATE', 'Lab Result', newLab.id, `Diagnostics verified: ${newLab.testName} (${newLab.value})`);
    addNotification(
      'Diagnostic Result Available',
      `${newLab.testName}: ${newLab.value} [${newLab.status}]`,
      newLab.status === 'Critical' ? 'critical' : newLab.status === 'Elevated' ? 'warning' : 'info',
      patientId
    );
  };

  const updateLabResult = (patientId: string, labId: string, updates: Partial<LabResult>) => {
    setPatients((prev) =>
      prev.map((p) => {
        if (p.id === patientId) {
          return {
            ...p,
            labResults: p.labResults.map((l) => (l.id === labId ? { ...l, ...updates } : l)),
            updatedAt: new Date().toISOString(),
          };
        }
        return p;
      })
    );
    logAuditEvent('UPDATE', 'Lab Result', labId, `Diagnostic assay updated: ${JSON.stringify(updates)}`);
    addNotification(
      'Lab Assay Verified',
      `Diagnostic result updated (${updates.status || 'Verified'})`,
      updates.status === 'Critical' ? 'critical' : updates.status === 'Elevated' ? 'warning' : 'info',
      patientId
    );
  };

  const dischargePatient = (patientId: string) => {
    const patient = patients.find((p) => p.id === patientId);
    if (!patient) return;

    setPatients((prev) =>
      prev.map((p) =>
        p.id === patientId
          ? {
              ...p,
              status: 'Discharged',
              wardOrRoom: undefined,
              updatedAt: new Date().toISOString(),
            }
          : p
      )
    );

    setWardBeds((prev) =>
      prev.map((bed) =>
        bed.patientId === patientId
          ? {
              ...bed,
              status: 'Available',
              patientId: undefined,
              patientName: undefined,
              assignedDoctor: undefined,
              admissionDate: undefined,
            }
          : bed
      )
    );

    logAuditEvent('UPDATE', 'Patient Record', patientId, `Discharged patient ${patient.firstName} ${patient.lastName}`);
    addNotification(
      'Patient Discharged',
      `${patient.firstName} ${patient.lastName} discharged. Bed sanitization protocol initialized.`,
      'success',
      patientId
    );
  };

  // Appointment Actions
  const bookAppointment = (
    aptData: Omit<Appointment, 'id' | 'queueNumber' | 'createdAt'>
  ): Appointment => {
    const queueNum = appointments.filter((a) => a.date === aptData.date).length + 1;
    const newApt: Appointment = {
      ...aptData,
      id: `APT-2026-${String(appointments.length + 1).padStart(3, '0')}`,
      queueNumber: queueNum,
      estimatedWaitMinutes: queueNum * 15,
      createdAt: new Date().toISOString(),
    };

    setAppointments((prev) => [...prev, newApt]);

    logAuditEvent('CREATE', 'Appointment', newApt.id, `Booked slot for ${newApt.patientName} with ${newApt.doctorName}`);
    addNotification(
      'Appointment Confirmed',
      `Live slot confirmed for ${newApt.patientName} with ${newApt.doctorName} on ${newApt.date} at ${newApt.timeSlot}.`,
      'info',
      newApt.id
    );

    return newApt;
  };

  const updateAppointmentStatus = (aptId: string, status: AppointmentStatus) => {
    let affectedApt: Appointment | undefined;

    setAppointments((prev) =>
      prev.map((apt) => {
        if (apt.id === aptId) {
          affectedApt = { ...apt, status };
          return affectedApt;
        }
        return apt;
      })
    );

    if (affectedApt) {
      logAuditEvent('UPDATE', 'Appointment', aptId, `Status updated to ${status}`);
      if (status === 'In Consultation') {
        setDoctors((prev) =>
          prev.map((d) => (d.id === affectedApt?.doctorId ? { ...d, status: 'In Consultation' } : d))
        );
        addNotification(
          'Consultation Started',
          `${affectedApt.doctorName} started session with ${affectedApt.patientName}.`,
          'info',
          affectedApt.id
        );
      } else if (status === 'Completed') {
        setDoctors((prev) =>
          prev.map((d) => (d.id === affectedApt?.doctorId ? { ...d, status: 'Available' } : d))
        );
        addNotification(
          'Consultation Finished',
          `Session complete for ${affectedApt.patientName}.`,
          'success',
          affectedApt.id
        );
      }
    }
  };

  const callNextAppointment = (doctorId?: string) => {
    const queue = appointments.filter(
      (a) =>
        (doctorId ? a.doctorId === doctorId : true) &&
        (a.status === 'Checked-In' || a.status === 'Scheduled')
    );

    if (queue.length === 0) {
      addNotification('Queue Empty', 'No waiting patients in queue for this physician.', 'info');
      return;
    }

    const nextPatient = queue[0];
    updateAppointmentStatus(nextPatient.id, 'In Consultation');
  };

  // Billing Actions
  const createInvoice = (
    invData: Omit<Invoice, 'id' | 'subtotal' | 'patientPayable' | 'amountPaid' | 'balanceDue' | 'transactions'>
  ): Invoice => {
    const subtotal = invData.items.reduce((sum, item) => sum + item.amount, 0);
    const patientPayable = Math.max(0, subtotal - invData.insuranceCoveredAmount + (invData.copayAmount || 0));

    const newInvoice: Invoice = {
      ...invData,
      id: `INV-2026-${String(invoices.length + 82).padStart(4, '0')}`,
      subtotal,
      tax: 0,
      patientPayable,
      amountPaid: 0,
      balanceDue: patientPayable,
      transactions: [],
    };

    setInvoices((prev) => [newInvoice, ...prev]);

    logAuditEvent('CREATE', 'Billing Invoice', newInvoice.id, `Created invoice for ${newInvoice.patientName} total $${subtotal}`, 'PCI-DSS Payment Log');
    addNotification(
      'Medical Invoice Created',
      `Invoice ${newInvoice.id} generated for ${newInvoice.patientName} ($${patientPayable.toFixed(2)} due).`,
      'info',
      newInvoice.id
    );

    return newInvoice;
  };

  const processPayment = async (
    invoiceId: string,
    paymentData: { amount: number; method: PaymentMethod; cardLast4?: string }
  ): Promise<{ success: boolean; transaction: PaymentTransaction }> => {
    await new Promise((resolve) => setTimeout(resolve, 600));

    const authCode = `AUTH-${Math.floor(100000 + Math.random() * 900000)}-SEC`;
    const newTxn: PaymentTransaction = {
      transactionId: `TXN-SEC-${Math.floor(10000 + Math.random() * 90000)}`,
      timestamp: new Date().toISOString(),
      amountPaid: paymentData.amount,
      method: paymentData.method,
      cardLast4: paymentData.cardLast4 || (paymentData.method === 'Credit/Debit Card' ? '4242' : undefined),
      authCode,
      gatewayStatus: 'Success',
    };

    setInvoices((prev) =>
      prev.map((inv) => {
        if (inv.id === invoiceId) {
          const totalPaid = inv.amountPaid + paymentData.amount;
          const newBalance = Math.max(0, inv.patientPayable - totalPaid);
          const newStatus = newBalance <= 0 ? 'Paid' : 'Partially Paid';

          return {
            ...inv,
            amountPaid: totalPaid,
            balanceDue: newBalance,
            status: newStatus,
            paymentMethod: paymentData.method,
            transactions: [...inv.transactions, newTxn],
          };
        }
        return inv;
      })
    );

    logAuditEvent('UPDATE', 'Billing Invoice', invoiceId, `Payment of $${paymentData.amount.toFixed(2)} settled via ${paymentData.method} (${authCode})`, 'PCI-DSS Payment Log');
    addNotification(
      'Payment Processed Successfully',
      `Secure payment of $${paymentData.amount.toFixed(2)} approved via ${paymentData.method}.`,
      'success',
      invoiceId
    );

    return { success: true, transaction: newTxn };
  };

  // Ward Actions
  const assignBedToPatient = (bedId: string, patientId: string) => {
    const patient = patients.find((p) => p.id === patientId);
    if (!patient) return;

    setWardBeds((prev) =>
      prev.map((bed) => {
        if (bed.id === bedId) {
          return {
            ...bed,
            status: 'Occupied',
            patientId,
            patientName: `${patient.firstName} ${patient.lastName}`,
            assignedDoctor: patient.primaryPhysicianName,
            admissionDate: new Date().toISOString().split('T')[0],
          };
        }
        return bed;
      })
    );

    const bed = wardBeds.find((b) => b.id === bedId);
    updatePatient(patientId, {
      status: 'Inpatient',
      wardOrRoom: `${bed?.wardName} - ${bed?.bedNumber}`,
    });

    logAuditEvent('UPDATE', 'Patient Record', patientId, `Assigned to ${bed?.wardName} (${bed?.bedNumber})`);
    addNotification('Ward Bed Assigned', `${patient.firstName} ${patient.lastName} transferred to ${bed?.bedNumber}.`, 'info', patientId);
  };

  const releaseBed = (bedId: string) => {
    const targetBed = wardBeds.find((b) => b.id === bedId);
    if (!targetBed) return;

    setWardBeds((prev) =>
      prev.map((bed) =>
        bed.id === bedId
          ? {
              ...bed,
              status: 'Available',
              patientId: undefined,
              patientName: undefined,
              assignedDoctor: undefined,
              admissionDate: undefined,
            }
          : bed
      )
    );

    addNotification('Bed Cleared', `Bed ${targetBed.bedNumber} sanitized and available.`, 'info');
  };

  // Staff Actions
  const addStaff = (memberData: Omit<StaffMember, 'id'>) => {
    const newStaffMember: StaffMember = {
      ...memberData,
      id: `STF-${String(staff.length + 1).padStart(2, '0')}`,
    };
    setStaff((prev) => [...prev, newStaffMember]);
    logAuditEvent('CREATE', 'Security Settings', newStaffMember.id, `Staff member added: ${newStaffMember.name} (${newStaffMember.role})`);
    addNotification('Staff Registered', `Added ${newStaffMember.name} to ${newStaffMember.department}.`, 'info');
  };

  const updateStaff = (id: string, updates: Partial<StaffMember>) => {
    setStaff((prev) => prev.map((s) => (s.id === id ? { ...s, ...updates } : s)));
    logAuditEvent('UPDATE', 'Security Settings', id, `Updated staff duty profile`);
  };

  // Pharmacy Actions
  const dispensePharmacyItem = (itemId: string, quantity: number, patientId: string) => {
    let dispensedItem: PharmacyItem | undefined;
    setPharmacy((prev) =>
      prev.map((item) => {
        if (item.id === itemId) {
          const newStock = Math.max(0, item.stockQuantity - quantity);
          dispensedItem = { ...item, stockQuantity: newStock };
          return dispensedItem;
        }
        return item;
      })
    );

    if (dispensedItem) {
      logAuditEvent('DISPENSE', 'Prescription', itemId, `Dispensed ${quantity} units of ${dispensedItem.name} to patient ${patientId}`);
      if (dispensedItem.stockQuantity <= dispensedItem.minThreshold) {
        addNotification(
          'Low Stock Warning',
          `${dispensedItem.name} has only ${dispensedItem.stockQuantity} units left (Min threshold: ${dispensedItem.minThreshold}).`,
          'warning',
          itemId
        );
      } else {
        addNotification('Medication Dispensed', `Dispensed ${quantity} units of ${dispensedItem.name}.`, 'success', itemId);
      }
    }
  };

  const restockPharmacyItem = (itemId: string, quantity: number) => {
    setPharmacy((prev) =>
      prev.map((item) =>
        item.id === itemId ? { ...item, stockQuantity: item.stockQuantity + quantity } : item
      )
    );
    logAuditEvent('UPDATE', 'Prescription', itemId, `Restocked +${quantity} units to inventory`);
    addNotification('Stock Replenished', `Added +${quantity} units to pharmacy inventory.`, 'info', itemId);
  };

  const addPharmacyItem = (itemData: Omit<PharmacyItem, 'id'>) => {
    const newItem: PharmacyItem = {
      ...itemData,
      id: `PHARM-${String(pharmacy.length + 1).padStart(2, '0')}`,
    };
    setPharmacy((prev) => [...prev, newItem]);
    logAuditEvent('CREATE', 'Prescription', newItem.id, `Cataloged new medicine: ${newItem.name}`);
    addNotification('Catalog Updated', `Added ${newItem.name} to pharmacy stock.`, 'info');
  };

  const resetHospitalData = () => {
    setPatients(initialPatients);
    setDoctors(initialDoctors);
    setAppointments(initialAppointments);
    setInvoices(initialInvoices);
    setWardBeds(initialWardBeds);
    setStaff(initialStaff);
    setPharmacy(initialPharmacy);
    setAuditLogs(initialAuditLogs);
    setCompliance(initialCompliance);
    localStorage.clear();
    addNotification('System Reset', 'Restored pristine MedCore OS clinical dataset.', 'info');
  };

  const selectedPatient = patients.find((p) => p.id === selectedPatientId) || null;

  return (
    <HospitalContext.Provider
      value={{
        patients,
        doctors,
        appointments,
        invoices,
        wardBeds,
        staff,
        pharmacy,
        auditLogs,
        compliance,
        notifications,
        selectedPatient,
        activeTab,
        currentRole,
        currentUser,
        setCurrentRole,
        setActiveTab,
        setSelectedPatientId,
        addPatient,
        updatePatient,
        addVitals,
        addMedication,
        addClinicalNote,
        addLabResult,
        updateLabResult,
        dischargePatient,
        bookAppointment,
        updateAppointmentStatus,
        callNextAppointment,
        createInvoice,
        processPayment,
        assignBedToPatient,
        releaseBed,
        addStaff,
        updateStaff,
        dispensePharmacyItem,
        restockPharmacyItem,
        addPharmacyItem,
        logAuditEvent,
        updateCompliance,
        markNotificationRead,
        clearAllNotifications,
        addNotification,
        resetHospitalData,
      }}
    >
      {children}
    </HospitalContext.Provider>
  );
};

export const useHospital = () => {
  const context = useContext(HospitalContext);
  if (!context) {
    throw new Error('useHospital must be used within a HospitalProvider');
  }
  return context;
};
